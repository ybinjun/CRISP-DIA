function IsIonsKept = InterfereDetectOnePeak(PeakListAglin,areaSampleAglin,ReferenceMS2)
    NumTransitionsOrig = size( areaSampleAglin, 2 );
    FinalIonsKeptIndexs = 1:NumTransitionsOrig;
    isRemove = isnan( areaSampleAglin ) | areaSampleAglin==0;
    areaSampleAglin( isRemove ) = [  ];
    ReferenceMS2( :, isRemove ) = [  ];
    FinalIonsKeptIndexs( isRemove ) = [  ];
    NumTransitions = size( areaSampleAglin, 2 );
    if sum( ~isnan( ReferenceMS2( 2, : ) ) )>0
        while NumTransitions>2
            SignalRatioErrorLimit = 0.05;
            ScaledReferenceMS2 = ReferenceMS2( 2, : ) / sum( ReferenceMS2( 2, : ) );
            ScaledSampleMS2 = areaSampleAglin / sum( areaSampleAglin );
            SignalRatioErrors = sqrt( sum( (ScaledSampleMS2 - ScaledReferenceMS2) .* (ScaledSampleMS2 - ScaledReferenceMS2), 'omitnan' ) / (NumTransitions - 1) );
            if max( SignalRatioErrors, [  ], 'omitnan' )>SignalRatioErrorLimit
                FinalEuclideanDistRemoveOneIon = ones( 1, NumTransitions ) * NaN;
                for j = 1:NumTransitions
                    areaSampleAglinTempo = [ areaSampleAglin( 1:j - 1 ), areaSampleAglin( j + 1:NumTransitions ) ];
                    ReferenceMS2Tempo = [ ReferenceMS2( :, 1:j - 1 ), ReferenceMS2( :, j + 1:NumTransitions ) ];
                    ScaledReferenceMS2Tempo = ReferenceMS2Tempo( 2, : ) / sum( ReferenceMS2Tempo( 2, : ) );
                    ScaledSampleMS2Tempo = areaSampleAglinTempo / sum( areaSampleAglinTempo );
                    EuclideanDistRemoveOneIon = sqrt( sum( (ScaledSampleMS2Tempo - ScaledReferenceMS2Tempo) .* (ScaledSampleMS2Tempo - ScaledReferenceMS2Tempo), 'omitnan' ) / (NumTransitions - 1 - 1) );
                    FinalEuclideanDistRemoveOneIon( j ) = EuclideanDistRemoveOneIon;
                end
                [MinRatioErrorsRemoveOneIon,jIndex] = min( FinalEuclideanDistRemoveOneIon );
                if SignalRatioErrors - MinRatioErrorsRemoveOneIon>SignalRatioErrorLimit
                    areaSampleAglin( jIndex ) = [  ];
                    NumTransitions = NumTransitions - 1;
                    ReferenceMS2( :, jIndex ) = [  ];
                    FinalIonsKeptIndexs( jIndex ) = [  ];
                else
                    break
                end
            else
                break
            end
        end
    end
    IsIonsKept = false( 1, NumTransitionsOrig );
    IsIonsKept( FinalIonsKeptIndexs ) = true;
end
