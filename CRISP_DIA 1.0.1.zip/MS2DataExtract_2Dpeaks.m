function MS2DataExtract_2Dpeaks(MyPeptideMSspec,RawDataPositionList,PrecursorRanges,inPrecursorRanges,MzErrorLimitPPM,SampleIndex,HalfExtractWindow,FilePath,Tr_Pred,MaxRetentionTime,iRTMeanMzErrorPPM,isSmooth,IonMobility,IonMobilityHalfWindow,NumIonMobilityRangesPerIsolationWindow)
    NumPeptides = size( MyPeptideMSspec, 2 );
    loadFilePath = RawDataPositionList{ SampleIndex }( 1:length( RawDataPositionList{ SampleIndex } ) - 7 );
    NumPrecursorRanges = size( PrecursorRanges, 1 );
    parfor i = 1:NumPrecursorRanges
        inPrecursorRangesCurrent = inPrecursorRanges( i, : );
        NumPeptidesCurrent = sum( inPrecursorRangesCurrent );
        if NumPeptidesCurrent==0
            continue
        end
        subPrecursorRanges = PrecursorRanges( i, : );
        SubFileName = [ num2str( subPrecursorRanges( 1, 1 ), '%4.3f' ), '-', num2str( subPrecursorRanges( 1, 2 ), '%4.3f' ) ];
        LoadName = [ loadFilePath, SubFileName, '.mat' ];
        Tempo = load( LoadName, 'MySubMS', 'FrameRTs', 'NumPeakApexes' );
        MyMS = Tempo.MySubMS;
        FrameRTs = Tempo.FrameRTs;
        NumPeakApexes = Tempo.NumPeakApexes;
        Tempo = [  ];
        times = [  ];
        NumFrames = size( FrameRTs, 1 );
        for ii = 1:NumFrames
            times = [ times; ones( NumPeakApexes( ii ), 1 ) * FrameRTs( ii ) ];
        end
        MyMS = [ cell2mat( MyMS ), times ];
        MyDatasetToSave = cell( 1, NumPeptidesCurrent );
        q = 1;
        for k = 1:NumPeptides
            if inPrecursorRangesCurrent( k )==0
                continue
            end
            StartExtractTime = Tr_Pred( k ) - HalfExtractWindow;
            EndExtractTime = Tr_Pred( k ) + HalfExtractWindow;
            IonMobilityLimit = [ IonMobility( k ) - IonMobilityHalfWindow, IonMobility( k ) + IonMobilityHalfWindow ];
            subMyMS_Medium = MyMS( (times>=StartExtractTime) & (times<=EndExtractTime) & (MyMS( :, 2 )>=IonMobilityLimit( 1 )) & (MyMS( :, 2 )<=IonMobilityLimit( 2 )), : );
            times_OK = FrameRTs( (FrameRTs>=StartExtractTime) & (FrameRTs<=EndExtractTime) );
            Num_times_OK = size( times_OK, 1 );
            MyDataset = [  ];
            NumTransitions = size( MyPeptideMSspec{ k }.MSspec, 1 );
            for j = 1:NumTransitions
                precursor = MyPeptideMSspec{ k }.MSspec( j, 1 );
                mzProduct = MyPeptideMSspec{ k }.MSspec( j, 2 );
                if ~isnan( mzProduct )
                    mzInt = [ mzProduct * (1 + iRTMeanMzErrorPPM( SampleIndex ) / 1000000 - MzErrorLimitPPM / 1000000), mzProduct * (1 + iRTMeanMzErrorPPM( SampleIndex ) / 1000000 + MzErrorLimitPPM / 1000000) ];
                    subMyMS = subMyMS_Medium( (subMyMS_Medium( :, 1 )>=mzInt( 1 )) & (subMyMS_Medium( :, 1 )<=mzInt( 2 )), : );
                    NumData = size( subMyMS, 1 );
                    subMyMS_merged = ones( Num_times_OK, 4 ) * NaN;
                    TempLine = 1;
                    for ii = 1:Num_times_OK
                        LinesInThis = [  ];
                        if TempLine>NumData || subMyMS( TempLine, 4 )>times_OK( ii )
                            subMyMS_merged( ii, : ) = [ times_OK( ii ), 0, 0, NaN ];
                        else
                            while TempLine<=NumData && subMyMS( TempLine, 4 )==times_OK( ii )
                                LinesInThis( end + 1, 1 ) = TempLine;
                                TempLine = TempLine + 1;
                            end
                            PeakData = subMyMS( LinesInThis, : );
                            if size( LinesInThis, 1 )>1
                                sumPeakData = sum( PeakData( :, 3 ) );
                                MzValue = sum( PeakData( :, 1 ) .* PeakData( :, 3 ) ) / sumPeakData;
                                IonMobilityAverage = sum( PeakData( :, 2 ) .* PeakData( :, 3 ) ) / sumPeakData;
                                subMyMS_merged( ii, : ) = [ times_OK( ii ), MzValue, sumPeakData, IonMobilityAverage ];
                            else
                                subMyMS_merged( ii, : ) = [ times_OK( ii ), PeakData( 1, 1 ), PeakData( 1, 3 ), PeakData( 1, 2 ) ];
                            end
                        end
                    end
                    if NumIonMobilityRangesPerIsolationWindow( i )==2
                        subMyMS1 = subMyMS_merged( 1:2:Num_times_OK, : );
                        subMyMS2 = subMyMS_merged( 2:2:Num_times_OK, : );
                        NumScans1 = size( subMyMS1, 1 );
                        NumScans2 = size( subMyMS2, 1 );
                        if NumScans2<NumScans1
                            subMyMS2( end + 1, : ) = [ 0, 0, 0, NaN ];
                        end
                        EIPProd = ones( NumScans1, 4 ) * NaN;
                        for ii = 1:NumScans1
                            TempSumIntensity = subMyMS1( ii, 3 ) + subMyMS2( ii, 3 );
                            if TempSumIntensity==0
                                EIPProd( ii, : ) = [ subMyMS1( ii, 1 ), 0, 0, NaN ];
                            else
                                EIPProd( ii, : ) = [ subMyMS1( ii, 1 ), (subMyMS1( ii, 2 ) * subMyMS1( ii, 3 ) + subMyMS2( ii, 2 ) * subMyMS2( ii, 3 )) / TempSumIntensity, TempSumIntensity, sum( [ subMyMS1( ii, 4 ) * subMyMS1( ii, 3 ), subMyMS2( ii, 4 ) * subMyMS2( ii, 3 ) ], 'omitnan' ) / TempSumIntensity ];
                            end
                        end
                    elseif NumIonMobilityRangesPerIsolationWindow( i )==1
                        EIPProd = subMyMS_merged;
                    else
                        error( 'The combination of isolation window and ion mobility is not recognized.' )
                    end
                    if isSmooth==1
                        NumPoints=size(EIPProd,1);
                        MzSmooth=ones(NumPoints,1)*NaN;
                        MzSmooth(1,1)=EIPProd(1,2);
                        IonMobilitySmooth=ones(NumPoints,1)*NaN;
                        IonMobilitySmooth(1,1)=EIPProd(1,4);
                        IntensitySmooth=ones(NumPoints,1)*NaN;
                        IntensitySmooth(1,1)=EIPProd(1,3);
                        for iii=2:NumPoints-1
                            TempSumIntensity=sum([EIPProd(iii-1,3) EIPProd(iii,3) EIPProd(iii+1,3)],'omitnan');
                            MzSmooth(iii,1)=(EIPProd(iii-1,2)*EIPProd(iii-1,3)+EIPProd(iii,2)*EIPProd(iii,3)+EIPProd(iii+1,2)*EIPProd(iii+1,3))/(TempSumIntensity);
                            IonMobilitySmooth(iii,1)=sum([EIPProd(iii-1,4)*EIPProd(iii-1,3) EIPProd(iii,4)*EIPProd(iii,3) EIPProd(iii+1,4)*EIPProd(iii+1,3)],'omitnan')/(TempSumIntensity);
                            if TempSumIntensity==0
                                MzSmooth(iii,1)=0; 
                                IonMobilitySmooth(iii,1)=NaN;
                            end
                            IntensitySmooth(iii)=TempSumIntensity/3;
                        end
                        MzSmooth(NumPoints,1)=EIPProd(NumPoints,2);
                        IonMobilitySmooth(NumPoints,1)=EIPProd(NumPoints,4);
                        IntensitySmooth(NumPoints)=EIPProd(NumPoints,3);
                        EIPProdSmooth=[EIPProd(:,1),MzSmooth,IntensitySmooth,IonMobilitySmooth];
                        MyDataset{j}.Data=EIPProdSmooth;
                    else
                        MyDataset{j}.Data=EIPProd;
                    end
                    MyDataset{ j }.mzInt = mzInt;
                end
                MyDataset{ j }.precursor = precursor;
                MyDataset{ j }.mzProduct = mzProduct;
            end
            MyDatasetToSave{ q } = MyDataset;
            q = q + 1;
        end
        SaveName = [ FilePath, SubFileName, 'Sample', num2str( SampleIndex, '%03d' ), '.mat' ];
        parsave( SaveName, MyDatasetToSave );
    end
end
function parsave(fname,MyDatasetToSave)
    Info = whos( 'MyDatasetToSave' );
    if Info.bytes<2147483648
        save( fname, 'MyDatasetToSave', '-v7' );
    else
        save( fname, 'MyDatasetToSave', '-v7.3' );
    end
end
