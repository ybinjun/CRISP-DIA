function [PrecursorRanges,PrecursorRangesRemoveBoundary,MS2_CE] = mzML2Matlab(FileName,FileID,OutputFilePath)
    FilePath = [ OutputFilePath, '\', FileID, '\' ];
    [~,~] = mkdir( FilePath );
    disp( [ 'Start converting ', FileID ] );
    fidRead = fopen( FileName, 'r' );
    if fidRead==-1
        error( [ FileName, ' File open fail.' ] )
    end
    curLine = fgetl( fidRead );
    curLine = strtrim( curLine );
    while ~strcmp( curLine( 1:min( length( curLine ), 13 ) ), '<spectrumList' )
        curLine = fgetl( fidRead );
        curLine = strtrim( curLine );
    end
    CurrentPosStart = strfind( curLine, 'count="' ) + 7;
    CurrentLength = find( curLine( CurrentPosStart:end )=='"', 1 ) - 1;
    scanCount = curLine( CurrentPosStart:CurrentPosStart + CurrentLength - 1 );
    if isempty( scanCount )
        error( 'The mzML file format is not recognized.' );
    else
        scanCount = str2double( scanCount );
    end
    disp( [ 'Start reading mzML file. In ', FileID ] );
    IsMS1 = true( scanCount, 1 );
    Time = ones( scanCount, 1 ) * NaN;
    MS2_PrecursorTarget = ones( scanCount, 1 ) * NaN;
    MS2_PrecursorLowerOffset = ones( scanCount, 1 ) * NaN;
    MS2_PrecursorUpperOffset = ones( scanCount, 1 ) * NaN;
    ScanMzBinaryPosition = ones( scanCount, 1 ) * NaN;
    ScanIntensityBinaryPosition = ones( scanCount, 1 ) * NaN;
    MS2_CE = ones( scanCount, 1 ) * NaN;
    IsCompression = false( scanCount, 1 );
    DataFormat = ones( scanCount, 1 ) * NaN;
    DispInterval = 10000;
    DispFlag = 0;
    count = 1;
    while count<=scanCount
        curLine = fgetl( fidRead );
        curLine = strtrim( curLine );
        PosFirstBlank = find( curLine==' ', 1 );
        if isempty( PosFirstBlank )
            PosFirstBlank = find( curLine=='>', 1 );
        end
        if isempty( PosFirstBlank )
            error( 'The mzML file format is not recognized.' )
        end
        CurrentLabel = curLine( 2:PosFirstBlank - 1 );
        switch CurrentLabel
            case 'cvParam'
                CurrentPosStart = strfind( curLine, ' accession="' ) + 12;
                CurrentLength = find( curLine( CurrentPosStart:end )=='"', 1 ) - 1;
                CurrentPosEnd = CurrentPosStart + CurrentLength - 1;
                CurrentMS_Label = curLine( CurrentPosStart:CurrentPosEnd );
                if isempty( CurrentMS_Label )
                    error( 'The mzML file format is not recognized.' )
                end
                switch CurrentMS_Label
                    case 'MS:1000579'
                        IsMS1( count ) = true;
                    case 'MS:1000580'
                        IsMS1( count ) = false;
                    case 'MS:1000016'
                        Time( count ) = getMZML_value( curLine( CurrentPosEnd + 1:end ) );
                    case 'MS:1000827'
                        MS2_PrecursorTarget( count ) = getMZML_value( curLine( CurrentPosEnd + 1:end ) );
                    case 'MS:1000828'
                        MS2_PrecursorLowerOffset( count ) = getMZML_value( curLine( CurrentPosEnd + 1:end ) );
                    case 'MS:1000829'
                        MS2_PrecursorUpperOffset( count ) = getMZML_value( curLine( CurrentPosEnd + 1:end ) );
                    case 'MS:1000045'
                        MS2_CE( count ) = getMZML_value( curLine( CurrentPosEnd + 1:end ) );
                    case { 'MS:1000574' }
                        IsCompression( count ) = true;
                    case { 'MS:1000576' }
                        IsCompression( count ) = false;
                    case { 'MS:1000523' }
                        DataFormat( count ) = 64;
                    case { 'MS:1000521' }
                        DataFormat( count ) = 32;
                    case { 'MS:1000514' }
                        IsMzBinary = true;
                        TempoFilePosition = ftell( fidRead );
                    case { 'MS:1000515' }
                        IsMzBinary = false;
                        TempoFilePosition = ftell( fidRead );
                end
            case 'binary'
                if IsMzBinary
                    ScanMzBinaryPosition( count ) = TempoFilePosition;
                else
                    ScanIntensityBinaryPosition( count ) = TempoFilePosition;
                end
            case '/spectrum'
                count = count + 1;
                DispFlag = DispFlag + 1;
                if DispFlag>=DispInterval
                    DispFlag = 0;
                    disp( [ num2str( count / scanCount * 100, '%2.1f' ), '% of this mzML file has been read. In ', FileID ] );
                end
        end
    end
    MS1_Time = Time( IsMS1 );
    MS2_Time = Time( ~IsMS1 );
    MS2_CE = MS2_CE( ~IsMS1 );
    MS1ScanMzBinaryPosition = ScanMzBinaryPosition( IsMS1 );
    MS2ScanMzBinaryPosition = ScanMzBinaryPosition( ~IsMS1 );
    MS1ScanIntensityBinaryPosition = ScanIntensityBinaryPosition( IsMS1 );
    MS2ScanIntensityBinaryPosition = ScanIntensityBinaryPosition( ~IsMS1 );
    DataFormatMS1 = DataFormat( IsMS1 );
    DataFormatMS2 = DataFormat( ~IsMS1 );
    IsCompressionMS1 = IsCompression( IsMS1 );
    IsCompressionMS2 = IsCompression( ~IsMS1 );
    MS2_PrecursorTarget( isnan( MS2_PrecursorTarget ) ) = [  ];
    MS2_PrecursorLowerOffset( isnan( MS2_PrecursorLowerOffset ) ) = [  ];
    MS2_PrecursorUpperOffset( isnan( MS2_PrecursorUpperOffset ) ) = [  ];
    if ~(size( MS1_Time, 1 )==size( MS1ScanIntensityBinaryPosition, 1 ) && size( MS1_Time, 1 )==size( MS1ScanMzBinaryPosition, 1 ) && size( MS1_Time, 1 )==size( DataFormatMS1, 1 ) && size( MS1_Time, 1 )==size( IsCompressionMS1, 1 ))
        error( 'Error! MS1 scan count does not match!' )
    end
    if ~(size( MS2_Time, 1 )==size( MS2ScanIntensityBinaryPosition, 1 ) && size( MS2_Time, 1 )==size( MS2ScanMzBinaryPosition, 1 ) && size( MS2_Time, 1 )==size( MS2_PrecursorTarget, 1 ) && size( MS2_Time, 1 )==size( MS2_PrecursorLowerOffset, 1 ) && size( MS2_Time, 1 )==size( MS2_PrecursorUpperOffset, 1 ))
        error( 'Error! MS2 scan count and/or isolation window do not match!' )
    end
    precursorMin = MS2_PrecursorTarget - MS2_PrecursorLowerOffset;
    precursorMax = MS2_PrecursorTarget + MS2_PrecursorUpperOffset;
    PrecursorRanges = unique( [ precursorMin, precursorMax ], 'rows' );
    NumPrecursorRanges = size( PrecursorRanges, 1 );
    PrecursorRangesRemoveBoundary( 1, 1 ) = PrecursorRanges( 1, 1 );
    for k = 1:NumPrecursorRanges - 1
        if PrecursorRanges( k, 2 )>PrecursorRanges( k + 1, 1 )
            PrecursorRangesRemoveBoundary( k, 2 ) = (PrecursorRanges( k, 2 ) + PrecursorRanges( k + 1, 1 )) / 2;
            PrecursorRangesRemoveBoundary( k + 1, 1 ) = PrecursorRangesRemoveBoundary( k, 2 );
        else
            PrecursorRangesRemoveBoundary( k, 2 ) = PrecursorRanges( k, 2 );
            PrecursorRangesRemoveBoundary( k + 1, 1 ) = PrecursorRanges( k + 1, 1 );
        end
    end
    PrecursorRangesRemoveBoundary( NumPrecursorRanges, 2 ) = PrecursorRanges( NumPrecursorRanges, 2 );
    disp( [ 'Start converting MS2 data. In ', FileID ] );
    for k = 1:NumPrecursorRanges
        Scans2Keep = (sum( abs( [ precursorMin, precursorMax ] - PrecursorRanges( k, : ) ), 2 )==0);
        SubMS2ScanMzBinaryPosition = MS2ScanMzBinaryPosition( Scans2Keep );
        SubMS2ScanIntensityBinaryPosition = MS2ScanIntensityBinaryPosition( Scans2Keep );
        SubMS2_Time = MS2_Time( Scans2Keep );
        SubMS2_CE = MS2_CE( Scans2Keep );
        SubDataFormatMS2 = DataFormatMS2( Scans2Keep );
        SubIsCompressionMS2 = IsCompressionMS2( Scans2Keep );
        NumSubMS2ScanBinaryPosition = size( SubMS2ScanMzBinaryPosition, 1 );
        subMyMS = cell( NumSubMS2ScanBinaryPosition, 1 );
        for i = 1:NumSubMS2ScanBinaryPosition
            fseek( fidRead, SubMS2ScanMzBinaryPosition( i ), 'bof' );
            curLine = fgetl( fidRead );
            mzValue = getMZML_Binary( curLine, SubIsCompressionMS2( i ), SubDataFormatMS2( i ) );
            fseek( fidRead, SubMS2ScanIntensityBinaryPosition( i ), 'bof' );
            curLine = fgetl( fidRead );
            IntensityValue = getMZML_Binary( curLine, SubIsCompressionMS2( i ), SubDataFormatMS2( i ) );
            subMyMS{ i }.Data = [ mzValue, IntensityValue ];
            subMyMS{ i }.Time = SubMS2_Time( i );
            subMyMS{ i }.CE = SubMS2_CE( i );
        end
        SubFileName = [ num2str( PrecursorRangesRemoveBoundary( k, 1 ), '%4.3f' ), '-', num2str( PrecursorRangesRemoveBoundary( k, 2 ), '%4.3f' ), '.mat' ];
        SaveName = [ FilePath, SubFileName ];
        Info = whos( 'subMyMS' );
        if Info.bytes<2147483648
            save( SaveName, 'subMyMS', '-v7' );
        else
            save( SaveName, 'subMyMS', '-v7.3' );
        end
        clear subMyMS ;
        disp( [ num2str( k / NumPrecursorRanges * 100, '%2.1f' ), '% of MS2 data has been converted. In ', FileID ] );
    end
    fclose( fidRead );
    disp( [ 'Finish converting ', FileID ] );
end
