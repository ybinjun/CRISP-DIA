function [ScoreLimit,FDR] = getScoreLimitToFDR(FianlScoreTarget,FianlScoreDecoy)
    ScoreLimit = [ 0.5:0.00001:1 ]';
    numScoreLimit = size( ScoreLimit, 1 );
    FDR = ones( numScoreLimit, 1 ) * NaN;
    numTarget = size( FianlScoreTarget, 1 );
    numDecoy = size( FianlScoreDecoy, 1 );
    for i = 1:numScoreLimit
        numScoreTargetPassLimit = sum( FianlScoreTarget>ScoreLimit( i ) );
        numScoreDecoyPassLimit = sum( FianlScoreDecoy>ScoreLimit( i ) );
        FDR( i ) = numScoreDecoyPassLimit / numDecoy / (numScoreTargetPassLimit / numTarget);
    end
end
