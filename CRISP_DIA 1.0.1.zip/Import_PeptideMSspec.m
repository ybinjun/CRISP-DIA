function [MyPeptideMSspec,PeptideSource] = Import_PeptideMSspec(FilePathName,SortMode)
    fidRead = fopen( FilePathName );
    if fidRead==-1
        error( [ 'Input data error: Can not find ', FilePathName, '.' ] );
    end
    curLine = fgetl( fidRead );
    if uint8( curLine( 1 ) )==255
        curLine = curLine( 2:end );
    end
    curLine = strtrim( curLine );
    curLine = strrep( curLine, ' ', '' );
    curLine = strrep( curLine, '_', '' );
    ColumnTitles = strsplit( curLine, ',' );
    FilePositionFirstData = ftell( fidRead );
    TempoDataCellForSort( :, 1 ) = ReadCSVFile( fidRead, '%s', 'PeptideModifiedSequence', ColumnTitles, FilePositionFirstData, true );
    TempoDataCellForSort( :, 2 ) = ReadCSVFile( fidRead, '%s', 'Trrecalibrated', ColumnTitles, FilePositionFirstData, true );
    TempoDataCellForSort( :, 3 ) = ReadCSVFile( fidRead, '%s', 'PrecursorCharge', ColumnTitles, FilePositionFirstData, true );
    TempoDataCellForSort( :, 4 ) = ReadCSVFile( fidRead, '%s', 'PrecursorMz', ColumnTitles, FilePositionFirstData, true );
    TempoDataCellForSort( :, 5 ) = ReadCSVFile( fidRead, '%s', 'FragmentCharge', ColumnTitles, FilePositionFirstData, true );
    TempoDataCellForSort( :, 6 ) = ReadCSVFile( fidRead, '%s', 'FragmentMz', ColumnTitles, FilePositionFirstData, true );
    TempoDataCellForSort( :, 7 ) = ReadCSVFile( fidRead, '%s', 'LibraryIntensity', ColumnTitles, FilePositionFirstData, true );
    Num = size( TempoDataCellForSort, 1 );
    NeutralLoss = ReadCSVFile( fidRead, '%s', 'FragmentNeutralLoss', ColumnTitles, FilePositionFirstData, false );
    if isempty( NeutralLoss )
        isemptyNeutralLoss = 1;
        NeutralLoss = ones( Num, 1 ) * NaN;
    else
        isemptyNeutralLoss = 0;
        TempoDataCellForSort( :, 8 ) = NeutralLoss;
    end
    PeptideSource = ReadCSVFile( fidRead, '%s', 'PeptideSource', ColumnTitles, FilePositionFirstData, false );
    if isempty( PeptideSource )
        isemptyPeptideSource = 1;
        PeptideSource = [  ];
    else
        isemptyPeptideSource = 0;
        TempoDataCellForSort( :, 9 - isemptyNeutralLoss ) = PeptideSource;
    end
    IonMobility = ReadCSVFile( fidRead, '%s', 'IonMobility', ColumnTitles, FilePositionFirstData, false );
    if isempty( IonMobility )
        isemptyIonMobility = 1;
        IonMobility = ones( Num, 1 ) * NaN;
    else
        isemptyIonMobility = 0;
        TempoDataCellForSort( :, 10 - isemptyNeutralLoss - isemptyPeptideSource ) = IonMobility;
    end
    fclose( fidRead );
    if strcmp( SortMode, 'PeptideModifiedSequence' )
        TempoDataCellForSort = sortrows( TempoDataCellForSort, [ 1, 3, -7 ] );
    elseif strcmp( SortMode, 'iRTValues' )
        TempoDataCellForSort = sortrows( TempoDataCellForSort, [ 2, -7 ] );
    else
    end
    PeptideModifiedSequence = TempoDataCellForSort( :, 1 );
    PeptideModifiedSequence = strrep( PeptideModifiedSequence, ':', '_' );
    PeptideModifiedSequence = strrep( PeptideModifiedSequence, '/', '_' );
    PeptideModifiedSequence = strrep( PeptideModifiedSequence, '\', '_' );
    PeptideModifiedSequence = strrep( PeptideModifiedSequence, '*', '_' );
    PeptideModifiedSequence = strrep( PeptideModifiedSequence, '?', '_' );
    PeptideModifiedSequence = strrep( PeptideModifiedSequence, '>', '_' );
    PeptideModifiedSequence = strrep( PeptideModifiedSequence, '<', '_' );
    PeptideModifiedSequence = strrep( PeptideModifiedSequence, '|', '_' );
    Tr_recalibrated = str2double( TempoDataCellForSort( :, 2 ) );
    PrecursorCharge = str2double( TempoDataCellForSort( :, 3 ) );
    PrecursorMz = str2double( TempoDataCellForSort( :, 4 ) );
    FragmentCharge = str2double( TempoDataCellForSort( :, 5 ) );
    FragmentMz = str2double( TempoDataCellForSort( :, 6 ) );
    LibraryIntensity = str2double( TempoDataCellForSort( :, 7 ) );
    if isemptyNeutralLoss==0
        NeutralLoss = str2double( TempoDataCellForSort( :, 8 ) );
        NeutralLoss( NeutralLoss==0 ) = NaN;
    end
    if isemptyPeptideSource==0
        PeptideSource = TempoDataCellForSort( :, 9 - isemptyNeutralLoss );
        PeptideSource = categorical( PeptideSource );
    end
    if isemptyIonMobility==0
        IonMobility = str2double( TempoDataCellForSort( :, 10 - isemptyNeutralLoss - isemptyPeptideSource ) );
    end
    IndexKeptPeptideSource = [  ];
    ii = 0;
    for i = 1:Num
        if i==1 || ~strcmp( PeptideModifiedSequence{ i }, PeptideModifiedSequence{ i - 1 } ) || PrecursorCharge( i )~=PrecursorCharge( i - 1 )
            ii = ii + 1;
            MyPeptideMSspec{ ii }.PeptideSequence = PeptideModifiedSequence{ i };
            IndexKeptPeptideSource = [ IndexKeptPeptideSource; i ];
            MyPeptideMSspec{ ii }.Tr_recalibrated = Tr_recalibrated( i );
            MyPeptideMSspec{ ii }.PrecursorCharge = PrecursorCharge( i );
            MyPeptideMSspec{ ii }.MSspec = [ PrecursorMz( i ), FragmentMz( i ), LibraryIntensity( i ) ];
            MyPeptideMSspec{ ii }.FragmentCharge = FragmentCharge( i );
            MyPeptideMSspec{ ii }.NeutralLoss = NeutralLoss( i );
            MyPeptideMSspec{ ii }.IonMobility = IonMobility( i );
        else
            MyPeptideMSspec{ ii }.MSspec = [ MyPeptideMSspec{ ii }.MSspec; PrecursorMz( i ), FragmentMz( i ), LibraryIntensity( i ) ];
            MyPeptideMSspec{ ii }.FragmentCharge = [ MyPeptideMSspec{ ii }.FragmentCharge; FragmentCharge( i ) ];
            MyPeptideMSspec{ ii }.NeutralLoss = [ MyPeptideMSspec{ ii }.NeutralLoss; NeutralLoss( i ) ];
        end
    end
    if isemptyPeptideSource==0
        PeptideSource = PeptideSource( IndexKeptPeptideSource );
    end
    NumPeptides = size( MyPeptideMSspec, 2 );
    for ii = 1:NumPeptides
        MatToRank = [ MyPeptideMSspec{ ii }.MSspec, MyPeptideMSspec{ ii }.FragmentCharge, MyPeptideMSspec{ ii }.NeutralLoss ];
        if sum( ~isnan( MatToRank( :, 3 ) ) )>0
            MatToRank = sortrows( MatToRank, -3 );
            MatToRank( isnan( MatToRank( :, 3 ) ), : ) = [  ];
        end
        [~,ia,~] = unique( MatToRank( :, 2 ) );
        ia = sort( ia );
        MatToRank = MatToRank( ia, : );
        MyPeptideMSspec{ ii }.MSspec = MatToRank( :, 1:3 );
        MyPeptideMSspec{ ii }.FragmentCharge = MatToRank( :, 4 );
        MyPeptideMSspec{ ii }.NeutralLoss = MatToRank( :, 5 );
    end
end
