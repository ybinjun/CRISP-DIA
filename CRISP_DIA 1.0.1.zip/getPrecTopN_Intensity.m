function [MyPeptideMSspec2,IndexKept] = getPrecTopN_Intensity(MyPeptideMSspec,TopN)
    NumPeptides = size( MyPeptideMSspec, 2 );
    IntensitySum = ones( NumPeptides, 1 ) * NaN;
    for ii = 1:NumPeptides
        IntensitySum( ii ) = sum( MyPeptideMSspec{ ii }.MSspec( :, 3 ) );
    end
    [~,Index] = sort( IntensitySum, 'descend' );
    TopN = min( TopN, NumPeptides );
    IndexKept = Index( 1:TopN );
    MyPeptideMSspec2 = MyPeptideMSspec( IndexKept );
end
