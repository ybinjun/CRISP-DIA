function [ProteinRatio,numPrecursorsAll,sumScorePrecsUsed,IndexProteinName,minFinalScoreLimit,PrecAreaUsed_ProtSum] = Quant_Prot_From_Prec2(FianlRatios,FianlScoreTarget,FianlScoreDecoy,ProteinName,PresetedScoreLimit,FDR_PrecLimit,FDR_ProteinLimit,PrecAreaSamples,SampleInfo,UseBestPrecAreaForProt)
    TopN_Used = Inf;
    FianlScoreTarget( isnan( FianlScoreTarget ) ) = 0;
    if isnan( PresetedScoreLimit )
        FianlScoreDecoy( isnan( FianlScoreDecoy ) ) = 0;
        [ScoreLimit,FDR_Prec] = getScoreLimitToFDR( FianlScoreTarget, FianlScoreDecoy );
        FDR_Prec( isnan( FDR_Prec ) ) = 0;
    end
    NumRuns = size( PrecAreaSamples, 2 );
    NumPrecs = size( PrecAreaSamples, 1 );
    IndexPrecs = (1:NumPrecs)';
    ConditionID = SampleInfo( :, 1 );
    NumConditions = max( ConditionID );
    RunOrder = (1:NumRuns)';
    RunsForConditions = cell( NumConditions, 1 );
    for i = 1:NumConditions
        RunsForConditions{ i } = RunOrder( ConditionID==i );
    end
    PrecAreaSamplesOrig = PrecAreaSamples;
    MeanArea_Condition = ones( NumPrecs, NumConditions ) * NaN;
    for i = 1:NumConditions
        TempColumns = RunsForConditions{ i };
        MeanArea_Condition( :, i ) = mean( PrecAreaSamples( :, TempColumns ), 2, 'omitnan' );
        NumTempColumns = size( TempColumns, 1 );
        for j = 1:NumTempColumns
            TempIsNan = isnan( PrecAreaSamples( :, TempColumns( j ) ) );
            PrecAreaSamples( TempIsNan, TempColumns( j ) ) = MeanArea_Condition( TempIsNan, i );
        end
    end
    PrecAreaSamples = PrecAreaSamples ./ mean( PrecAreaSamples, 2, 'omitnan' );
    PrecAreaSamples = PrecAreaSamples .* FianlScoreTarget;
    HasNaN_Condition = (sum( isnan( MeanArea_Condition ), 2 )>0);
    IndexProteinName = unique( ProteinName );
    NumProtein = size( IndexProteinName, 1 );
    ProteinRatio = ones( NumProtein, 1 ) * NaN;
    numPrecursorsAll = ones( NumProtein, 1 ) * NaN;
    sumScorePrecsUsed = ones( NumProtein, 1 ) * NaN;
    if isnan( PresetedScoreLimit )
        minFDR_PrecLimit = min( [ FDR_PrecLimit, FDR_ProteinLimit ] );
        minFinalScoreLimit = ScoreLimit( find( FDR_Prec<minFDR_PrecLimit, 1 ) );
    else
        minFinalScoreLimit = PresetedScoreLimit;
    end
    PrecAreaUsed_ProtSum = ones( NumProtein, NumRuns ) * NaN;
    for iProtein = 1:NumProtein
        PrecsUsed = (ProteinName==IndexProteinName( iProtein ));
        numPrecursors = sum( PrecsUsed );
        if isnan( PresetedScoreLimit )
            FDR_PrecLimit = 1 - (1 - FDR_ProteinLimit) ^ (1 / numPrecursors);
            FinalScoreLimit = ScoreLimit( find( FDR_Prec<FDR_PrecLimit, 1 ) );
            FinalScoreLimit = max( [ FinalScoreLimit, minFinalScoreLimit ] );
        else
            FinalScoreLimit = PresetedScoreLimit;
        end
        PrecsUsedPassLimit = (FianlScoreTarget>=FinalScoreLimit) & PrecsUsed & ~HasNaN_Condition;
        numPrecursorsAll( iProtein ) = sum( PrecsUsedPassLimit );
        if numPrecursorsAll( iProtein )~=0
            [~,TempMaxIndex] = sort( FianlScoreTarget( PrecsUsedPassLimit ), 'descend' );
            IndexPrecsPass = IndexPrecs( PrecsUsedPassLimit );
            TempIndexPrecsPass = IndexPrecsPass( TempMaxIndex );
            TempIndexPrecsPassUsed = TempIndexPrecsPass( 1:min( [ TopN_Used, size( TempIndexPrecsPass, 1 ) ] ) );
            if UseBestPrecAreaForProt
                TempRatiosPass = FianlRatios( PrecsUsedPassLimit );
                TempRatiosPass = TempRatiosPass( TempMaxIndex );
                [~,TempIndex] = sort( TempRatiosPass, 'descend' );
                TempIndexPrecs = TempIndexPrecsPass( TempIndex );
                if mod( numPrecursorsAll( iProtein ), 2 )==1
                    TempIndexPrecsUsed = TempIndexPrecs( (numPrecursorsAll( iProtein ) + 1) / 2 );
                else
                    TempIndexPrecsUsed1 = TempIndexPrecs( numPrecursorsAll( iProtein ) / 2 );
                    TempIndexPrecsUsed2 = TempIndexPrecs( numPrecursorsAll( iProtein ) / 2 + 1 );
                    if FianlScoreTarget( TempIndexPrecsUsed1 )>FianlScoreTarget( TempIndexPrecsUsed2 )
                        TempIndexPrecsUsed = TempIndexPrecsUsed1;
                    else
                        TempIndexPrecsUsed = TempIndexPrecsUsed2;
                    end
                end
                PrecAreaUsed_ProtSum( iProtein, : ) = PrecAreaSamplesOrig( TempIndexPrecsUsed, : );
            else
                PrecAreaUsed = PrecAreaSamples( TempIndexPrecsPassUsed, : );
                PrecAreaUsed = sum( PrecAreaUsed, 1, 'omitnan' );
                PrecAreaUsed_ProtSum( iProtein, : ) = sum( PrecAreaUsed, 1, 'omitnan' );
            end
        else
            ProteinRatio( iProtein ) = NaN;
        end
        sumScorePrecsUsed( iProtein ) = sum( FianlScoreTarget( PrecsUsedPassLimit ) );
    end
    PrecAreaUsed_ConditionMean = ones( NumProtein, NumConditions ) * NaN;
    for i = 1:NumConditions
        TempColumns = RunsForConditions{ i };
        PrecAreaUsed_ConditionMean( :, i ) = mean( PrecAreaUsed_ProtSum( :, TempColumns ), 2, 'omitnan' );
    end
    ProteinRatio = ones( NumProtein, NumConditions - 1 ) * NaN;
    for i = 2:NumConditions
        ProteinRatio( :, i - 1 ) = PrecAreaUsed_ConditionMean( :, i ) ./ PrecAreaUsed_ConditionMean( :, 1 );
    end
end
