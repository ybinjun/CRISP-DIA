function [PrecursorRanges,PrecursorRangesRemoveBoundary,NumIonMobilityRangesPerIsolationWindow] = IonMobility2Matlab(directory,SampleFileName,SaveFilePath,Mz_RelativeDev_Max,IonMobility_Dev_Max,BaseLineIntensity)
    tdfFile = 'analysis.tdf';
    SaveFilePath = [ SaveFilePath, '\', SampleFileName ];
    [~,~] = mkdir( SaveFilePath );
    DiaFrameMsMsWindows = sqlite3( [ directory, '\', tdfFile ], 'SELECT * FROM DiaFrameMsMsWindows;' );
    numDiaFrameMsMsWindows = size( DiaFrameMsMsWindows, 2 );
    precursorMin = ones( numDiaFrameMsMsWindows, 1 ) * NaN;
    precursorMax = ones( numDiaFrameMsMsWindows, 1 ) * NaN;
    IsolationWindowsInfo = ones( numDiaFrameMsMsWindows, 4 ) * NaN;
    for i = 1:numDiaFrameMsMsWindows
        IsolationOffset = DiaFrameMsMsWindows( i ).IsolationWidth / 2;
        precursorMin( i ) = DiaFrameMsMsWindows( i ).IsolationMz - IsolationOffset;
        precursorMax( i ) = DiaFrameMsMsWindows( i ).IsolationMz + IsolationOffset;
        IsolationWindowsInfo( i, 1 ) = DiaFrameMsMsWindows( i ).WindowGroup;
        IsolationWindowsInfo( i, 2 ) = DiaFrameMsMsWindows( i ).ScanNumBegin;
        IsolationWindowsInfo( i, 3 ) = DiaFrameMsMsWindows( i ).ScanNumEnd;
        IsolationWindowsInfo( i, 4 ) = DiaFrameMsMsWindows( i ).CollisionEnergy;
    end
    [precursorMin,I] = sort( precursorMin );
    precursorMax = precursorMax( I );
    IsolationWindowsInfo = IsolationWindowsInfo( I, : );
    PrecursorRanges( 1, : ) = [ precursorMin( 1 ), precursorMax( 1 ) ];
    IsolationInfo{ 1 } = IsolationWindowsInfo( 1, : );
    for i = 2:numDiaFrameMsMsWindows
        if PrecursorRanges( end, 1 )==precursorMin( i ) && PrecursorRanges( end, 2 )==precursorMax( i )
            IsolationInfo{ end } = [ IsolationInfo{ end }; IsolationWindowsInfo( i, : ) ];
        else
            PrecursorRanges( end + 1, : ) = [ precursorMin( i ), precursorMax( i ) ];
            IsolationInfo{ end + 1 } = IsolationWindowsInfo( i, : );
        end
    end
    NumPrecursorRanges = size( PrecursorRanges, 1 );
    NumIonMobilityRangesPerIsolationWindow = ones( NumPrecursorRanges, 1 ) * NaN;
    for k = 1:NumPrecursorRanges
        NumIonMobilityRangesPerIsolationWindow( k ) = size( IsolationInfo{ k }, 1 );
        if ~(NumIonMobilityRangesPerIsolationWindow( k )==1 || NumIonMobilityRangesPerIsolationWindow( k )==2)
            error( 'The combination of isolation window and ion mobility is not recognized.' )
        end
    end
    PrecursorRangesRemoveBoundary( 1, 1 ) = PrecursorRanges( 1, 1 );
    for k = 1:NumPrecursorRanges - 1
        if PrecursorRanges( k, 2 )>PrecursorRanges( k + 1, 1 )
            PrecursorRangesRemoveBoundary( k, 2 ) = (PrecursorRanges( k, 2 ) + PrecursorRanges( k + 1, 1 )) / 2;
            PrecursorRangesRemoveBoundary( k + 1, 1 ) = PrecursorRangesRemoveBoundary( k, 2 );
        else
            PrecursorRangesRemoveBoundary( k, 2 ) = PrecursorRanges( k, 2 );
            PrecursorRangesRemoveBoundary( k + 1, 1 ) = PrecursorRanges( k + 1, 1 );
        end
    end
    PrecursorRangesRemoveBoundary( NumPrecursorRanges, 2 ) = PrecursorRanges( NumPrecursorRanges, 2 );
    DiaFrameMsMsInfo = sqlite3( [ directory, '\', tdfFile ], 'SELECT * FROM DiaFrameMsMsInfo;' );
    numDiaFrameMsMsInfo = size( DiaFrameMsMsInfo, 2 );
    Frame2WindowGroup = ones( numDiaFrameMsMsInfo, 2 );
    for i = 1:numDiaFrameMsMsInfo
        Frame2WindowGroup( i, 1 ) = DiaFrameMsMsInfo( i ).Frame;
        Frame2WindowGroup( i, 2 ) = DiaFrameMsMsInfo( i ).WindowGroup;
    end
    FramesInfo = sqlite3( [ directory, '\', tdfFile ], 'SELECT Id, Time, MsMsType, NumScans FROM frames;' );
    numFramesInfo = size( FramesInfo, 2 );
    Frames_RT = ones( numFramesInfo, 2 );
    for i = 1:numFramesInfo
        Frames_RT( i, 1 ) = FramesInfo( i ).Id;
        Frames_RT( i, 2 ) = FramesInfo( i ).Time;
        Frames_RT( i, 3 ) = FramesInfo( i ).MsMsType;
        Frames_RT( i, 4 ) = FramesInfo( i ).NumScans;
    end
    for i = 1:NumPrecursorRanges
        IsUsedFrames = zeros( size( Frame2WindowGroup, 1 ), 1 );
        UsedScans = ones( size( Frame2WindowGroup, 1 ), 2 ) * NaN;
        for j = 1:size( IsolationInfo{ i }, 1 )
            UsedWindowGroup = IsolationInfo{ i }( j, 1 );
            IsUsedFrames_Temp = (Frame2WindowGroup( :, 2 )==UsedWindowGroup);
            UsedScans( IsUsedFrames_Temp, 1 ) = IsolationInfo{ i }( j, 2 );
            UsedScans( IsUsedFrames_Temp, 2 ) = IsolationInfo{ i }( j, 3 );
            IsUsedFrames = IsUsedFrames | IsUsedFrames_Temp;
        end
        UsedFrames = Frame2WindowGroup( IsUsedFrames, 1 );
        UsedScans = UsedScans( IsUsedFrames, : );
        [MySubMS,NumPeakApexes] = getTIMSdata2DpeaksParfor( directory, UsedFrames, UsedScans, Mz_RelativeDev_Max, IonMobility_Dev_Max, BaseLineIntensity );
        FrameRTs = Frames_RT( UsedFrames, 2 ) / 60;
        SubFileName = [ num2str( PrecursorRanges( i, 1 ), '%4.3f' ), '-', num2str( PrecursorRanges( i, 2 ), '%4.3f' ), '.mat' ];
        parsave( [ SaveFilePath, '\', SubFileName ], MySubMS, FrameRTs, NumPeakApexes );
        disp( [ num2str( i / NumPrecursorRanges * 100, '%2.1f' ), '% of MS2 data has been converted. In ', SampleFileName ] );
    end
end
function parsave(fname,MySubMS,FrameRTs,NumPeakApexes)
    Info = whos( 'MySubMS' );
    if Info.bytes<2147483648
        save( fname, 'MySubMS', 'FrameRTs', 'NumPeakApexes', '-v7' );
    else
        save( fname, 'MySubMS', 'FrameRTs', 'NumPeakApexes', '-v7.3' );
    end
end
