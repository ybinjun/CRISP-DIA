function NormalizeCoeff = getTIC_Sum_2Dpeaks(RawDataPositionList,PrecursorRanges)
    NumSamples = size( RawDataPositionList, 2 );
    SumInSample = zeros( NumSamples, 1 );
    for SampleIndex = 1:NumSamples
        loadFilePath = RawDataPositionList{ SampleIndex }( 1:length( RawDataPositionList{ SampleIndex } ) - 7 );
        NumPrecursorRanges = size( PrecursorRanges, 1 );
        parfor i = 1:NumPrecursorRanges
            subPrecursorRanges = PrecursorRanges( i, : );
            SubFileName = [ num2str( subPrecursorRanges( 1, 1 ), '%4.3f' ), '-', num2str( subPrecursorRanges( 1, 2 ), '%4.3f' ) ];
            LoadName = [ loadFilePath, SubFileName, '.mat' ];
            Tempo = load( LoadName, 'MySubMS' );
            MyMS = Tempo.MySubMS;
            Tempo = [  ];
            MyMS = cell2mat( MyMS );
            SumInDIAWindow( i ) = sum( MyMS( :, 3 ) );
        end
        SumInSample( SampleIndex ) = sum( SumInDIAWindow );
    end
    NormalizeCoeff = mean( SumInSample ) ./ SumInSample;
end
