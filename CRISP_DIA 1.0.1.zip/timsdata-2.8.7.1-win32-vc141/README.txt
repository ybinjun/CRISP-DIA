
This is tdf-sdk (version 2.8.x), shared libraries and examples for accessing mass-spectrometry data 
in tdf (tims data) format stored by Bruker timsTOF instruments.

This software uses Intel(R) Math Kernel Library
(http://www.intel.com/software/products/mkl) and other third-party software. A full list
of their licenses can be found in the file THIRD-PARTY-LICENSE-README.txt.

