function NormalizeCoeff = getTIC_Sum(RawDataPositionList,PrecursorRanges)
    NumSamples = size( RawDataPositionList, 2 );
    SumInSample = zeros( NumSamples, 1 );
    for SampleIndex = 1:NumSamples
        loadFilePath = RawDataPositionList{ SampleIndex }( 1:length( RawDataPositionList{ SampleIndex } ) - 7 );
        NumPrecursorRanges = size( PrecursorRanges, 1 );
        parfor i = 1:NumPrecursorRanges
            subPrecursorRanges = PrecursorRanges( i, : );
            SubFileName = [ num2str( subPrecursorRanges( 1, 1 ), '%4.3f' ), '-', num2str( subPrecursorRanges( 1, 2 ), '%4.3f' ) ];
            LoadName = [ loadFilePath, SubFileName, '.mat' ];
            Tempo = load( LoadName, 'subMyMS' );
            MyMS = Tempo.subMyMS;
            Tempo = [  ];
            NumScans = size( MyMS, 2 );
            SumInScan = [  ];
            for ii = 1:NumScans
                SumInScan( ii ) = sum( MyMS{ ii }.Data( :, 2 ) );
            end
            SumInDIAWindow( i ) = sum( SumInScan );
        end
        SumInSample( SampleIndex ) = sum( SumInDIAWindow );
    end
    NormalizeCoeff = mean( SumInSample ) ./ SumInSample;
end
