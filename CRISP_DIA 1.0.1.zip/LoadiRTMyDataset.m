function iRTMyDatasetAll = LoadiRTMyDataset(MyPeptideMSspec,NumSamples,FilePath)
    NumPeptides = size( MyPeptideMSspec, 2 );
    iRTMyDatasetAll = cell( NumSamples, NumPeptides );
    for k = 1:NumPeptides
        FileName = [ num2str( MyPeptideMSspec{ k }.MSspec( 1, 1 ), '%4.0f' ), MyPeptideMSspec{ k }.PeptideSequence ];
        SaveName = [ FilePath, FileName, '.mat' ];
        load( SaveName, 'MyDatasetAll' );
        iRTMyDatasetAll( :, k ) = MyDatasetAll;
    end
end
