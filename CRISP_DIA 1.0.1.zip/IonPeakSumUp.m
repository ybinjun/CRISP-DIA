function [NewPeakListSum,NewProductIonAreas,NewIonKept,NewMzErrorPPM2,NewRankIndexAll,NewIonMobilityAvg] = IonPeakSumUp(IonPeakListSelected,MyDataset,RefmzProduct,iRTMeanMzErrorPPM_i,MzErrorLimitPPM)
    if isempty( IonPeakListSelected ) || sum( sum( sum( ~isnan( IonPeakListSelected ) ) ) )==0
        NewPeakListSum = [  ];
        NewProductIonAreas = [  ];
        NewIonKept = [  ];
        NewMzErrorPPM2 = [  ];
        NewRankIndexAll = [  ];
        NewIonMobilityAvg = [  ];
        return
    else
        NumPeaks = size( IonPeakListSelected, 3 );
    end
    NumTransitions = size( IonPeakListSelected, 1 );
    PeakListSum = [  ];
    ProductIonAreas = ones( NumPeaks, NumTransitions ) * NaN;
    IonKept = zeros( NumPeaks, NumTransitions );
    MzErrorPPM2 = ones( NumPeaks, NumTransitions ) * NaN;
    RankIndexAll = ones( NumPeaks, NumTransitions ) * NaN;
    IonMobilityAvg = ones( NumPeaks, NumTransitions ) * NaN;
    MaxNumPoints = 3;
    MaxNum = size( MyDataset{ 1 }.Data, 1 );
    for k = 1:NumPeaks
        MedianApexPoint = round( median( IonPeakListSelected( :, 4, k ), 'omitnan' ) );
        MedianPeakStartPoint = round( median( IonPeakListSelected( :, 5, k ), 'omitnan' ) );
        MedianPeakEndPoint = round( median( IonPeakListSelected( :, 6, k ), 'omitnan' ) );
        if MedianApexPoint - MedianPeakStartPoint>MaxNumPoints
            MedianPeakStartPoint = max( [ MedianApexPoint - MaxNumPoints, 1 ] );
        end
        if MedianPeakEndPoint - MedianApexPoint>MaxNumPoints
            MedianPeakEndPoint = min( [ MedianApexPoint + MaxNumPoints, MaxNum ] );
        end
        maxSignal = 0;
        TempomaxSignal = 0;
        if isnan( MedianApexPoint )
            RetentionTime = NaN;
            PeakStartTime = NaN;
            PeakEndTime = NaN;
            Area = NaN;
            maxSignal = NaN;
        else
            RetentionTime = MyDataset{ 1 }.Data( MedianApexPoint, 1 );
            PeakStartTime = MyDataset{ 1 }.Data( MedianPeakStartPoint, 1 );
            PeakEndTime = MyDataset{ 1 }.Data( MedianPeakEndPoint, 1 );
            for j = 1:NumTransitions
                if ~isnan( IonPeakListSelected( j, 1, k ) )
                    [ProductIonAreas( k, j ),IonMobilityAvgTemp] = PeakIntegrate( MyDataset{ j }.Data( :, 1 ), MyDataset{ j }.Data( :, 3:end ), PeakStartTime, PeakEndTime );
                    if ProductIonAreas( k, j )>0
                        IonKept( k, j ) = 1;
                        TempomaxSignal = max( MyDataset{ j }.Data( MedianPeakStartPoint:MedianPeakEndPoint, 3 ) );
                        maxSignal = max( maxSignal, TempomaxSignal );
                        TempoApexMz = (MyDataset{ j }.Data( MedianApexPoint, 2 ));
                        MzErrorPPM2( k, j ) = abs( (TempoApexMz - RefmzProduct( j )) / RefmzProduct( j ) * 10 ^ 6 - iRTMeanMzErrorPPM_i );
                        IonMobilityAvg( k, j ) = IonMobilityAvgTemp;
                    else
                        IonPeakListSelected( j, :, k ) = NaN;
                    end
                end
            end
            Area = sum( ProductIonAreas( k, : ), 'omitnan' );
        end
        MzErrorPPM2( k, MzErrorPPM2( k, : )>MzErrorLimitPPM ) = MzErrorLimitPPM;
        MzErrorPPM = median( MzErrorPPM2( k, : ), 'omitnan' );
        ApexPoints = IonPeakListSelected( :, 4, k );
        ApexPoints( IonKept( k, : )'==0 ) = NaN;
        RankIndex = getRankIndex( MedianApexPoint, MedianPeakStartPoint, MedianPeakEndPoint, ApexPoints, MyDataset );
        ProfileSimilarity = mean( RankIndex, 'omitnan' );
        RankIndexAll( k, : ) = RankIndex';
        PeakListSum( k, : ) = [ RetentionTime, PeakStartTime, PeakEndTime, MedianApexPoint, MedianPeakStartPoint, MedianPeakEndPoint, maxSignal, Area, MzErrorPPM, ProfileSimilarity ];
    end
    NewPeakListSum = [  ];
    NewProductIonAreas = [  ];
    NewIonKept = [  ];
    NewMzErrorPPM2 = [  ];
    NewRankIndexAll = [  ];
    NewIonMobilityAvg = [  ];
    i = 1;
    for k = 1:NumPeaks
        if ~isnan( PeakListSum( k, 1 ) )
            NewPeakListSum( i, : ) = PeakListSum( k, : );
            NewProductIonAreas( i, : ) = ProductIonAreas( k, : );
            NewIonKept( i, : ) = IonKept( k, : );
            NewMzErrorPPM2( i, : ) = MzErrorPPM2( k, : );
            NewRankIndexAll( i, : ) = RankIndexAll( k, : );
            NewIonMobilityAvg( i, : ) = IonMobilityAvg( k, : );
            i = i + 1;
        end
    end
    PeakListSum = NewPeakListSum;
    ProductIonAreas = NewProductIonAreas;
    IonKept = NewIonKept;
    MzErrorPPM2 = NewMzErrorPPM2;
    RankIndexAll = NewRankIndexAll;
    IonMobilityAvg = NewIonMobilityAvg;
    NumPeaks = size( PeakListSum, 1 );
    Repeated = zeros( NumPeaks, 1 );
    for p = 1:NumPeaks
        for pp = p + 1:NumPeaks
            if all( IonKept( p, : )==IonKept( pp, : ) ) && IsEqual( PeakListSum( p, : ), PeakListSum( pp, : ) )
                Repeated( p ) = 1;
                break
            end
        end
    end
    NewPeakListSum = [  ];
    NewProductIonAreas = [  ];
    NewIonKept = [  ];
    NewMzErrorPPM2 = [  ];
    NewRankIndexAll = [  ];
    NewIonMobilityAvg = [  ];
    i = 1;
    for k = 1:NumPeaks
        if Repeated( k )~=1
            NewPeakListSum( i, : ) = PeakListSum( k, : );
            NewProductIonAreas( i, : ) = ProductIonAreas( k, : );
            NewIonKept( i, : ) = IonKept( k, : );
            NewMzErrorPPM2( i, : ) = MzErrorPPM2( k, : );
            NewRankIndexAll( i, : ) = RankIndexAll( k, : );
            NewIonMobilityAvg( i, : ) = IonMobilityAvg( k, : );
            i = i + 1;
        end
    end
end
