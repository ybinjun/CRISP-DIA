function MS2DataExtractTrans(MyPeptideMSspec,NumSamples,FilePath,PrecursorRanges,inPrecursorRanges)
    NumPrecursorRanges = size( PrecursorRanges, 1 );
    NumPeptides = size( MyPeptideMSspec, 2 );
    parfor i = 1:NumPrecursorRanges
        inPrecursorRangesCurrent = inPrecursorRanges( i, : );
        if sum( inPrecursorRangesCurrent )==0
            continue
        end
        subPrecursorRanges = PrecursorRanges( i, : );
        NumPeptidesCurrent = sum( inPrecursorRangesCurrent );
        MyDatasetToSaveAll = cell( NumSamples, NumPeptidesCurrent );
        for SampleIndex = 1:NumSamples
            SubFileName = [ num2str( subPrecursorRanges( 1, 1 ), '%4.3f' ), '-', num2str( subPrecursorRanges( 1, 2 ), '%4.3f' ), 'Sample', num2str( SampleIndex, '%03d' ), '.mat' ];
            Tempo = load( [ FilePath, SubFileName ], 'MyDatasetToSave' );
            delete( [ FilePath, SubFileName ] );
            MyDatasetToSaveAll( SampleIndex, : ) = Tempo.MyDatasetToSave;
        end
        q = 1;
        for k = 1:NumPeptides
            if inPrecursorRangesCurrent( k )~=0
                if isempty( MyPeptideMSspec{ k }.MSspec )
                    q = q + 1;
                    continue
                end
                MyDatasetAll = MyDatasetToSaveAll( :, q );
                q = q + 1;
                FileName = [ num2str( MyPeptideMSspec{ k }.MSspec( 1, 1 ), '%4.0f' ), MyPeptideMSspec{ k }.PeptideSequence ];
                SaveName = [ FilePath, FileName, '.mat' ];
                parsave( SaveName, 'MyDatasetAll', MyDatasetAll );
            end
        end
    end
end
function parsave(fname,x,MyDatasetAll)
    save( fname, x )
end
