function PeakList = PeakDetect(X1,PeakMaxWidthCoeff,PeakMinLimit,RefmzProduct,iRTMeanMzErrorPPM_i,MzErrorLimitPPM)
    X1_Orig = X1;
    IndexPeak = 1;
    TotalNumPoints = size( X1, 1 );
    minSignal = median( X1( :, 3 ), 'omitnan' );
    PeakMinLimit = max( [ minSignal, PeakMinLimit ] );
    [maxSignal,maxN] = max( X1( :, 3 ) );
    CoeffPeakChange = 0;
    PeakList = [  ];
    while maxSignal>PeakMinLimit
        PeakBoundarySignalLimit = (maxSignal - minSignal) * 0.1 + minSignal;
        iStart = maxN;
        PeakChangeLimit = (maxSignal - minSignal) * CoeffPeakChange;
        iMinmal = maxN;
        while X1( iStart, 3 )>PeakBoundarySignalLimit
            if iStart>1
                iStart = iStart - 1;
            else
                break
            end
            if X1( iStart, 3 )<X1( iStart + 1, 3 )
                iMinmal = iStart;
            end
            Flag1 = X1( iStart, 3 )>X1( iStart + 1, 3 ) && X1( iStart + 1, 3 )>X1( iStart + 2, 3 ) && max( [ X1( iStart, 3 ) - X1( iStart + 1, 3 ), X1( iStart + 1, 3 ) - X1( iStart + 2, 3 ) ] )>PeakChangeLimit;
            Flag2 = X1( iStart, 3 )>X1( iStart + 1, 3 ) && X1( iStart, 3 )>X1( iStart + 2, 3 ) && min( [ X1( iStart, 3 ) - X1( iStart + 1, 3 ), X1( iStart, 3 ) - X1( iStart + 2, 3 ) ] )>PeakChangeLimit;
            if Flag1 || Flag2
                iStart = iMinmal;
                break
            end
        end
        iEnd = maxN;
        while X1( iEnd, 3 )>PeakBoundarySignalLimit
            if iEnd<TotalNumPoints
                iEnd = iEnd + 1;
            else
                break
            end
            if X1( iEnd, 3 )<X1( iEnd - 1, 3 )
                iMinmal = iEnd;
            end
            Flag1 = X1( iEnd, 3 )>X1( iEnd - 1, 3 ) && X1( iEnd - 1, 3 )>X1( iEnd - 2, 3 ) && max( [ X1( iEnd, 3 ) - X1( iEnd - 1, 3 ), X1( iEnd - 1, 3 ) - X1( iEnd - 2, 3 ) ] )>PeakChangeLimit;
            Flag2 = X1( iEnd, 3 )>X1( iEnd - 1, 3 ) && X1( iEnd, 3 )>X1( iEnd - 2, 3 ) && min( [ X1( iEnd, 3 ) - X1( iEnd - 1, 3 ), X1( iEnd, 3 ) - X1( iEnd - 2, 3 ) ] )>PeakChangeLimit;
            if Flag1 || Flag2
                iEnd = iMinmal;
                break
            end
        end
        iFrontDec = iStart;
        while X1( iFrontDec, 3 )<X1( iFrontDec + 1, 3 )
            if iFrontDec>1
                iFrontDec = iFrontDec - 1;
            else
                iFrontDec = 0;
                break
            end
        end
        if iFrontDec~=iStart
            iFrontDec = iFrontDec + 1;
        end
        iBackDec = iEnd;
        while X1( iBackDec, 3 )<X1( iBackDec - 1, 3 )
            if iBackDec<TotalNumPoints
                iBackDec = iBackDec + 1;
            else
                iBackDec = TotalNumPoints + 1;
                break
            end
        end
        if iBackDec~=iEnd
            iBackDec = iBackDec - 1;
        end
        if iStart==iEnd
            area = 0;
        else
            area = PeakIntegrate( X1_Orig( :, 1 ), X1_Orig( :, 3:end ), X1( iStart, 1 ), X1( iEnd, 1 ) );
        end
        PeakList( IndexPeak, : ) = [ X1( maxN, 1 ), X1( iStart, 1 ), X1( iEnd, 1 ), maxN, iStart, iEnd, maxSignal, area, NaN ];
        IndexPeak = IndexPeak + 1;
        X1( iFrontDec:iBackDec, 3 ) = minSignal;
        [maxSignal,maxN] = max( X1( :, 3 ) );
    end
end
