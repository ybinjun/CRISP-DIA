function inPrecursorRanges = get_inPrecursorRanges(PrecursorRanges,MyPeptideMSspec)
    NumPrecursorRanges = size( PrecursorRanges, 1 );
    NumPeptides = size( MyPeptideMSspec, 2 );
    Precursors = ones( 1, NumPeptides ) * NaN;
    for k = 1:NumPeptides
        Precursors( 1, k ) = MyPeptideMSspec{ k }.MSspec( 1, 1 );
    end
    inPrecursorRanges = zeros( NumPrecursorRanges, NumPeptides );
    for i = 1:NumPrecursorRanges
        inPrecursorRanges( i, : ) = (Precursors - PrecursorRanges( i, 1 )>=0) & (Precursors - PrecursorRanges( i, 2 )<=0);
    end
end
