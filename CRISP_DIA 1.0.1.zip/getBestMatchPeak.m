function [BestMatchRunID,BestMatchPeakID,BestMatchIonsKept,FianlScore] = getBestMatchPeak(AllPeakListSum,areaAllSample,IonKept,MzErrorPPM2,OriginalReferenceMS2,ScoreWeights,PrecursorDataPosition,Tr_PredSample,MzErrorLimitPPM,HalfExtractWindow,isLibFreeMode,IonMobilityAvg,IonMobilityReference,IonMobilityHalfWindow)
    NumSamples = size( areaAllSample, 2 );
    NumTransitions = size( OriginalReferenceMS2, 2 );
    ScoreWeights( 4 ) = 0;
    ScoreWeights( 10 ) = 0;
    ScoreWeights( 5 ) = 0;
    ScoreWeights( 3 ) = 0;
    if isLibFreeMode
        ScoreWeights( 2 ) = 0;
        ScoreWeights( 3 ) = 0;
        ScoreWeights( 7 ) = 0;
    end
    RunID = [  ];
    PeakID = [  ];
    for i = 1:NumSamples
        NumPeaks = size( AllPeakListSum{ i }, 1 );
        RunID = [ RunID; ones( NumPeaks, 1 ) * i ];
        PeakID = [ PeakID; (1:NumPeaks)' ];
        for j = 1:NumPeaks
            IsIonsKept{ i }( j, : ) = InterfereDetectOnePeak( AllPeakListSum{ i }( j, : ), areaAllSample{ i }( j, : ), OriginalReferenceMS2 );
            areaAllSample{ i }( j, ~IsIonsKept{ i }( j, : ) ) = NaN;
            AllPeakListSum{ i }( j, 8 ) = sum( areaAllSample{ i }( j, : ), 'omitnan' );
            MzErrorPPM2{ i }( j, ~IsIonsKept{ i }( j, : ) ) = NaN;
            AllPeakListSum{ i }( j, 9 ) = median( MzErrorPPM2{ i }( j, : ), 'omitnan' );
            IonMobilityAvg{ i }( j, ~IsIonsKept{ i }( j, : ) ) = NaN;
        end
    end
    AllPeakListSumOne = cell2mat( AllPeakListSum' );
    if isempty( AllPeakListSumOne )
        FianlScore = 0;
        BestMatchRunID = NaN;
        BestMatchPeakID = NaN;
        BestMatchIonsKept = NaN;
        return
    end
    areaAllSampleOne = cell2mat( areaAllSample' );
    PeakAreaAfterSelectIon = AllPeakListSumOne( :, 8 );
    logPeakAreaAfterSelectIon = log( PeakAreaAfterSelectIon );
    MaxlogPeakAreaAfterSelectIon = max( logPeakAreaAfterSelectIon( logPeakAreaAfterSelectIon~=-Inf ) );
    NumPeaksForSelect = size( AllPeakListSumOne, 1 );
    if isempty( MaxlogPeakAreaAfterSelectIon )
        ScoreIntensity = zeros( NumPeaksForSelect, 1 );
    else
        MinlogPeakAreaAfterSelectIon = min( logPeakAreaAfterSelectIon( logPeakAreaAfterSelectIon~=-Inf ) );
        if MaxlogPeakAreaAfterSelectIon==MinlogPeakAreaAfterSelectIon
            ScoreIntensity = ones( NumPeaksForSelect, 1 ) * 100;
        else
            ScoreIntensity = (logPeakAreaAfterSelectIon - MinlogPeakAreaAfterSelectIon) / (MaxlogPeakAreaAfterSelectIon - MinlogPeakAreaAfterSelectIon) * 100;
        end
    end
    ScoreIntensity( isinf( ScoreIntensity ) ) = 0;
    ScoreIntensity( isnan( ScoreIntensity ) ) = 0;
    if isempty( PrecursorDataPosition )
        ScoreWeights( 5 ) = 0;
        PrecursorPeakArea = ones( NumPeaksForSelect, 1 ) * NaN;
    else
        [PrecursorPeakArea,MyDatasetAllPrecursor] = getPrecursorPeakArea( PrecursorDataPosition, [  ], AllPeakListSum );
        PrecursorPeakArea = cell2mat( PrecursorPeakArea );
    end
    if sum( ~isnan( PrecursorPeakArea ) )==0
        ScoreIntensityPrecursor = zeros( NumPeaksForSelect, 1 ) * 100;
    else
        logPrecursorPeakArea = log( PrecursorPeakArea );
        MaxlogPrecursorPeakArea = max( logPrecursorPeakArea( logPrecursorPeakArea~=-Inf ) );
        if isempty( MaxlogPrecursorPeakArea )
            ScoreIntensityPrecursor = zeros( NumPeaksForSelect, 1 );
        else
            MinlogPrecursorPeakArea = min( logPrecursorPeakArea( logPrecursorPeakArea~=-Inf ) );
            if MaxlogPrecursorPeakArea==MinlogPrecursorPeakArea
                ScoreIntensityPrecursor = ones( NumPeaksForSelect, 1 ) * 100;
            else
                ScoreIntensityPrecursor = (logPrecursorPeakArea - MinlogPrecursorPeakArea) / (MaxlogPrecursorPeakArea - MinlogPrecursorPeakArea) * 100;
            end
        end
    end
    ScoreIntensityPrecursor( isinf( ScoreIntensityPrecursor ) ) = 0;
    ScoreIntensityPrecursor( isnan( ScoreIntensityPrecursor ) ) = 0;
    Tr_PredSampleOneColumn = Tr_PredSample( RunID );
    RTerror_AfterSelectIon = abs( AllPeakListSumOne( :, 1 ) - Tr_PredSampleOneColumn );
    ScoreRT_AfterSelectIon = max( 50, 100 - (RTerror_AfterSelectIon - 0) / (HalfExtractWindow - 0) * 50 );
    ScoreRT_AfterSelectIon( isnan( ScoreRT_AfterSelectIon ) ) = 0;
    NumIonsLeast = max( [ floor( NumTransitions / 3 ), 2 ] );
    NumIonsLeast = min( [ NumIonsLeast, 6 ] );
    ScoreNumIonsKept = ones( NumPeaksForSelect, 1 ) * NaN;
    CosDistAfterSelectIon = ones( NumPeaksForSelect, 1 ) * NaN;
    EuclideanDistAfterSelectIon = ones( NumPeaksForSelect, 1 ) * NaN;
    for k = 1:NumPeaksForSelect
        IsIonsKept_Current = ~isnan( areaAllSampleOne( k, : ) );
        PeakMS2_Current = areaAllSampleOne( k, IsIonsKept_Current );
        NumTransitions_Current = size( PeakMS2_Current, 2 );
        if ~isLibFreeMode
            ScaledPeakMS2 = PeakMS2_Current / sum( PeakMS2_Current );
            ReferenceMS2_Current = OriginalReferenceMS2( 2, IsIonsKept_Current );
            ScaledReferenceMS2 = ReferenceMS2_Current / sum( ReferenceMS2_Current );
            if NumTransitions_Current>=2
                CosDistAfterSelectIon( k ) = 1 - dot( ScaledReferenceMS2, ScaledPeakMS2 ) / norm( ScaledReferenceMS2 ) / norm( ScaledPeakMS2 );
                EuclideanDistAfterSelectIon( k ) = sqrt( sum( (ScaledPeakMS2 - ScaledReferenceMS2) .* (ScaledPeakMS2 - ScaledReferenceMS2) ) / (NumTransitions_Current - 1) );
            end
        end
        if NumTransitions_Current<NumIonsLeast
            ScoreNumIonsKept( k ) = 0;
        else
            ScoreNumIonsKept( k ) = (NumTransitions_Current - 1 + 1) / (min( [ NumTransitions, 15 ] ) - 1 + 1) * 100;
        end
    end
    ScoreNumIonsKept( ScoreNumIonsKept>100 ) = 100;
    MaxCosDistAfterSelectIon = 1;
    MinCosDistAfterSelectIon = 0;
    ScoreCosDistAfterSelectIon = (MaxCosDistAfterSelectIon - CosDistAfterSelectIon) / (MaxCosDistAfterSelectIon - MinCosDistAfterSelectIon) * 100;
    ScoreEuclideanDistAfterSelectIon = max( 0, ((0.3 - EuclideanDistAfterSelectIon) / (0.3 - 0)) * 100 );
    ScoreCosDistAfterSelectIon( isnan( ScoreCosDistAfterSelectIon ) ) = 0;
    ScoreEuclideanDistAfterSelectIon( isnan( ScoreEuclideanDistAfterSelectIon ) ) = 0;
    ScoreProfileSimilarity = max( 0, 1 - (AllPeakListSumOne( :, 10 ) - 1) * 0.2 ) * 100;
    MzErrorPPM = AllPeakListSumOne( :, 9 );
    MzErrorLimitPPM = 30;
    ScoreMzError = 100 - MzErrorPPM * 100 / MzErrorLimitPPM;
    ScoreMzError( MzErrorPPM>MzErrorLimitPPM ) = 0;
    IonMobilityAvgOne = cell2mat( IonMobilityAvg' );
    IonMobilityReferenceOneColumn = IonMobilityReference( :, RunID )';
    IonMobilityError = median( abs( IonMobilityAvgOne - IonMobilityReferenceOneColumn ), 2, 'omitnan' );
    ScoreIonMobilityError = (1 - IonMobilityError / IonMobilityHalfWindow) * 100;
    ScoreIonMobilityError( isnan( ScoreIonMobilityError ) ) = 0;
    ScoresNoUse = zeros( NumPeaksForSelect, 1 );
    ScoresToSave = [ ScoreIntensity, ScoreRT_AfterSelectIon, ScoreCosDistAfterSelectIon, ScoresNoUse, ScoreIntensityPrecursor, ScoreProfileSimilarity, ScoreEuclideanDistAfterSelectIon, ScoreNumIonsKept, ScoreMzError, ScoresNoUse, ScoreIonMobilityError ];
    if ~isLibFreeMode
        ScoresToSave( isnan( CosDistAfterSelectIon ) | ~(CosDistAfterSelectIon<=0.2), : ) = 0;
    end
    [FianlSelectedPeakIndex,FianlScore,~] = PeakGroupSeletct( ScoresToSave, ScoreWeights );
    BestMatchRunID = RunID( FianlSelectedPeakIndex );
    BestMatchPeakID = PeakID( FianlSelectedPeakIndex );
    BestMatchIonsKept = IsIonsKept{ BestMatchRunID }( BestMatchPeakID, : );
end
