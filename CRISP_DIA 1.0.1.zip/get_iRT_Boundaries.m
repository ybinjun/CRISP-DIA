function iRT_Boundaries = get_iRT_Boundaries(iRTtimes,iRTValues,MaxRetentionTime)
    medianRTs = median( iRTtimes, 1 );
    NumPeptides = size( iRTtimes, 2 );
    RegressCoeffs = regress( iRTValues', [ medianRTs', ones( NumPeptides, 1 ) ] );
    iRT_Boundaries = [ 0, [ 0, 1 ] * RegressCoeffs; MaxRetentionTime, [ MaxRetentionTime, 1 ] * RegressCoeffs ];
end
