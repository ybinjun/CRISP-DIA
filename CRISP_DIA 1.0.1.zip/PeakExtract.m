function PeakApexes = PeakExtract(AllInOneFrame,Mz_RelativeDev_Max,IonMobility_Dev_Max,BaseLineIntensity)
    Mz_RelativeDev_Max = Mz_RelativeDev_Max / 1000000;
    AllInOneFrame = sortrows( AllInOneFrame, [ 3, 2, 1 ], { 'descend', 'ascend', 'ascend' } );
    Num = size( AllInOneFrame, 1 );
    AllInOneFrame( :, 3 ) = AllInOneFrame( :, 3 ) - BaseLineIntensity;
    AllInOneFrame( AllInOneFrame( :, 3 )<0, 3 ) = 0;
    BaseLineIntensity = 0;
    Peaks( 1, : ) = [ AllInOneFrame( 1, 1 ), AllInOneFrame( 1, 2 ), AllInOneFrame( 1, 1 ), AllInOneFrame( 1, 1 ), AllInOneFrame( 1, 2 ), AllInOneFrame( 1, 2 ), AllInOneFrame( 1, 1 ) * Mz_RelativeDev_Max ];
    PeakDataLines{ 1 } = 1;
    for i = 2:Num
        if AllInOneFrame( i, 3 )<=BaseLineIntensity
            break
        end
        MzValue_Temp = AllInOneFrame( i, 1 );
        IonMobility_Temp = AllInOneFrame( i, 2 );
        MzDiff1 = MzValue_Temp - Peaks( :, 3 );
        MzDiff2 = Peaks( :, 4 ) - MzValue_Temp;
        IonMobilityDiff1 = IonMobility_Temp - Peaks( :, 5 );
        IonMobilityDiff2 = Peaks( :, 6 ) - IonMobility_Temp;
        NumPeaks = size( Peaks, 1 );
        isInPeak = 0;
        isInPeak = find( (MzDiff1>0) & (MzDiff2>0) & (IonMobilityDiff1>0) & (IonMobilityDiff2>0), 1, 'first' );
        if isempty( isInPeak )
            isInPeak = 0;
        end
        if isInPeak==0
            MzDiff1( MzDiff1>0 ) = 0;
            MzDiff1 = -MzDiff1;
            MzDiff2( MzDiff1>0 ) = 0;
            MzDiff2 = -MzDiff2;
            Mz_Devs = max( [ MzDiff1, MzDiff2 ], [  ], 2 );
            MzScore = 1 - Mz_Devs ./ Peaks( :, 7 );
            MzScore( MzScore<0 ) = 0;
            IonMobilityDiff1( IonMobilityDiff1>0 ) = 0;
            IonMobilityDiff1 = -IonMobilityDiff1;
            IonMobilityDiff2( IonMobilityDiff1>0 ) = 0;
            IonMobilityDiff2 = -IonMobilityDiff2;
            IonMobility_Devs = max( [ IonMobilityDiff1, IonMobilityDiff2 ], [  ], 2 );
            IonMobilityScore = 1 - IonMobility_Devs / IonMobility_Dev_Max;
            IonMobilityScore( IonMobilityScore<0 ) = 0;
            Score = MzScore .* IonMobilityScore;
            [maxScore,Index] = max( Score );
            if maxScore>0
                isInPeak = Index;
            end
        end
        if isInPeak==0
            Peaks( end + 1, : ) = [ MzValue_Temp, IonMobility_Temp, MzValue_Temp, MzValue_Temp, IonMobility_Temp, IonMobility_Temp, MzValue_Temp * Mz_RelativeDev_Max ];
            PeakDataLines{ end + 1 } = i;
        else
            Peaks( isInPeak, 3:6 ) = [ min( [ MzValue_Temp, Peaks( isInPeak, 3 ) ] ), max( [ MzValue_Temp, Peaks( isInPeak, 4 ) ] ), min( [ IonMobility_Temp, Peaks( isInPeak, 5 ) ] ), max( [ IonMobility_Temp, Peaks( isInPeak, 6 ) ] ) ];
            PeakDataLines{ isInPeak }( end + 1 ) = i;
        end
    end
    NumPeaks = size( Peaks, 1 );
    PeakApexes = ones( NumPeaks, 3 ) * NaN;
    for j = 1:NumPeaks
        PeakData = AllInOneFrame( PeakDataLines{ j }, : );
        SumIntensity = sum( PeakData( :, 3 ) );
        Mz_PeakApex = sum( PeakData( :, 1 ) .* PeakData( :, 3 ) ) / SumIntensity;
        IonMobility_PeakApex = sum( PeakData( :, 2 ) .* PeakData( :, 3 ) ) / SumIntensity;
        PeakApexes( j, : ) = [ Mz_PeakApex, IonMobility_PeakApex, SumIntensity ];
    end
end
