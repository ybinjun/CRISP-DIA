function [AllPeakListSum,areaAllSample,IonKept,MzErrorPPM2,IonMobilityAvg,RankIndexAll,FianlScore] = getMatchPeak2(AllPeakListSum,areaAllSample,IonKept,MzErrorPPM2,IonMobilityAvg,RankIndexAll,OriginalReferenceMS2,BestMatchRTAglined,TimeDeviationLimit,RTAglined,ScoreWeights,MzErrorLimitPPM,is_iRTClac,isLibFreeMode,IonMobilityReference,IonMobilityHalfWindow)
    NumColumns = size( AllPeakListSum, 2 );
    NumPeaks = size( AllPeakListSum, 1 );
    CosineLimit = 0;
    RTisOK = abs( RTAglined - BestMatchRTAglined )<=TimeDeviationLimit;
    NumIonKept = sum( IonKept, 2 );
    NumTransitions = size( OriginalReferenceMS2, 2 );
    AllPeakListSumOne = AllPeakListSum( RTisOK, : );
    if isempty( AllPeakListSumOne )
        AllPeakListSum = ones( 1, NumColumns ) * NaN;
        areaAllSample = ones( 1, NumTransitions ) * NaN;
        IonKept = zeros( 1, NumTransitions );
        MzErrorPPM2 = ones( 1, NumTransitions ) * NaN;
        IonMobilityAvg = ones( 1, NumTransitions ) * NaN;
        RankIndexAll = ones( 1, NumTransitions ) * NaN;
        FianlScore = 0;
        return
    end
    areaAllSampleOne = areaAllSample( RTisOK, : );
    IonKept = IonKept( RTisOK, : );
    MzErrorPPM2 = MzErrorPPM2( RTisOK, : );
    IonMobilityAvg = IonMobilityAvg( RTisOK, : );
    RankIndexAll = RankIndexAll( RTisOK, : );
    NumIonKept = NumIonKept( RTisOK, : );
    ScoreWeights( 4 ) = 0;
    ScoreWeights( 10 ) = 0;
    ScoreWeights( 2 ) = 0;
    ScoreWeights( 5 ) = 0;
    if ~is_iRTClac
        ScoreWeights( 1 ) = 0;
    end
    ScoreWeights( 3 ) = 0;
    if isLibFreeMode
        ScoreWeights( 2 ) = 0;
    end
    PeakAreaAfterSelectIon = sum( areaAllSampleOne, 2, 'omitnan' );
    logPeakAreaAfterSelectIon = log( PeakAreaAfterSelectIon );
    MaxlogPeakAreaAfterSelectIon = max( logPeakAreaAfterSelectIon( logPeakAreaAfterSelectIon~=-Inf ) );
    NumPeaksForSelect = size( AllPeakListSumOne, 1 );
    if isempty( MaxlogPeakAreaAfterSelectIon )
        ScoreIntensity = zeros( NumPeaksForSelect, 1 );
    else
        MinlogPeakAreaAfterSelectIon = min( logPeakAreaAfterSelectIon( logPeakAreaAfterSelectIon~=-Inf ) );
        if MaxlogPeakAreaAfterSelectIon==MinlogPeakAreaAfterSelectIon
            ScoreIntensity = ones( NumPeaksForSelect, 1 ) * 100;
        else
            ScoreIntensity = (logPeakAreaAfterSelectIon - MinlogPeakAreaAfterSelectIon) / (MaxlogPeakAreaAfterSelectIon - MinlogPeakAreaAfterSelectIon) * 100;
        end
    end
    ScoreIntensity( isinf( ScoreIntensity ) ) = 0;
    ScoreIntensity( isnan( ScoreIntensity ) ) = 0;
    PrecursorDataPosition = [  ];
    if isempty( PrecursorDataPosition )
        ScoreWeights( 5 ) = 0;
        PrecursorPeakArea = ones( NumPeaksForSelect, 1 ) * NaN;
    else
        [PrecursorPeakArea,MyDatasetAllPrecursor] = getPrecursorPeakArea( PrecursorDataPosition, [  ], AllPeakListSum );
        PrecursorPeakArea = cell2mat( PrecursorPeakArea );
    end
    if sum( ~isnan( PrecursorPeakArea ) )==0
        ScoreIntensityPrecursor = zeros( NumPeaksForSelect, 1 ) * 100;
    else
        logPrecursorPeakArea = log( PrecursorPeakArea );
        MaxlogPrecursorPeakArea = max( logPrecursorPeakArea( logPrecursorPeakArea~=-Inf ) );
        if isempty( MaxlogPrecursorPeakArea )
            ScoreIntensityPrecursor = zeros( NumPeaksForSelect, 1 );
        else
            MinlogPrecursorPeakArea = min( logPrecursorPeakArea( logPrecursorPeakArea~=-Inf ) );
            if MaxlogPrecursorPeakArea==MinlogPrecursorPeakArea
                ScoreIntensityPrecursor = ones( NumPeaksForSelect, 1 ) * 100;
            else
                ScoreIntensityPrecursor = (logPrecursorPeakArea - MinlogPrecursorPeakArea) / (MaxlogPrecursorPeakArea - MinlogPrecursorPeakArea) * 100;
            end
        end
    end
    ScoreIntensityPrecursor( isinf( ScoreIntensityPrecursor ) ) = 0;
    ScoreIntensityPrecursor( isnan( ScoreIntensityPrecursor ) ) = 0;
    ScoreRT_AfterSelectIon = zeros( NumPeaksForSelect, 1 );
    NumIonsLeast = max( [ floor( NumTransitions / 3 ), 2 ] );
    NumIonsLeast = min( [ NumIonsLeast, 4 ] );
    ScoreNumIonsKept = (NumIonKept - 1 + 1) / (min( [ NumTransitions, 15 ] ) - 1 + 1) * 100;
    ScoreNumIonsKept( ScoreNumIonsKept>100 ) = 100;
    ScoreNumIonsKept( NumIonKept<NumIonsLeast ) = 0;
    ScoreNumIonsKept( ScoreNumIonsKept<0 ) = 0;
    CosDistAfterSelectIon = ones( NumPeaksForSelect, 1 ) * NaN;
    EuclideanDistAfterSelectIon = ones( NumPeaksForSelect, 1 ) * NaN;
    for k = 1:NumPeaksForSelect
        IsIonsKept_Current = ~isnan( areaAllSampleOne( k, : ) );
        PeakMS2_Current = areaAllSampleOne( k, IsIonsKept_Current );
        ScaledPeakMS2 = PeakMS2_Current / sum( PeakMS2_Current );
        ReferenceMS2_Current = OriginalReferenceMS2( 2, IsIonsKept_Current );
        ScaledReferenceMS2 = ReferenceMS2_Current / sum( ReferenceMS2_Current );
        NumTransitions_Current = size( PeakMS2_Current, 2 );
        if NumTransitions_Current>=2
            CosDistAfterSelectIon( k ) = 1 - dot( ScaledReferenceMS2, ScaledPeakMS2 ) / norm( ScaledReferenceMS2 ) / norm( ScaledPeakMS2 );
            EuclideanDistAfterSelectIon( k ) = sqrt( sum( (ScaledPeakMS2 - ScaledReferenceMS2) .* (ScaledPeakMS2 - ScaledReferenceMS2) ) / (NumTransitions_Current - 1) );
        end
    end
    MaxCosDistAfterSelectIon = 1;
    MinCosDistAfterSelectIon = 0;
    ScoreCosDistAfterSelectIon = (MaxCosDistAfterSelectIon - CosDistAfterSelectIon) / (MaxCosDistAfterSelectIon - MinCosDistAfterSelectIon) * 100;
    ScoreEuclideanDistAfterSelectIon = max( 0, ((0.3 - EuclideanDistAfterSelectIon) / (0.3 - 0)) * 100 );
    ScoreCosDistAfterSelectIon( isnan( ScoreCosDistAfterSelectIon ) ) = 0;
    ScoreEuclideanDistAfterSelectIon( isnan( ScoreEuclideanDistAfterSelectIon ) ) = 0;
    ScoreCosDistAfterSelectIon( ScoreCosDistAfterSelectIon<CosineLimit * 100 ) = 0;
    ScoreProfileSimilarity = max( 0, 1 - (AllPeakListSumOne( :, 10 ) - 1) * 0.2 ) * 100;
    MzErrorPPM = median( MzErrorPPM2, 2, 'omitnan' );
    MzErrorLimitPPM = 30;
    ScoreMzError = 100 - MzErrorPPM * 100 / MzErrorLimitPPM;
    ScoreMzError( MzErrorPPM>MzErrorLimitPPM ) = 0;
    IonMobilityError = median( abs( IonMobilityAvg - IonMobilityReference ), 2, 'omitnan' );
    ScoreIonMobilityError = (1 - IonMobilityError / IonMobilityHalfWindow) * 100;
    ScoreIonMobilityError( isnan( ScoreIonMobilityError ) ) = 0;
    ScoresNoUse = zeros( NumPeaksForSelect, 1 );
    ScoresToSave = [ ScoreIntensity, ScoreRT_AfterSelectIon, ScoreCosDistAfterSelectIon, ScoresNoUse, ScoreIntensityPrecursor, ScoreProfileSimilarity, ScoreEuclideanDistAfterSelectIon, ScoreNumIonsKept, ScoreMzError, ScoresNoUse, ScoreIonMobilityError ];
    ScoresToSave( isnan( CosDistAfterSelectIon ) | ~(CosDistAfterSelectIon<=0.2), : ) = 0;
    [FianlSelectedPeakIndex,FianlScore,~] = PeakGroupSeletct( ScoresToSave, ScoreWeights );
    FianlScoreLimit = 0;
    if FianlScore<=FianlScoreLimit
        AllPeakListSum = ones( 1, NumColumns ) * NaN;
        areaAllSample = ones( 1, NumTransitions ) * NaN;
        IonKept = zeros( 1, NumTransitions );
        MzErrorPPM2 = ones( 1, NumTransitions ) * NaN;
        IonMobilityAvg = ones( 1, NumTransitions ) * NaN;
        RankIndexAll = ones( 1, NumTransitions ) * NaN;
    else
        AllPeakListSum = AllPeakListSumOne( FianlSelectedPeakIndex, : );
        areaAllSample = areaAllSampleOne( FianlSelectedPeakIndex, : );
        IonKept = IonKept( FianlSelectedPeakIndex, : );
        MzErrorPPM2 = MzErrorPPM2( FianlSelectedPeakIndex, : );
        IonMobilityAvg = IonMobilityAvg( FianlSelectedPeakIndex, : );
        RankIndexAll = RankIndexAll( FianlSelectedPeakIndex, : );
    end
end
