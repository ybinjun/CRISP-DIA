function [MySubMS,NumPeakApexes] = getTIMSdata2DpeaksParfor(directory,UsedFrames,UsedScans,Mz_RelativeDev_Max,IonMobility_Dev_Max,BaseLineIntensity)
    numFramesId = size( UsedFrames, 1 );
    poolobj = gcp( 'nocreate' );
    if isempty( poolobj )
        NumCPUs = feature( 'numcores' );
        parpool( NumCPUs, 'IdleTimeout', 240 );
    else
        NumCPUs = poolobj.NumWorkers;
    end
    for i = 1:NumCPUs
        UsedFramesParfor{ i } = UsedFrames( i:NumCPUs:end );
        UsedScansParfor{ i } = UsedScans( i:NumCPUs:end, : );
    end
    parfor i = 1:NumCPUs
        warning( 'off' )
        UsedFrames = UsedFramesParfor{ i };
        UsedScans = UsedScansParfor{ i };
        numFramesIdParfor{ i } = size( UsedFrames, 1 );
        if isempty( UsedFrames )
            PeakApexes{ i, 1 } = {  };
        else
            loadlibrary( 'timsdata.dll', 'timsdata.h' );
            pFile = calllib( 'timsdata', 'tims_open', directory, 0 );
            if pFile==0
                error( [ directory, ' File open fail.' ] );
            end
            BufferNumUint32 = 1000000;
            p_buf_data = libpointer( 'voidPtr', uint32( zeros( 1, BufferNumUint32 ) ) );
            for k = 1:numFramesIdParfor{ i }
                [Num,p_buf_dataOut] = calllib( 'timsdata', 'tims_read_scans_v2', pFile, UsedFrames( k ), UsedScans( k, 1 ), UsedScans( k, 2 ), p_buf_data, BufferNumUint32 * 4 );
                if Num==0
                    error( 'tims_read_scans_v2 function error!' );
                end
                if Num / 4>BufferNumUint32
                    BufferNumUint32 = Num / 4;
                    p_buf_data = libpointer( 'voidPtr', uint32( zeros( 1, BufferNumUint32 ) ) );
                    [~,p_buf_dataOut] = calllib( 'timsdata', 'tims_read_scans_v2', pFile, UsedFrames( k ), UsedScans( k, 1 ), UsedScans( k, 2 ), p_buf_data, BufferNumUint32 * 4 );
                end
                setdatatype( p_buf_dataOut, 'uint32Ptr', 1, BufferNumUint32 );
                DataOut = p_buf_dataOut.Value';
                p_double_index = libpointer( 'doublePtr', DataOut' );
                p_double_mz = libpointer( 'doublePtr', zeros( 1, BufferNumUint32 ) );
                status = calllib( 'timsdata', 'tims_index_to_mz', pFile, UsedFrames( k ), p_double_index, p_double_mz, uint32( BufferNumUint32 ) );
                if status==0
                    error( 'tims_index_to_mz function error!' );
                end
                DataOutMz = p_double_mz.value';
                NumScans = UsedScans( k, 2 ) - UsedScans( k, 1 );
                NumPeaksInEachScan = DataOut( 1:NumScans );
                CurrentPos = NumScans;
                p_double_scans = libpointer( 'doublePtr', (UsedScans( k, 1 ):1:UsedScans( k, 2 ) - 1) );
                p_double_oneoverk0 = libpointer( 'doublePtr', zeros( 1, NumScans ) );
                status = calllib( 'timsdata', 'tims_scannum_to_oneoverk0', pFile, UsedFrames( k ), p_double_scans, p_double_oneoverk0, uint32( NumScans ) );
                if status==0
                    error( 'tims_scannum_to_oneoverk0 function error!' );
                end
                oneoverk0 = p_double_oneoverk0.value';
                AllInOneFrame = cell( NumScans, 1 );
                for m = 1:NumScans
                    Temp = DataOutMz( CurrentPos + 1:CurrentPos + NumPeaksInEachScan( m ) );
                    Temp( :, 2 ) = ones( size( Temp, 1 ), 1 ) * oneoverk0( m );
                    CurrentPos = CurrentPos + NumPeaksInEachScan( m );
                    Temp( :, 3 ) = DataOut( CurrentPos + 1:CurrentPos + NumPeaksInEachScan( m ) );
                    CurrentPos = CurrentPos + NumPeaksInEachScan( m );
                    AllInOneFrame{ m, 1 } = Temp;
                end
                AllInOneFrame = cell2mat( AllInOneFrame );
                PeakApexes{ i, 1 }{ k, 1 } = PeakExtract( AllInOneFrame, Mz_RelativeDev_Max, IonMobility_Dev_Max, BaseLineIntensity );
            end
            calllib( 'timsdata', 'tims_close', pFile );
        end
        warning( 'on' );
    end
    MySubMS = cell( numFramesId, 1 );
    NumPeakApexes = ones( numFramesId, 1 ) * NaN;
    q = 0;
    k = 0;
    while q<=numFramesId
        k = k + 1;
        for i = 1:NumCPUs
            q = q + 1;
            if q>numFramesId
                break
            end
            MySubMS{ q } = PeakApexes{ i, 1 }{ k, 1 };
            NumPeakApexes( q ) = size( PeakApexes{ i, 1 }{ k, 1 }, 1 );
        end
    end
end
