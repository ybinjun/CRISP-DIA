function Tr_PredSample = TrPredInterp(iRTValues,iRTtimes,iRTValue_x,iRT_Boundaries)
    NumSamples = size( iRTtimes, 1 );
    Tr_PredSample = interp1( [ iRT_Boundaries( 1, 2 ), iRTValues, iRT_Boundaries( 2, 2 ) ]', [ ones( NumSamples, 1 ) * iRT_Boundaries( 1, 1 ), iRTtimes, ones( NumSamples, 1 ) * iRT_Boundaries( 2, 1 ) ]', iRTValue_x, 'linear' );
    Tr_PredSample = Tr_PredSample';
end
