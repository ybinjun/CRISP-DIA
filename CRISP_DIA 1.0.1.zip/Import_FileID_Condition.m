function [FileID,ConditionNameUnique,SampleInfo] = Import_FileID_Condition(FilePathName)
    fidRead = fopen( FilePathName );
    if fidRead==-1
        error( 'Input data error: Can not find FileID_Condition.csv.' );
    end
    curLine = fgetl( fidRead );
    if uint8( curLine( 1 ) )==255
        curLine = curLine( 2:end );
    end
    curLine = strtrim( curLine );
    curLine = strrep( curLine, ' ', '' );
    curLine = strrep( curLine, '_', '' );
    ColumnTitles = strsplit( curLine, ',' );
    FilePositionFirstData = ftell( fidRead );
    FileID = ReadCSVFile( fidRead, '%s', 'FileID', ColumnTitles, FilePositionFirstData, true );
    Condition = ReadCSVFile( fidRead, '%C', 'Condition', ColumnTitles, FilePositionFirstData, true );
    fclose( fidRead );
    NumSamples = size( FileID, 1 );
    for i = 1:NumSamples
        if size( FileID{ i }, 2 )>5 && strcmpi( FileID{ i }( end - 4:end ), '.mzML' )
            FileID{ i } = FileID{ i }( 1:end - 5 );
        end
    end
    ConditionNameUnique = unique( Condition, 'stable' );
    NumProcesses = size( ConditionNameUnique, 1 );
    ConditionID = ones( NumSamples, 1 ) * NaN;
    RunOrder = ones( NumSamples, 1 ) * NaN;
    for i = 1:NumProcesses
        TempRuns = (Condition==ConditionNameUnique( i ));
        ConditionID( TempRuns ) = i;
        RunOrder( TempRuns ) = [ 1:sum( TempRuns ) ];
    end
    SampleInfo = [ ConditionID, RunOrder ];
    ConditionNameUnique = string( ConditionNameUnique );
end
