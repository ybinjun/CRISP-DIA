function ColumnData = ReadCSVFile(fidRead,TargetFormat,CurrentColumnName,ColumnTitles,FilePositionFirstData,isObligatory)
    NumInputColumns = size( ColumnTitles, 2 );
    format = '%*s';
    CurrentColumnIndex = find( strcmpi( ColumnTitles, CurrentColumnName ) );
    if isempty( CurrentColumnIndex )
        if isObligatory==true
            error( [ 'Input data error: Lack the data of ', CurrentColumnName, '. You may also need to check the column names in the csv file.' ] )
        else
            ColumnData = [  ];
        end
    else
        ColumnData = textscan( fidRead, [ repmat( format, [ 1, CurrentColumnIndex - 1 ] ), TargetFormat, repmat( format, [ 1, NumInputColumns - CurrentColumnIndex ] ) ], 'Delimiter', ',', 'HeaderLines', 0 );
        ColumnData = ColumnData{ 1, 1 };
        fseek( fidRead, FilePositionFirstData, 'bof' );
    end
end
