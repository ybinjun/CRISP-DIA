function Inputs = checkVarargin(varargin)
    warning( 'on' );
    getInputs = @(x) find( strcmpi( varargin, x ), 1 );
    TextInPos = getInputs( 'Inputs' );
    if ~isempty( TextInPos )
        load( [ varargin{ TextInPos + 1 }, '\Inputs.mat' ], 'Inputs' );
    else
        TextInPos = getInputs( 'iRT_PeptideMSspec' );
        if ~isempty( TextInPos )
            switch varargin{ TextInPos + 1 }
                case { 'Biognosys-11' }
                    load( [ '.\PresetData\iRT_', varargin{ TextInPos + 1 }, '.mat' ], 'MyPeptideMSspec' );
                    Inputs.iRT_PeptideMSspec = MyPeptideMSspec;
                otherwise
                    [Inputs.iRT_PeptideMSspec,~] = Import_PeptideMSspec( varargin{ TextInPos + 1 }, 'None' );
            end
        else
            error( 'Input data error: iRT_PeptideMSspec should be provided.' )
        end
        NumPeptides = size( Inputs.iRT_PeptideMSspec, 2 );
        iRTValues = [  ];
        for i = 1:NumPeptides
            iRTValues = [ iRTValues, Inputs.iRT_PeptideMSspec{ i }.Tr_recalibrated ];
        end
        [Inputs.iRTValues,Index] = sort( iRTValues );
        Inputs.iRT_PeptideMSspec = Inputs.iRT_PeptideMSspec( Index );
        TextInPos = getInputs( 'TargetSortMode' );
        if ~isempty( TextInPos )
            Inputs.TargetSortMode = varargin{ TextInPos + 1 };
        else
            Inputs.TargetSortMode = 'PeptideModifiedSequence';
        end
        TextInPos = getInputs( 'TargetPeptideMSspec' );
        if ~isempty( TextInPos )
            [Inputs.MyPeptideMSspec,Inputs.PeptideSource] = Import_PeptideMSspec( varargin{ TextInPos + 1 }, Inputs.TargetSortMode );
        else
            error( 'Input data error: TargetPeptideMSspec should be provided.' )
        end
        TextInPos = getInputs( 'MSFilePath' );
        if ~isempty( TextInPos )
            Inputs.MSFilePath = varargin{ TextInPos + 1 };
            if Inputs.MSFilePath( end )~='\'
                Inputs.MSFilePath( end + 1 ) = '\';
            end
        else
            error( 'Input data error: LC-MS raw file path should be provided.' )
        end
        TextInPos = getInputs( 'FilePathforFileID_Condition' );
        if ~isempty( TextInPos )
            [Inputs.FileID,Inputs.ConditionNameUnique,Inputs.SampleInfo] = Import_FileID_Condition( varargin{ TextInPos + 1 } );
        else
            error( 'Input data error: LC-MS data filenames and their corresponding condition classifiers should be provided.' )
        end
        TextInPos = getInputs( 'OutputFilePath' );
        if ~isempty( TextInPos )
            Inputs.OutputFilePath = varargin{ TextInPos + 1 };
            if Inputs.OutputFilePath( end )~='\'
                Inputs.OutputFilePath( end + 1 ) = '\';
            end
        else
            error( 'Input data error: OutputFilePath should be provided.' )
        end
        TextInPos = getInputs( 'HalfExtractWindow' );
        if ~isempty( TextInPos )
            Inputs.HalfExtractWindow = varargin{ TextInPos + 1 };
        else
            warning( 'HalfExtractWindow is not provided. The value will be roughly estimated.' )
            Inputs.HalfExtractWindow = NaN;
        end
        TextInPos = getInputs( 'MzErrorLimitPPM' );
        if ~isempty( TextInPos )
            Inputs.MzErrorLimitPPM = varargin{ TextInPos + 1 };
        else
            warning( 'MzErrorLimitPPM is not provided. The default value of 20 PPM will be used.' )
            Inputs.MzErrorLimitPPM = 20;
        end
        TextInPos = getInputs( 'TimeDeviationLimitCoeff' );
        if ~isempty( TextInPos )
            TimeDeviationLimitCoeff = varargin{ TextInPos + 1 };
            Inputs.TimeDeviationLimit_Intercept = TimeDeviationLimitCoeff( 1 );
            Inputs.TimeDeviationLimit_Slope = TimeDeviationLimitCoeff( 2 );
        else
            Inputs.TimeDeviationLimit_Intercept = NaN;
            Inputs.TimeDeviationLimit_Slope = NaN;
        end
        TextInPos = getInputs( 'iRT_Boundaries' );
        if ~isempty( TextInPos )
            Inputs.iRT_Boundaries = varargin{ TextInPos + 1 };
            if ~all( size( Inputs.iRT_Boundaries )==[ 2, 2 ] )
                error( 'Input data error: iRT_Boundaries should be a 2x2 matrix.' )
            end
            if Inputs.iRT_Boundaries( 1, 1 )>=Inputs.iRT_Boundaries( 2, 1 ) || Inputs.iRT_Boundaries( 1, 2 )>=Inputs.iRT_Boundaries( 2, 2 )
                error( 'Input data error: The first line of iRT_Boundaries should be corresponding to the lower boundary.' )
            end
        else
            Inputs.iRT_Boundaries = NaN;
        end
        TextInPos = getInputs( 'iRT_times' );
        if ~isempty( TextInPos )
            Inputs.iRTtimes = varargin{ TextInPos + 1 };
            Inputs.iRTtimes = Inputs.iRTtimes( :, Index );
        else
            Inputs.iRTtimes = NaN;
        end
        TextInPos = getInputs( 'ExpectedFirstPeakWidth' );
        if ~isempty( TextInPos )
            Inputs.min_iRTPeakWidths = varargin{ TextInPos + 1 };
        else
            Inputs.min_iRTPeakWidths = NaN;
        end
        TextInPos = getInputs( 'ExpectedMiddlePeakWidth' );
        if ~isempty( TextInPos )
            Inputs.median_iRTPeakWidths = varargin{ TextInPos + 1 };
        else
            Inputs.median_iRTPeakWidths = NaN;
        end
        NumSamples = size( Inputs.FileID, 1 );
        TextInPos = getInputs( 'MzBiasPPM' );
        if ~isempty( TextInPos )
            Inputs.iRTMeanMzErrorPPM = varargin{ TextInPos + 1 };
            if ischar( Inputs.iRTMeanMzErrorPPM ) || (max( size( Inputs.iRTMeanMzErrorPPM ) )==1 && Inputs.iRTMeanMzErrorPPM==0)
                if strcmpi( Inputs.iRTMeanMzErrorPPM, 'Ignore' ) || (max( size( Inputs.iRTMeanMzErrorPPM ) )==1 && Inputs.iRTMeanMzErrorPPM==0)
                    Inputs.iRTMeanMzErrorPPM = zeros( 1, NumSamples );
                else
                    Inputs.iRTMeanMzErrorPPM = NaN;
                end
            end
        else
            Inputs.iRTMeanMzErrorPPM = NaN;
        end
        TextInPos = getInputs( 'SmoothMS2Intensity' );
        if ~isempty( TextInPos )
            Inputs.isSmooth = varargin{ TextInPos + 1 };
            if string( Inputs.isSmooth )=='0' || strcmpi( Inputs.isSmooth, 'false' )
                Inputs.isSmooth = 0;
            else
                Inputs.isSmooth = 1;
            end
        else
            Inputs.isSmooth = 1;
        end
        Inputs.isemptyIonMobility = true;
        NumPeptides = size( Inputs.MyPeptideMSspec, 2 );
        for i = 1:NumPeptides
            if isfield( Inputs.MyPeptideMSspec{ i }, 'IonMobility' )
                if ~isnan( Inputs.MyPeptideMSspec{ i }.IonMobility )
                    Inputs.isemptyIonMobility = false;
                    break
                end
            else
                Inputs.isemptyIonMobility = true;
                break
            end
        end
        Inputs.IonMobilityDeviation = NaN;
        if Inputs.isemptyIonMobility==false
            TextInPos = getInputs( 'IonMobilityHalfWindow' );
            if ~isempty( TextInPos )
                Inputs.IonMobilityHalfWindow = varargin{ TextInPos + 1 };
            else
                error( 'Input data error: IonMobilityHalfWindow should be provided.' )
            end
            TextInPos = getInputs( 'IonMobilityBias' );
            if ~isempty( TextInPos )
                Inputs.IonMobilityDeviation = varargin{ TextInPos + 1 };
                if ischar( Inputs.IonMobilityDeviation ) || (max( size( Inputs.IonMobilityDeviation ) )==1 && Inputs.IonMobilityDeviation==0)
                    if strcmpi( Inputs.IonMobilityDeviation, 'Ignore' ) || (max( size( Inputs.IonMobilityDeviation ) )==1 && Inputs.IonMobilityDeviation==0)
                        Inputs.IonMobilityDeviation = zeros( 1, NumSamples );
                    else
                        Inputs.IonMobilityDeviation = NaN;
                    end
                end
            else
                Inputs.IonMobilityDeviation = NaN;
            end
            if isnan( Inputs.IonMobilityDeviation )
                TextInPos = getInputs( 'NumForIonMobilityCalibrate' );
                if ~isempty( TextInPos )
                    Inputs.NumForIonMobilityCalibrate = varargin{ TextInPos + 1 };
                    if ~(Inputs.NumForIonMobilityCalibrate<=10000 && Inputs.NumForIonMobilityCalibrate>=10)
                        warning( 'Please consider change NumForIonMobilityCalibrate to a suggested value (10 to 10000). Or, press Enter to continue.' )
                    end
                else
                    Inputs.NumForIonMobilityCalibrate = 100;
                end
            else
                Inputs.NumForIonMobilityCalibrate = 0;
            end
            TextInPos = getInputs( 'IM_PeakExtract_MzMaxRelativeDev' );
            if ~isempty( TextInPos )
                Inputs.IM_PeakPicking_MzMaxRelativeDev = varargin{ TextInPos + 1 };
            else
                Inputs.IM_PeakPicking_MzMaxRelativeDev = 10;
            end
            TextInPos = getInputs( 'IM_PeakExtract_IonMobilityMaxDev' );
            if ~isempty( TextInPos )
                Inputs.IM_PeakPicking_IonMobilityMaxDev = varargin{ TextInPos + 1 };
            else
                Inputs.IM_PeakPicking_IonMobilityMaxDev = 0.01;
            end
            TextInPos = getInputs( 'IM_PeakExtract_BaseLineIntensity' );
            if ~isempty( TextInPos )
                Inputs.IM_PeakPicking_BaseLineIntensity = varargin{ TextInPos + 1 };
            else
                Inputs.IM_PeakPicking_BaseLineIntensity = 0;
            end
            TextInPos = getInputs( 'IonMobilityConsistencyLimit' );
            if ~isempty( TextInPos )
                Inputs.IonMobilityConsistencyLimit = varargin{ TextInPos + 1 };
            else
                Inputs.IonMobilityConsistencyLimit = Inputs.IM_PeakPicking_IonMobilityMaxDev;
            end
        else
            Inputs.IonMobilityHalfWindow = NaN;
            Inputs.IonMobilityConsistencyLimit = NaN;
        end
        TextInPos = getInputs( 'NormalizeMS2Intensity' );
        if ~isempty( TextInPos )
            Inputs.isNormalize = varargin{ TextInPos + 1 };
            if string( Inputs.isNormalize )=='0' || strcmpi( Inputs.isNormalize, 'false' )
                Inputs.isNormalize = false;
            else
                Inputs.isNormalize = true;
            end
        else
            Inputs.isNormalize = false;
        end
        TextInPos = getInputs( 'UseBestPrecAreaForProtein' );
        if ~isempty( TextInPos )
            Inputs.UseBestPrecAreaForProt = varargin{ TextInPos + 1 };
            if string( Inputs.UseBestPrecAreaForProt )=='0' || strcmpi( Inputs.UseBestPrecAreaForProt, 'false' )
                Inputs.UseBestPrecAreaForProt = false;
            else
                Inputs.UseBestPrecAreaForProt = true;
            end
        else
            Inputs.UseBestPrecAreaForProt = true;
        end
        if Inputs.UseBestPrecAreaForProt && max( Inputs.SampleInfo( :, 1 ) )>2
            Inputs.UseBestPrecAreaForProt = false;
            warning( 'UseBestPrecAreaForProt is not allowed for the studies with more than two conditions. Instead, the weighted sum of the normalized areas of all the related peptide precursors above the score limit will be used for protein quantity.' );
        end
        TextInPos = getInputs( 'ScoreWeights' );
        if ~isempty( TextInPos )
            Inputs.ScoreWeightsNew = varargin{ TextInPos + 1 };
            if size( Inputs.ScoreWeightsNew, 1 )>size( Inputs.ScoreWeightsNew, 2 )
                Inputs.ScoreWeightsNew = Inputs.ScoreWeightsNew';
            end
            if size( Inputs.ScoreWeightsNew, 1 )~=1 || size( Inputs.ScoreWeightsNew, 2 )~=8
                error( 'Input data error: ScoreWeightsNew should be a 1x8 matrix.' )
            end
            Inputs.ScoreWeights = zeros( 1, 11 );
            Inputs.ScoreWeights( [ 7, 9, 8, 6, 2, 1, 4, 10 ] ) = Inputs.ScoreWeightsNew;
        else
            Inputs.ScoreWeights = [ 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0 ];
        end
        if max( Inputs.SampleInfo( :, 2 ) )==1
            Inputs.ScoreWeights( 7 ) = 0;
            warning( 'The weight for PARS is set to zero, because there are no replicate runs.' );
        end
        TextInPos = getInputs( 'ScoreLimitForPrecursor' );
        if ~isempty( TextInPos )
            Inputs.ScoreLimit = varargin{ TextInPos + 1 };
            Inputs.FDR_Prec = NaN;
            Inputs.FDR_Protein = NaN;
        else
            Inputs.ScoreLimit = NaN;
            TextInPos = getInputs( 'DecoyPeptideMSspec' );
            if ~isempty( TextInPos )
                [Inputs.DecoyPeptideMSspec,~] = Import_PeptideMSspec( varargin{ TextInPos + 1 }, 'None' );
                TextInPos = getInputs( 'FDR_Limit_For_Precursor' );
                if ~isempty( TextInPos )
                    Inputs.FDR_Prec = varargin{ TextInPos + 1 };
                    if Inputs.FDR_Prec>1 || Inputs.FDR_Prec<=0
                        error( 'FDR_Limit_For_Precursor is invalid.It should be in the range of 0-1.' )
                    end
                else
                    warning( 'FDR_Limit_For_Precursor is not provided. The default value of 1% will be used.' )
                    Inputs.FDR_Prec = 0.01;
                end
                TextInPos = getInputs( 'FDR_Limit_For_Protein' );
                if ~isempty( TextInPos )
                    Inputs.FDR_Protein = varargin{ TextInPos + 1 };
                    if Inputs.FDR_Protein>1 || Inputs.FDR_Protein<=0
                        error( 'FDR_Limit_For_Protein is invalid.It should be in the range of 0-1.' )
                    end
                else
                    warning( 'FDR_Limit_For_Protein is not provided. FDR at Protein level will not be controlled, but FDR at Precursor level is still active.' )
                    Inputs.FDR_Protein = 1;
                end
            else
                Inputs.ScoreLimit = 0.85;
                Inputs.FDR_Prec = NaN;
                Inputs.FDR_Protein = NaN;
                warning( 'The data of decoy peptides are not provided. The default value of 0.85 will be used as the score limit for peptide precursors.' )
            end
        end
        TextInPos = getInputs( 'MaxRetentionTime' );
        if ~isempty( TextInPos )
            Inputs.MaxRetentionTime = varargin{ TextInPos + 1 };
        else
            Inputs.MaxRetentionTime = NaN;
        end
        TextInPos = getInputs( 'MaxNumQuantMS2Ions' );
        if ~isempty( TextInPos )
            Inputs.MaxNumQuantMS2Ions = varargin{ TextInPos + 1 };
            if ~(Inputs.MaxNumQuantMS2Ions>=5 && Inputs.MaxNumQuantMS2Ions<=15)
                warning( 'Please consider change MaxNumQuantMS2Ions to a suggested value (5 to 15). Or, press Enter to continue.' )
                pause;
            end
        else
            Inputs.MaxNumQuantMS2Ions = 6;
        end
        TextInPos = getInputs( 'NumParallel' );
        NumCPUs = feature( 'numcores' );
        if ~isempty( TextInPos )
            Inputs.NumParallel = varargin{ TextInPos + 1 };
            if ~(Inputs.NumParallel<=NumCPUs)
                warning( [ 'The maximal number of parallel workers is ', num2str( NumCPUs ), '.' ] )
                Inputs.NumParallel = NumCPUs;
            end
        else
            Inputs.NumParallel = NumCPUs;
        end
        poolobj = gcp( 'nocreate' );
        if isempty( poolobj )
            parpool( Inputs.NumParallel, 'IdleTimeout', 240 );
        elseif poolobj.NumWorkers~=Inputs.NumParallel
            delete( poolobj );
            parpool( Inputs.NumParallel, 'IdleTimeout', 240 );
        end
        [~,~] = mkdir( Inputs.OutputFilePath );
        SaveName = [ Inputs.OutputFilePath, 'Inputs.mat' ];
        save( SaveName, 'Inputs' );
    end
end
