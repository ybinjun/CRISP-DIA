function IonPeakListAllAglin = IonsAglin(PeakList,TimeDeviationLimit_Intercept,TimeDeviationLimit_Slope)
    IonPeakListAllAglin = [  ];
    NumTransitions = size( PeakList, 2 );
    NumColumns = 9;
    for ii = 1:NumTransitions
        PeakListSum = PeakList{ ii };
        if isempty( PeakListSum )
            PeakListSum = ones( 1, NumColumns ) * NaN;
        end
        PeakListAll{ ii } = sortrows( PeakListSum, 1 );
        TimeAglinAll{ ii } = PeakListAll{ ii }( :, 1:3 );
    end
    TimeDeviationLimit = Inf;
    q = 0;
    AglinedIndexList = [  ];
    for ii = 1:NumTransitions
        for p = 1:size( TimeAglinAll{ ii }, 1 )
            TempoAglinedIndexList = ones( 1, NumTransitions ) * -1;
            TempoAglinedIndexList2 = ones( 1, NumTransitions ) * -1;
            for iii = 1:NumTransitions
                if iii==ii
                    TempoAglinedIndexList( iii ) = p;
                    TempoAglinedIndexList2( iii ) = p;
                    continue
                end
                ind2keep = (TimeAglinAll{ iii }( :, 1 )>max( [ TimeAglinAll{ ii }( p, 2 ), TimeAglinAll{ ii }( p, 1 ) - TimeDeviationLimit ] )) & (TimeAglinAll{ iii }( :, 1 )<min( [ TimeAglinAll{ ii }( p, 3 ), TimeAglinAll{ ii }( p, 1 ) + TimeDeviationLimit ] ));
                if sum( ind2keep )>=1
                    [~,maxIndex] = max( PeakListAll{ iii }( :, 8 ) .* ind2keep );
                    TempoAglinedIndexList( iii ) = maxIndex;
                    [~,maxIndex] = min( abs( TimeAglinAll{ iii }( :, 1 ) - TimeAglinAll{ ii }( p, 1 ) ) );
                    TempoAglinedIndexList2( iii ) = maxIndex;
                else
                end
            end
            q = q + 1;
            AglinedIndexList( q, : ) = TempoAglinedIndexList;
            q = q + 1;
            AglinedIndexList( q, : ) = TempoAglinedIndexList2;
        end
    end
    Repeated = zeros( q, 1 );
    for p = 1:q
        for pp = p + 1:q
            if all( AglinedIndexList( p, : )==AglinedIndexList( pp, : ) )
                Repeated( p ) = 1;
                break
            end
        end
    end
    if size( AglinedIndexList, 1 )==0
        return
    end
    pp = 1;
    for p = 1:size( AglinedIndexList, 1 )
        if Repeated( p )==0
            AglinedIndexList2( pp, : ) = AglinedIndexList( p, : );
            pp = pp + 1;
        end
    end
    for PossiblePeakIndex = 1:size( AglinedIndexList2, 1 )
        for ii = 1:NumTransitions
            if AglinedIndexList2( PossiblePeakIndex, ii )==-1
                IonPeakListAllAglin( ii, :, PossiblePeakIndex ) = ones( 1, NumColumns ) * NaN;
            else
                IonPeakListAllAglin( ii, :, PossiblePeakIndex ) = PeakListAll{ ii }( AglinedIndexList2( PossiblePeakIndex, ii ), : );
            end
        end
    end
end
