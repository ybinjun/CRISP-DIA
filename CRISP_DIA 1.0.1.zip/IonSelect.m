function IonPeakListSelected = IonSelect(IonPeakListAllAglin,MyDataset,IonMobilityDeviationLimit)
    IonPeakListSelected = [  ];
    RankLimitCoeff = 0.8;
    NumTransitions = size( IonPeakListAllAglin, 1 );
    NumColumns = size( IonPeakListAllAglin, 2 );
    if isempty( IonPeakListAllAglin )
        NumPeaks = 0;
    else
        NumPeaks = size( IonPeakListAllAglin, 3 );
        IonPeakListSelected = ones( NumTransitions, NumColumns + 1, NumPeaks ) * NaN;
    end
    MaxNumPoints = 3;
    MaxNum = size( MyDataset{ 1 }.Data, 1 );
    for k = 1:NumPeaks
        MedianApexPoint = round( median( IonPeakListAllAglin( :, 4, k ), 'omitnan' ) );
        MedianPeakStartPoint = round( median( IonPeakListAllAglin( :, 5, k ), 'omitnan' ) );
        MedianPeakEndPoint = round( median( IonPeakListAllAglin( :, 6, k ), 'omitnan' ) );
        if MedianApexPoint - MedianPeakStartPoint>MaxNumPoints
            MedianPeakStartPoint = max( [ MedianApexPoint - MaxNumPoints, 1 ] );
        end
        if MedianPeakEndPoint - MedianApexPoint>MaxNumPoints
            MedianPeakEndPoint = min( [ MedianApexPoint + MaxNumPoints, MaxNum ] );
        end
        ApexPoints = IonPeakListAllAglin( :, 4, k );
        RankIndex = getRankIndex( MedianApexPoint, MedianPeakStartPoint, MedianPeakEndPoint, ApexPoints, MyDataset );
        IonPeakToRemove = isnan( RankIndex ) | RankIndex>(RankLimitCoeff * (MedianPeakEndPoint - MedianPeakStartPoint + 1));
        if size( MyDataset{ 1 }.Data, 2 )==4
            IonMobility_MedianApexPoint = ones( NumTransitions, 1 ) * NaN;
            for j = 1:NumTransitions
                IonMobility_MedianApexPoint( j ) = MyDataset{ j }.Data( MedianApexPoint, 4 );
            end
            IonMobility_ApexMedian = median( IonMobility_MedianApexPoint, 'omitnan' );
            for j = 1:NumTransitions
                if abs( IonMobility_MedianApexPoint( j ) - IonMobility_ApexMedian )>IonMobilityDeviationLimit
                    IonPeakToRemove( j ) = true;
                end
            end
        end
        RankIndex( IonPeakToRemove ) = NaN;
        IonPeakListSelected( :, :, k ) = [ IonPeakListAllAglin( :, :, k ), RankIndex ];
        IonPeakListSelected( IonPeakToRemove, :, k ) = NaN;
    end
end
