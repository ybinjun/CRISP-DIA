function FinalRankIndex = mySort(x,mode)
    if size( x, 1 )==1
        x = x';
    end
    Num = size( x, 1 );
    x( isnan( x ) ) = -inf;
    if mode==1
        [SortedValues,SortIndex] = sort( x, 'descend' );
    else
        [SortedValues,SortIndex] = sort( x, 'ascend' );
    end
    RankIndex = zeros( Num, 1 );
    for ii = 1:Num
        RankIndex( ii ) = ii;
    end
    i = 1;
    while i<Num
        if SortedValues( i )~=SortedValues( i + 1 )
            i = i + 1;
        else
            j = i + 1;
            NumEqual = 2;
            while j<Num
                if SortedValues( j )==SortedValues( j + 1 )
                    NumEqual = NumEqual + 1;
                else
                    break
                end
                j = j + 1;
            end
            RankIndex( i:i + NumEqual - 1 ) = min( RankIndex( i:i + NumEqual - 1 ) );
            i = i + NumEqual;
        end
    end
    Y = sortrows( [ SortIndex, RankIndex ], 1 );
    FinalRankIndex = Y( :, 2 );
end
