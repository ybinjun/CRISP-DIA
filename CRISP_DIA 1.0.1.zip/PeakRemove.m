function NewIonPeakListAllAglin = PeakRemove(IonPeakListAllAglin,NumTransitions)
    if isempty( IonPeakListAllAglin )
        NumPeaks = 0;
    else
        NumPeaks = size( IonPeakListAllAglin, 3 );
    end
    NumIonsLeast = max( [ floor( NumTransitions / 2 ), 2 ] );
    NumIonsLeast = min( [ NumIonsLeast, 6 ] );
    NewIonPeakListAllAglin = [  ];
    i = 1;
    for k = 1:NumPeaks
        if sum( ~isnan( IonPeakListAllAglin( :, 1, k ) ) )<NumIonsLeast
            continue
        else
            NewIonPeakListAllAglin( :, :, i ) = IonPeakListAllAglin( :, :, k );
            i = i + 1;
        end
    end
end
