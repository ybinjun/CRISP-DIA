function ScoresToSave = PeakGroupsScoring(NumProcesses,PeakAreaAfterSelectIon,RTerror_AfterSelectIon,CosDistAfterSelectIon,AreaSamplesForRSD,PrecursorPeakArea,PeakListAglinSelectedIons,EuclideanDistAfterSelectIon,ScoreNumIonsKept,CosDistComplementaryIon,MzErrorLimitPPM,HalfExtractWindow,IonMobilityError,IonMobilityHalfWindow)
    ScoreIntensity = 0;
    ScoreIntensityPrecursor = 0;
    ScoreRT_AfterSelectIon = max( 50, 100 - (RTerror_AfterSelectIon - 0) / (HalfExtractWindow - 0) * 50 );
    ScoreRT_AfterSelectIon( isnan( ScoreRT_AfterSelectIon ) ) = 0;
    MaxCosDistAfterSelectIon = 1;
    MinCosDistAfterSelectIon = 0;
    ScoreCosDistAfterSelectIon = (MaxCosDistAfterSelectIon - CosDistAfterSelectIon) / (MaxCosDistAfterSelectIon - MinCosDistAfterSelectIon) * 100;
    ScoreCosDistAfterSelectIon( isnan( ScoreCosDistAfterSelectIon ) ) = 0;
    ScoreEuclideanDistAfterSelectIon = max( 0, ((0.3 - EuclideanDistAfterSelectIon) / (0.3 - 0)) * 100 );
    ScoreEuclideanDistAfterSelectIon( isnan( ScoreEuclideanDistAfterSelectIon ) ) = 0;
    RSDAreaSamples = ones( 1, NumProcesses ) * NaN;
    for ii = 1:NumProcesses
        if sum( ~isnan( AreaSamplesForRSD{ ii } ) )<=1
            RSDAreaSamples( ii ) = NaN;
        else
            RSDAreaSamples( ii ) = min( [ std( AreaSamplesForRSD{ ii }, 'omitnan' ) / mean( AreaSamplesForRSD{ ii }, 'omitnan' ), 0.5 ] );
        end
    end
    RSDArea = median( RSDAreaSamples, 'omitnan' );
    ScoreRSDArea = ((0.5 - RSDArea) / 0.5) ^ 0.5 * 100;
    ScoreRSDArea( isnan( ScoreRSDArea ) ) = 0;
    ProfileSimilarity = mean( PeakListAglinSelectedIons( :, 10 ), 'omitnan' );
    ScoreProfileSimilarity = (max( [ 0, 1 - (ProfileSimilarity - 1) * 0.2 ] )) * 100;
    MzErrorLimitPPM = 30;
    MzErrorPPM = mean( PeakListAglinSelectedIons( :, 9 ), 'omitnan' );
    ScoreMzError = max( [ 0, 100 - MzErrorPPM * 100 / MzErrorLimitPPM ] );
    ScoreSampleKept = sum( ~isnan( PeakListAglinSelectedIons( :, 1 ) ) ) / size( PeakListAglinSelectedIons, 1 ) * 100;
    ScoreComplementaryIon = (1 - IonMobilityError / IonMobilityHalfWindow) * 100;
    ScoreComplementaryIon( isnan( ScoreComplementaryIon ) ) = 0;
    ScoresToSave = [ ScoreIntensity', ScoreRT_AfterSelectIon', ScoreCosDistAfterSelectIon', ScoreRSDArea', ScoreIntensityPrecursor', ScoreProfileSimilarity', ScoreEuclideanDistAfterSelectIon', ScoreNumIonsKept', ScoreMzError', ScoreSampleKept', ScoreComplementaryIon' ];
end
