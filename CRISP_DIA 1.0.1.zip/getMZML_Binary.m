function Output = getMZML_Binary(curLine,IsCompression,DataFormat)
    CurrentPosStart = find( curLine=='>', 1 ) + 1;
    CurrentPosEnd = find( curLine=='<', 1, 'last' ) - 1;
    CurrentValue = curLine( CurrentPosStart:CurrentPosEnd );
    if ~isempty( CurrentValue )
        Output = strDecode( CurrentValue );
        if IsCompression
            buffer = java.io.ByteArrayOutputStream();
            Temp = java.util.zip.InflaterOutputStream( buffer );
            Temp.write( Output, 0, numel( Output ) );
            Temp.close();
            Output = typecast( buffer.toByteArray(), 'uint8' )';
        end
        switch DataFormat
            case 64
                Output = typecast( Output, 'double' );
            case 32
                Output = typecast( Output, 'single' );
            otherwise
                error( 'The precision of data in mzML file is not recognized.' )
        end
    else
        Output = 0;
    end
    Output = Output';
end
