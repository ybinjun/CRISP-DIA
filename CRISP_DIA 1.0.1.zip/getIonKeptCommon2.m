function [PeakListAllAglin,IonKeptCommon] = getIonKeptCommon2(PeakListAllAglin,IonKeptOneColumn,SampleInfo)
    NumConditionsKept = size( unique( SampleInfo( ~isnan( PeakListAllAglin( :, 1 ) ), 1 ) ), 1 );
    NumTransitions = size( IonKeptOneColumn, 2 );
    IonKeptCommon = zeros( 1, NumTransitions );
    NumIonsKept = 0;
    SumIonsKept = 0;
    IonKeptOneColumnNew = IonKeptOneColumn;
    IonKeptCommonNew = IonKeptCommon;
    PeakListAllAglinNew = PeakListAllAglin;
    [~,maxIndex] = max( sum( IonKeptOneColumn, 1 ) );
    IonKeptCommonNew( maxIndex ) = 1;
    NumIonsKeptNew = NumIonsKept + 1;
    isSampleRemove = IonKeptOneColumn( :, maxIndex )==0;
    IonKeptOneColumnNew( isSampleRemove, : ) = 0;
    PeakListAllAglinNew( isSampleRemove, : ) = NaN;
    NumSampleKeptNew = sum( ~isnan( PeakListAllAglinNew( :, 1 ) ) );
    SumIonsKeptNew = NumIonsKeptNew * NumSampleKeptNew;
    while NumIonsKept<NumTransitions && SumIonsKeptNew>SumIonsKept
        IonKeptCommon = IonKeptCommonNew;
        NumIonsKept = NumIonsKeptNew;
        IonKeptOneColumn = IonKeptOneColumnNew;
        PeakListAllAglin = PeakListAllAglinNew;
        SumIonsKept = SumIonsKeptNew;
        [~,maxIndex] = max( sum( IonKeptOneColumn, 1 ) .* (1 - IonKeptCommon) );
        IonKeptCommonNew( maxIndex ) = 1;
        NumIonsKeptNew = NumIonsKept + 1;
        isSampleRemove = IonKeptOneColumn( :, maxIndex )==0;
        IonKeptOneColumnNew( isSampleRemove, : ) = 0;
        PeakListAllAglinNew( isSampleRemove, : ) = NaN;
        NumConditionsKeptNew = size( unique( SampleInfo( ~isnan( PeakListAllAglinNew( :, 1 ) ), 1 ) ), 1 );
        if NumConditionsKeptNew<NumConditionsKept * 0.8
            break
        end
        NumSampleKeptNew = sum( ~isnan( PeakListAllAglinNew( :, 1 ) ) );
        SumIonsKeptNew = NumIonsKeptNew * NumSampleKeptNew;
    end
end
