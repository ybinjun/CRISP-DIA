function [iRTtimes,iRT_Boundaries,iRTMeanMzErrorPPM,TimeDeviationLimit_Intercept,TimeDeviationLimit_Slope,MaxRetentionTime] = iRTprocessing(MyPeptideMSspec,iRTtimes,iRTValues,iRT_Boundaries,iRTMeanMzErrorPPM,MzErrorLimitPPM,OutputFilePath,RawDataPositionList,PrecursorRanges,TimeDeviationLimit_Intercept,TimeDeviationLimit_Slope,median_iRTPeakWidths,min_iRTPeakWidths,Orig_MaxRetentionTime,isSmooth,NormalizeCoeff,ScoreWeights,isemptyIonMobility,IonMobilityHalfWindow,IonMobilityDeviation,IonMobilityDeviationLimit,NumIonMobilityRangesPerIsolationWindow)
    MzErrorLimitPPM = 30;
    OutputFilePath_Matlab = [ OutputFilePath, 'iRT\Matlab\' ];
    MaxRetentionTime = Inf;
    NumPeptides = size( MyPeptideMSspec, 2 );
    NumSamples = size( RawDataPositionList, 2 );
    IonMobilityDeviation = ones( 1, NumSamples ) * 0;
    inPrecursorRanges = get_inPrecursorRanges( PrecursorRanges, MyPeptideMSspec );
    for i = 1:NumPeptides
        if sum( inPrecursorRanges( :, i ) )~=1
            error( [ 'iRT peptide ', num2str( i ), ' is error, precursor m/z do not match!' ] );
        end
    end
    IonMobility = ones( NumPeptides, NumSamples ) * NaN;
    if isemptyIonMobility==false
        for i = 1:NumPeptides
            IonMobility( i, : ) = MyPeptideMSspec{ i }.IonMobility + IonMobilityDeviation;
        end
    end
    if sum( ~isnan( iRTtimes ), 'all' )==0 || sum( ~isnan( iRTMeanMzErrorPPM ) )==0
        iRTMyDatasetAll = cell( NumSamples, NumPeptides );
        if exist( OutputFilePath_Matlab, 'dir' )==7
            rmdir( OutputFilePath_Matlab, 's' );
        end
        [~,~] = mkdir( OutputFilePath_Matlab );
        disp( 'Start extracting MS2 data of iRT peptides.' );
        for SampleIndex = 1:NumSamples
            if isemptyIonMobility==true
                MS2DataExtract( MyPeptideMSspec, RawDataPositionList, PrecursorRanges, inPrecursorRanges, MzErrorLimitPPM, SampleIndex, Inf, OutputFilePath_Matlab, zeros( NumPeptides, 1 ), MaxRetentionTime, zeros( 1, NumSamples ), isSmooth );
            else
                MS2DataExtract_2Dpeaks( MyPeptideMSspec, RawDataPositionList, PrecursorRanges, inPrecursorRanges, MzErrorLimitPPM, SampleIndex, Inf, OutputFilePath_Matlab, zeros( NumPeptides, 1 ), MaxRetentionTime, zeros( 1, NumSamples ), isSmooth, IonMobility( :, SampleIndex ), IonMobilityHalfWindow, NumIonMobilityRangesPerIsolationWindow );
            end
        end
        MS2DataExtractTrans( MyPeptideMSspec, NumSamples, OutputFilePath_Matlab, PrecursorRanges, inPrecursorRanges );
        iRTMyDatasetAll = LoadiRTMyDataset( MyPeptideMSspec, NumSamples, OutputFilePath_Matlab );
        disp( 'The MS2 data of iRT peptides have been extracted.' );
        MaxRetentionTime = iRTMyDatasetAll{ 1, 1 }{ 1 }.Data( end, 1 );
        if MaxRetentionTime>99.9
            MaxRetentionTime = round( MaxRetentionTime, 0 );
        elseif MaxRetentionTime>9.9
            MaxRetentionTime = round( MaxRetentionTime, 1 );
        else
            MaxRetentionTime = round( MaxRetentionTime, 2 );
        end
        if sum( ~isnan( iRTtimes ), 'all' )==0
            ScoreWeights( 2 ) = 0;
            ScoreWeights( 4 ) = 0;
            ScoreWeights( 5 ) = 0;
            ScoreWeights( 11 ) = 0;
            [FianlScore,FianlRatios,FianlAreas,iRTtimes,FianlPeakStarts,FianlPeakEnds,FianlSelectedProductIons] = Quant_Pep_Prec( MyPeptideMSspec, OutputFilePath_Matlab, [  ], [  ], [ (1:NumSamples)', ones( NumSamples, 1 ) ], [ 0, 0; MaxRetentionTime, MaxRetentionTime ], ones( NumSamples, 1 ) * 0.5 * MaxRetentionTime, zeros( 1, NumSamples ), MzErrorLimitPPM, MaxRetentionTime * 0.05, 0, zeros( NumPeptides, NumSamples ), ScoreWeights, Inf, NormalizeCoeff, true, IonMobilityHalfWindow, IonMobility, IonMobilityDeviationLimit );
            iRTtimes = iRTtimes';
            check_iRT_Times( iRTtimes, iRTValues, MyPeptideMSspec, OutputFilePath_Matlab );
        end
        if sum( ~isnan( iRTMeanMzErrorPPM ) )==0
            iRTMeanMzErrorPPM = get_MzErrorPPM( iRTMyDatasetAll, getMSspecTopN( MyPeptideMSspec, 3 ), iRTtimes, MzErrorLimitPPM );
        end
    else
        if exist( OutputFilePath_Matlab, 'dir' )~=7
            mkdir( OutputFilePath_Matlab );
        end
        if isnan( Orig_MaxRetentionTime )
            TempoMyPeptideMSspec{ 1 } = MyPeptideMSspec{ 1 };
            if isemptyIonMobility==true
                MS2DataExtract( TempoMyPeptideMSspec, RawDataPositionList, PrecursorRanges, inPrecursorRanges( :, 1 ), MzErrorLimitPPM, 1, Inf, OutputFilePath_Matlab, 0, MaxRetentionTime, 0, 0 );
            else
                MS2DataExtract_2Dpeaks( TempoMyPeptideMSspec, RawDataPositionList, PrecursorRanges, inPrecursorRanges( :, 1 ), MzErrorLimitPPM, 1, Inf, OutputFilePath_Matlab, 0, MaxRetentionTime, 0, 0, IonMobility, IonMobilityHalfWindow, NumIonMobilityRangesPerIsolationWindow );
            end
            MS2DataExtractTrans( TempoMyPeptideMSspec, 1, OutputFilePath_Matlab, PrecursorRanges, inPrecursorRanges( :, 1 ) );
            iRTMyDataset = LoadiRTMyDataset( TempoMyPeptideMSspec, 1, OutputFilePath_Matlab );
            MaxRetentionTime = iRTMyDataset{ 1 }{ 1 }.Data( end, 1 );
            if MaxRetentionTime>99.9
                MaxRetentionTime = round( MaxRetentionTime, 0 );
            elseif MaxRetentionTime>9.9
                MaxRetentionTime = round( MaxRetentionTime, 1 );
            else
                MaxRetentionTime = round( MaxRetentionTime, 2 );
            end
        else
            MaxRetentionTime = Orig_MaxRetentionTime;
        end
    end
    if isnan( iRT_Boundaries )
        iRT_Boundaries = get_iRT_Boundaries( iRTtimes, iRTValues, MaxRetentionTime );
    end
    if isnan( TimeDeviationLimit_Intercept ) || isnan( TimeDeviationLimit_Slope )
        [TimeDeviationLimit_Intercept,TimeDeviationLimit_Slope] = get_TimeDeviationLimit3( iRTtimes, iRT_Boundaries );
    end
end
