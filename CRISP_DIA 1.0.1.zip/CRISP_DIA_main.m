function CRISP_DIA_main(varargin)
    Inputs = checkVarargin( varargin{ : } );
    NumSamples = size( Inputs.FileID, 1 );
    NumPeptides = size( Inputs.MyPeptideMSspec, 2 );
    NumConditions = size( Inputs.ConditionNameUnique, 1 );
    try
        if java.io.File( Inputs.OutputFilePath ).getFreeSpace() / (2 ^ 30)<(1 * NumSamples + 0.1 / (2 ^ 10) * NumPeptides * NumSamples)
            warning( [ 'The free space of hard-disk may not enough (roughly estimated requirement of ', num2str( round( 1 * NumSamples + 0.1 / (2 ^ 10) * NumPeptides * NumSamples, 1 ) ), ' GB). Please consider change OutputFilePath and restart this program. Or, press Enter to continue.' ] )
        end
    catch
        warning( [ 'The free space of hard-disk should be checked manually (roughly estimated requirement of ', num2str( round( 1 * NumSamples + 0.1 / (2 ^ 10) * NumPeptides * NumSamples, 1 ) ), ' GB).' ] )
    end
    TempoPrecursorRanges = cell( NumSamples, 1 );
    TempoMzRangeWithBoundary = cell( NumSamples, 1 );
    RawDataPositionList = cell( 1, NumSamples );
    RawDataPositionListPrecursor = cell( 1, NumSamples );
    if Inputs.isemptyIonMobility==true
        parfor SampleIndex = 1:NumSamples
            TempoFolderName = [ Inputs.OutputFilePath, 'Matlab\', Inputs.FileID{ SampleIndex } ];
            if exist( TempoFolderName, 'dir' )==7
                warning( [ 'The folder for the .mat data of ', Inputs.FileID{ SampleIndex }, ' already exist. Manually remove the folder (', TempoFolderName, ') if you want to recreate the .mat data.' ] )
            else
                SampleFileName = [ Inputs.MSFilePath, Inputs.FileID{ SampleIndex } ];
                if ~strcmp( SampleFileName( end - 4:end ), '.mzML' )
                    SampleFileName = [ SampleFileName, '.mzML' ];
                end
                if exist( SampleFileName, 'file' )
                    [TempoMzRangeWithBoundary{ SampleIndex },TempoPrecursorRanges{ SampleIndex },~] = mzML2Matlab( SampleFileName, Inputs.FileID{ SampleIndex }, [ Inputs.OutputFilePath, 'Matlab' ] );
                else
                    error( [ 'The file of ', SampleFileName, ' does not exist. Only .mzML format (which can be converted from vendor raw data using MSConvert), is supported in this version of CRISP-DIA.' ] )
                end
            end
            RawDataPositionList{ SampleIndex } = [ TempoFolderName, '\MS2.mat' ];
            RawDataPositionListPrecursor{ SampleIndex } = [ TempoFolderName, '\MS1.mat' ];
        end
    else
        for SampleIndex = 1:NumSamples
            TempoFolderName = [ Inputs.OutputFilePath, 'Matlab\', Inputs.FileID{ SampleIndex } ];
            if exist( TempoFolderName, 'dir' )==7
                warning( [ 'The folder for the .mat data of ', Inputs.FileID{ SampleIndex }, ' already exist. Manually remove the folder (', TempoFolderName, ') if you want to recreate the .mat data.' ] )
            else
                SampleFileName = [ Inputs.MSFilePath, Inputs.FileID{ SampleIndex } ];
                if ~strcmp( SampleFileName( end - 1:end ), '.d' )
                    SampleFileName = [ SampleFileName, '.d' ];
                end
                if exist( SampleFileName, 'dir' )==7
                    [TempoMzRangeWithBoundary{ SampleIndex },TempoPrecursorRanges{ SampleIndex },NumIonMobilityRangesPerIsolationWindow] = IonMobility2Matlab( SampleFileName, Inputs.FileID{ SampleIndex }, [ Inputs.OutputFilePath, 'Matlab' ], Inputs.IM_PeakPicking_MzMaxRelativeDev, Inputs.IM_PeakPicking_IonMobilityMaxDev, Inputs.IM_PeakPicking_BaseLineIntensity );
                else
                    error( [ 'The folder of ', SampleFileName, ' does not exist. Only Bruker .d format is supported for the raw data containing ion mobility, in this version of CRISP-DIA.' ] )
                end
            end
            RawDataPositionList{ SampleIndex } = [ TempoFolderName, '\MS2.mat' ];
            RawDataPositionListPrecursor{ SampleIndex } = [ TempoFolderName, '\MS1.mat' ];
        end
    end
    PrecursorRanges = TempoPrecursorRanges{ 1 };
    MzRangeWithBoundary = TempoMzRangeWithBoundary{ 1 };
    for SampleIndex = 2:NumSamples
        if isempty( PrecursorRanges )
            PrecursorRanges = TempoPrecursorRanges{ SampleIndex };
            if ~isempty( TempoMzRangeWithBoundary{ SampleIndex } )
                MzRangeWithBoundary = TempoMzRangeWithBoundary{ SampleIndex };
            end
        else
            if ~isempty( TempoPrecursorRanges{ SampleIndex } )
                if ~all( TempoPrecursorRanges{ SampleIndex }==PrecursorRanges, 'all' )
                    error( 'Different isolation windows found in the DIA data. Such data should be analyzed separately.' )
                end
            end
        end
    end
    if ~isempty( PrecursorRanges )
        if Inputs.isemptyIonMobility==true
            save( [ Inputs.OutputFilePath, 'PrecursorRanges.mat' ], 'PrecursorRanges', 'MzRangeWithBoundary' );
            NumIonMobilityRangesPerIsolationWindow = NaN;
        else
            save( [ Inputs.OutputFilePath, 'PrecursorRanges.mat' ], 'PrecursorRanges', 'MzRangeWithBoundary', 'NumIonMobilityRangesPerIsolationWindow' );
        end
    else
        if Inputs.isemptyIonMobility==true
            load( [ Inputs.OutputFilePath, 'PrecursorRanges.mat' ], 'PrecursorRanges', 'MzRangeWithBoundary' );
            NumIonMobilityRangesPerIsolationWindow = NaN;
        else
            load( [ Inputs.OutputFilePath, 'PrecursorRanges.mat' ], 'PrecursorRanges', 'MzRangeWithBoundary', 'NumIonMobilityRangesPerIsolationWindow' );
        end
    end
    inPrecursorRanges = get_inPrecursorRanges( PrecursorRanges, Inputs.MyPeptideMSspec );
    TempKeepPrec = sum( inPrecursorRanges, 1 )==1;
    inPrecursorRanges = inPrecursorRanges( :, TempKeepPrec );
    Inputs.MyPeptideMSspec = Inputs.MyPeptideMSspec( TempKeepPrec );
    Inputs.PeptideSource = Inputs.PeptideSource( TempKeepPrec );
    NumPeptides = size( Inputs.MyPeptideMSspec, 2 );
    if Inputs.isNormalize
        disp( [ 'Start calculating normalization coefficients for MS2 intensities.', datestr( now ) ] );
        if Inputs.isemptyIonMobility==true
            NormalizeCoeff = getTIC_Sum( RawDataPositionList, PrecursorRanges );
        else
            NormalizeCoeff = getTIC_Sum_2Dpeaks( RawDataPositionList, PrecursorRanges );
        end
    else
        NormalizeCoeff = ones( NumSamples, 1 );
    end
    Inputs.iRT_PeptideMSspec = getMSspecTopN( Inputs.iRT_PeptideMSspec, Inputs.MaxNumQuantMS2Ions );
    [iRTtimes,iRT_Boundaries,iRTMeanMzErrorPPM,TimeDeviationLimit_Intercept,TimeDeviationLimit_Slope,MaxRetentionTime] = iRTprocessing( Inputs.iRT_PeptideMSspec, Inputs.iRTtimes, Inputs.iRTValues, Inputs.iRT_Boundaries, Inputs.iRTMeanMzErrorPPM, Inputs.MzErrorLimitPPM, Inputs.OutputFilePath, RawDataPositionList, PrecursorRanges, Inputs.TimeDeviationLimit_Intercept, Inputs.TimeDeviationLimit_Slope, Inputs.median_iRTPeakWidths, Inputs.min_iRTPeakWidths, Inputs.MaxRetentionTime, Inputs.isSmooth, NormalizeCoeff, Inputs.ScoreWeights, Inputs.isemptyIonMobility, Inputs.IonMobilityHalfWindow, Inputs.IonMobilityDeviation, Inputs.IonMobilityConsistencyLimit, NumIonMobilityRangesPerIsolationWindow );
    Target_iRTValues = ones( NumPeptides, 1 ) * NaN;
    for i = 1:NumPeptides
        Target_iRTValues( i ) = Inputs.MyPeptideMSspec{ i }.Tr_recalibrated;
    end
    if isnan( Inputs.iRT_Boundaries )
        min_iRTValue = min( Target_iRTValues );
        max_iRTValue = max( Target_iRTValues );
        iRT_Boundaries( 1, 2 ) = min( [ iRT_Boundaries( 1, 2 ), min_iRTValue ] );
        iRT_Boundaries( 2, 2 ) = max( [ iRT_Boundaries( 2, 2 ), max_iRTValue ] );
    else
        iRT_Boundaries = Inputs.iRT_Boundaries;
    end
    OutputFilePath_iRTreport = [ Inputs.OutputFilePath, 'iRT\' ];
    [~,~] = mkdir( OutputFilePath_iRTreport );
    SaveName = [ OutputFilePath_iRTreport, 'iRT_Report.mat' ];
    save( SaveName, 'iRTtimes', 'iRT_Boundaries', 'iRTMeanMzErrorPPM', 'TimeDeviationLimit_Intercept', 'TimeDeviationLimit_Slope', 'MaxRetentionTime' );
    if isnan( Inputs.HalfExtractWindow )
        Inputs.HalfExtractWindow = MaxRetentionTime * 0.05;
        warning( [ 'HalfExtractWindow is estimated to be ', num2str( Inputs.HalfExtractWindow ), '. It is noted that this value may not be optimal for some cases.' ] )
    end
    Tr_Pred = getTr_Pred( Target_iRTValues, iRT_Boundaries, Inputs.iRTValues, iRTtimes );
    Inputs.MyPeptideMSspec = RemoveMS2inPrecursorRange( Inputs.MyPeptideMSspec, inPrecursorRanges, MzRangeWithBoundary );
    Inputs.MyPeptideMSspec = getMSspecTopN( Inputs.MyPeptideMSspec, Inputs.MaxNumQuantMS2Ions );
    if Inputs.isemptyIonMobility==false
        if isnan( Inputs.IonMobilityDeviation )
            IonMobilityDeviation = IonMobilityCalibrate( Inputs.NumForIonMobilityCalibrate, Inputs, RawDataPositionList, PrecursorRanges, inPrecursorRanges, Tr_Pred, iRT_Boundaries, iRTtimes, iRTMeanMzErrorPPM, MaxRetentionTime, TimeDeviationLimit_Intercept, TimeDeviationLimit_Slope, NormalizeCoeff, Inputs.IonMobilityConsistencyLimit, NumIonMobilityRangesPerIsolationWindow );
        else
            IonMobilityDeviation = Inputs.IonMobilityDeviation;
        end
    end
    IonMobility = ones( NumPeptides, NumSamples ) * NaN;
    if Inputs.isemptyIonMobility==false
        for i = 1:NumPeptides
            IonMobility( i, : ) = Inputs.MyPeptideMSspec{ i }.IonMobility + IonMobilityDeviation;
        end
    end
    disp( [ 'Start extracting MS2 data.', datestr( now ) ] );
    MS2FilePath = [ Inputs.OutputFilePath, 'Matlab\MS2\' ];
    if exist( MS2FilePath, 'dir' )==7
        warning( [ 'The folder for the extracted MS2 data already exist. Manually remove the folder (', MS2FilePath, ') or set another OutputFilePath, if you want to redo data extraction (in cases like incomplete/mistaken previous extractions).' ] )
    else
        [~,~] = mkdir( MS2FilePath );
        for SampleIndex = 1:NumSamples
            if Inputs.isemptyIonMobility==true
                MS2DataExtract( Inputs.MyPeptideMSspec, RawDataPositionList, PrecursorRanges, inPrecursorRanges, Inputs.MzErrorLimitPPM, SampleIndex, Inputs.HalfExtractWindow, MS2FilePath, Tr_Pred( :, SampleIndex ), MaxRetentionTime, iRTMeanMzErrorPPM, Inputs.isSmooth );
            else
                MS2DataExtract_2Dpeaks( Inputs.MyPeptideMSspec, RawDataPositionList, PrecursorRanges, inPrecursorRanges, Inputs.MzErrorLimitPPM, SampleIndex, Inputs.HalfExtractWindow, MS2FilePath, Tr_Pred( :, SampleIndex ), MaxRetentionTime, iRTMeanMzErrorPPM, Inputs.isSmooth, IonMobility( :, SampleIndex ), Inputs.IonMobilityHalfWindow, NumIonMobilityRangesPerIsolationWindow );
            end
            disp( [ 'The MS2 data of Sample NO. ', num2str( SampleIndex ), ' have been extracted.', datestr( now ) ] );
        end
        disp( [ 'Start converting extracted MS2 data.', datestr( now ) ] );
        MS2DataExtractTrans( Inputs.MyPeptideMSspec, NumSamples, MS2FilePath, PrecursorRanges, inPrecursorRanges );
        disp( [ 'Finish converting extracted MS2 data.', datestr( now ) ] );
    end
    if Inputs.ScoreWeights( 5 )~=0
        disp( [ 'Start extracting MS1 data.', datestr( now ) ] );
        MS1FilePath = [ Inputs.OutputFilePath, 'Matlab\MS1\' ];
        if exist( MS1FilePath, 'dir' )==7
            warning( [ 'The folder for the extracted MS1 data already exist. Manually remove the folder (', MS1FilePath, ') or set another OutputFilePath, if you want to redo data extraction (in cases like incomplete/mistaken previous extractions).' ] )
        else
            [~,~] = mkdir( MS1FilePath );
            for SampleIndex = 1:NumSamples
                MS1DataExtract( Inputs.MyPeptideMSspec, RawDataPositionListPrecursor, Inputs.MzErrorLimitPPM, SampleIndex, Inputs.HalfExtractWindow, MS1FilePath, Tr_Pred( :, SampleIndex ), MaxRetentionTime );
                disp( [ 'The MS1 data of Sample NO. ', num2str( SampleIndex ), ' have been extracted.', datestr( now ) ] );
            end
            disp( [ 'Start converting extracted MS1 data.', datestr( now ) ] );
            MS1DataExtractTrans( Inputs.MyPeptideMSspec, NumSamples, MS1FilePath );
            disp( [ 'Finish converting extracted MS1 data.', datestr( now ) ] );
        end
    else
        MS1FilePath = [  ];
    end
    if Inputs.ScoreWeights( 11 )~=0
        TempoMyPeptideMSspec = addComplementaryIon( Inputs.MyPeptideMSspec );
        for ii = 1:NumPeptides
            TempoMyPeptideMSspec{ ii }.MSspec( :, 2 ) = TempoMyPeptideMSspec{ ii }.CompleIonMz;
            TempoMyPeptideMSspec{ ii }.MSspec( :, 3 ) = ones( size( TempoMyPeptideMSspec{ ii }.MSspec( :, 3 ) ) ) * NaN;
        end
        disp( [ 'Start extracting MS2 data of Complementary Ions.', datestr( now ) ] );
        MS2FilePathComplementaryIon = [ Inputs.OutputFilePath, 'Matlab\MS2ComplementaryIon\' ];
        if exist( MS2FilePathComplementaryIon, 'dir' )==7
            warning( [ 'The folder for the extracted MS2 Complementary Ion data already exist. Manually remove the folder (', MS2FilePathComplementaryIon, ') or set another OutputFilePath, if you want to redo data extraction (in cases like incomplete/mistaken previous extractions).' ] )
        else
            [~,~] = mkdir( MS2FilePathComplementaryIon );
            for SampleIndex = 1:NumSamples
                MS2DataExtract( TempoMyPeptideMSspec, RawDataPositionList, PrecursorRanges, inPrecursorRanges, Inputs.MzErrorLimitPPM, SampleIndex, Inputs.HalfExtractWindow, MS2FilePathComplementaryIon, Tr_Pred( :, SampleIndex ), MaxRetentionTime, iRTMeanMzErrorPPM, Inputs.isSmooth );
                disp( [ 'The MS2 Complementary Ion data of Sample NO. ', num2str( SampleIndex ), ' have been extracted.', datestr( now ) ] );
            end
            disp( [ 'Start converting extracted MS2 Complementary data.', datestr( now ) ] );
            MS2DataExtractTrans( TempoMyPeptideMSspec, NumSamples, MS2FilePathComplementaryIon, PrecursorRanges, inPrecursorRanges );
            disp( [ 'Finish converting extracted MS2 Complementary data.', datestr( now ) ] );
        end
    else
        MS2FilePathComplementaryIon = [  ];
    end
    NumCPUs = feature( 'numcores' );
    poolobj = gcp( 'nocreate' );
    if isempty( poolobj )
        parpool( NumCPUs, 'IdleTimeout', 240 );
    elseif poolobj.NumWorkers~=NumCPUs
        delete( poolobj );
        parpool( NumCPUs, 'IdleTimeout', 240 );
    end
    disp( 'Start calculation for peptide quantification. It may take several hours depending on the number of peptide precursors (about 30 s for 1000 precursor), number of samples and computer hardware.' );
    [PrecScore,PrecRatios,PrecAreaSamples,PrecRTs,PrecPeakStarts,PrecPeakEnds,SelectedFragmentIons] = Quant_Pep_Prec( Inputs.MyPeptideMSspec, MS2FilePath, MS1FilePath, MS2FilePathComplementaryIon, Inputs.SampleInfo, iRT_Boundaries, iRTtimes, iRTMeanMzErrorPPM, Inputs.MzErrorLimitPPM, TimeDeviationLimit_Intercept, TimeDeviationLimit_Slope, Tr_Pred, Inputs.ScoreWeights, Inputs.HalfExtractWindow, NormalizeCoeff, false, Inputs.IonMobilityHalfWindow, IonMobility, Inputs.IonMobilityConsistencyLimit );
    disp( 'Finish calculation for peptide quantification.' );
    if isnan( Inputs.ScoreLimit )
        poolobj = gcp( 'nocreate' );
        if isempty( poolobj )
            parpool( Inputs.NumParallel, 'IdleTimeout', 240 );
        elseif poolobj.NumWorkers~=Inputs.NumParallel
            delete( poolobj );
            parpool( Inputs.NumParallel, 'IdleTimeout', 240 );
        end
        inPrecursorRanges = get_inPrecursorRanges( PrecursorRanges, Inputs.DecoyPeptideMSspec );
        TempKeepPrec = sum( inPrecursorRanges, 1 )==1;
        inPrecursorRanges = inPrecursorRanges( :, TempKeepPrec );
        Inputs.DecoyPeptideMSspec = Inputs.DecoyPeptideMSspec( TempKeepPrec );
        NumPeptidesDecoy = size( Inputs.DecoyPeptideMSspec, 2 );
        Decoy_iRTValues = ones( NumPeptidesDecoy, 1 ) * NaN;
        for i = 1:NumPeptidesDecoy
            Decoy_iRTValues( i ) = Inputs.DecoyPeptideMSspec{ i }.Tr_recalibrated;
        end
        DecoyTr_Pred = getTr_Pred( Decoy_iRTValues, iRT_Boundaries, Inputs.iRTValues, iRTtimes );
        Inputs.DecoyPeptideMSspec = RemoveMS2inPrecursorRange( Inputs.DecoyPeptideMSspec, inPrecursorRanges, MzRangeWithBoundary );
        Inputs.DecoyPeptideMSspec = getMSspecTopN( Inputs.DecoyPeptideMSspec, Inputs.MaxNumQuantMS2Ions );
        if Inputs.isemptyIonMobility==false
            IonMobility = ones( NumPeptidesDecoy, NumSamples ) * NaN;
            for i = 1:NumPeptidesDecoy
                IonMobility( i, : ) = Inputs.DecoyPeptideMSspec{ i }.IonMobility + IonMobilityDeviation;
            end
        end
        disp( [ 'Start extracting decoy MS2 data.', datestr( now ) ] );
        MS2FilePath = [ Inputs.OutputFilePath, 'Matlab\DecoyMS2\' ];
        if exist( MS2FilePath, 'dir' )==7
            warning( [ 'The folder for the extracted decoy MS2 data already exist. Manually remove the folder (', MS2FilePath, ') or set another OutputFilePath, if you want to redo data extraction (in cases like incomplete/mistaken previous extractions).' ] )
        else
            [~,~] = mkdir( MS2FilePath );
            for SampleIndex = 1:NumSamples
                if Inputs.isemptyIonMobility==true
                    MS2DataExtract( Inputs.DecoyPeptideMSspec, RawDataPositionList, PrecursorRanges, inPrecursorRanges, Inputs.MzErrorLimitPPM, SampleIndex, Inputs.HalfExtractWindow, MS2FilePath, DecoyTr_Pred( :, SampleIndex ), MaxRetentionTime, iRTMeanMzErrorPPM, Inputs.isSmooth );
                else
                    MS2DataExtract_2Dpeaks( Inputs.DecoyPeptideMSspec, RawDataPositionList, PrecursorRanges, inPrecursorRanges, Inputs.MzErrorLimitPPM, SampleIndex, Inputs.HalfExtractWindow, MS2FilePath, DecoyTr_Pred( :, SampleIndex ), MaxRetentionTime, iRTMeanMzErrorPPM, Inputs.isSmooth, IonMobility( :, SampleIndex ), Inputs.IonMobilityHalfWindow, NumIonMobilityRangesPerIsolationWindow );
                end
                disp( [ 'The decoy MS2 data of Sample NO. ', num2str( SampleIndex ), ' have been extracted.', datestr( now ) ] );
            end
            disp( [ 'Start converting extracted decoy MS2 data.', datestr( now ) ] );
            MS2DataExtractTrans( Inputs.DecoyPeptideMSspec, NumSamples, MS2FilePath, PrecursorRanges, inPrecursorRanges );
            disp( [ 'Finish converting extracted decoy MS2 data.', datestr( now ) ] );
        end
        if Inputs.ScoreWeights( 5 )~=0
            disp( [ 'Start extracting decoy MS1 data.', datestr( now ) ] );
            MS1FilePath = [ Inputs.OutputFilePath, 'Matlab\DecoyMS1\' ];
            if exist( MS1FilePath, 'dir' )==7
                warning( [ 'The folder for the extracted decoy MS1 data already exist. Manually remove the folder (', MS1FilePath, ') or set another OutputFilePath, if you want to redo data extraction (in cases like incomplete/mistaken previous extractions).' ] )
            else
                [~,~] = mkdir( MS1FilePath );
                for SampleIndex = 1:NumSamples
                    MS1DataExtract( Inputs.DecoyPeptideMSspec, RawDataPositionListPrecursor, Inputs.MzErrorLimitPPM, SampleIndex, Inputs.HalfExtractWindow, MS1FilePath, DecoyTr_Pred( :, SampleIndex ), MaxRetentionTime );
                    disp( [ 'The decoy MS1 data of Sample NO. ', num2str( SampleIndex ), ' have been extracted.', datestr( now ) ] );
                end
                disp( [ 'Start converting extracted decoy MS1 data.', datestr( now ) ] );
                MS1DataExtractTrans( Inputs.DecoyPeptideMSspec, NumSamples, MS1FilePath );
                disp( [ 'Finish converting extracted decoy MS1 data.', datestr( now ) ] );
            end
        else
            MS1FilePath = [  ];
        end
        if Inputs.ScoreWeights( 11 )~=0
            TempoMyPeptideMSspec = addComplementaryIon( Inputs.DecoyPeptideMSspec );
            for ii = 1:NumPeptidesDecoy
                TempoMyPeptideMSspec{ ii }.MSspec( :, 2 ) = TempoMyPeptideMSspec{ ii }.CompleIonMz;
                TempoMyPeptideMSspec{ ii }.MSspec( :, 3 ) = ones( size( TempoMyPeptideMSspec{ ii }.MSspec( :, 3 ) ) ) * NaN;
            end
            disp( [ 'Start extracting decoy MS2 data of Complementary Ions.', datestr( now ) ] );
            MS2FilePathComplementaryIon = [ Inputs.OutputFilePath, 'Matlab\DecoyMS2ComplementaryIon\' ];
            if exist( MS2FilePathComplementaryIon, 'dir' )==7
                warning( [ 'The folder for the extracted decoy MS2 Complementary Ion data already exist. Manually remove the folder (', MS2FilePathComplementaryIon, ') or set another OutputFilePath, if you want to redo data extraction (in cases like incomplete/mistaken previous extractions).' ] )
            else
                [~,~] = mkdir( MS2FilePathComplementaryIon );
                for SampleIndex = 1:NumSamples
                    MS2DataExtract( TempoMyPeptideMSspec, RawDataPositionList, PrecursorRanges, inPrecursorRanges, Inputs.MzErrorLimitPPM, SampleIndex, Inputs.HalfExtractWindow, MS2FilePathComplementaryIon, DecoyTr_Pred( :, SampleIndex ), MaxRetentionTime, iRTMeanMzErrorPPM, Inputs.isSmooth );
                    disp( [ 'The decoy MS2 Complementary Ion data of Sample NO. ', num2str( SampleIndex ), ' have been extracted.', datestr( now ) ] );
                end
                disp( [ 'Start converting extracted decoy MS2 Complementary data.', datestr( now ) ] );
                MS2DataExtractTrans( TempoMyPeptideMSspec, NumSamples, MS2FilePathComplementaryIon, PrecursorRanges, inPrecursorRanges );
                disp( [ 'Finish converting extracted decoy MS2 Complementary data.', datestr( now ) ] );
            end
        else
            MS2FilePathComplementaryIon = [  ];
        end
        poolobj = gcp( 'nocreate' );
        if isempty( poolobj )
            parpool( NumCPUs, 'IdleTimeout', 240 );
        elseif poolobj.NumWorkers~=NumCPUs
            delete( poolobj );
            parpool( NumCPUs, 'IdleTimeout', 240 );
        end
        disp( 'Start calculation for decoy peptide quantification. It may take several hours depending on the number of peptide precursors (about 30 s for 1000 precursor), number of samples and computer hardware.' );
        [FianlScoreDecoy,PrecRatiosDecoy,PrecAreaSamplesDecoy,PrecRTsDecoy,PrecPeakStartsDecoy,PrecPeakEndsDecoy,SelectedFragmentIonsDecoy] = Quant_Pep_Prec( Inputs.DecoyPeptideMSspec, MS2FilePath, MS1FilePath, MS2FilePathComplementaryIon, Inputs.SampleInfo, iRT_Boundaries, iRTtimes, iRTMeanMzErrorPPM, Inputs.MzErrorLimitPPM, TimeDeviationLimit_Intercept, TimeDeviationLimit_Slope, DecoyTr_Pred, Inputs.ScoreWeights, Inputs.HalfExtractWindow, NormalizeCoeff, false, Inputs.IonMobilityHalfWindow, IonMobility, Inputs.IonMobilityConsistencyLimit );
        disp( 'Finish calculation for decoy peptide quantification.' );
        PeptideModifiedSequenceDecoy = cell( NumPeptidesDecoy, 1 );
        PrecursorChargeDecoy = ones( NumPeptidesDecoy, 1 ) * NaN;
        for i = 1:NumPeptidesDecoy
            PeptideModifiedSequenceDecoy{ i } = Inputs.DecoyPeptideMSspec{ i }.PeptideSequence;
            PrecursorChargeDecoy( i ) = Inputs.DecoyPeptideMSspec{ i }.PrecursorCharge;
            SelectedFragmentIonsDecoy{ i, 1 } = strrep( num2str( SelectedFragmentIonsDecoy{ i }( end, : ), '% .4f' ), '  ', ' ' );
        end
        TableReportDecoy = table( PeptideModifiedSequenceDecoy, PrecursorChargeDecoy, FianlScoreDecoy, PrecRatiosDecoy, PrecAreaSamplesDecoy, PrecRTsDecoy, PrecPeakStartsDecoy, PrecPeakEndsDecoy, SelectedFragmentIonsDecoy );
        PrecRatioTitles = [  ];
        for i = 2:NumConditions
            PrecRatioTitles = strcat( PrecRatioTitles, 'Ratio-', Inputs.ConditionNameUnique( i ), ':', Inputs.ConditionNameUnique( 1 ), ',' );
        end
        PrecAreaTitles = [  ];
        RT_Titles = [  ];
        PeakStartTitles = [  ];
        PeakEndTitles = [  ];
        for i = 1:NumSamples
            PrecAreaTitles = strcat( PrecAreaTitles, 'Area-', Inputs.FileID{ i }, ',' );
            RT_Titles = strcat( RT_Titles, 'Retention time-', Inputs.FileID{ i }, ',' );
            PeakStartTitles = strcat( PeakStartTitles, 'Peak start time-', Inputs.FileID{ i }, ',' );
            PeakEndTitles = strcat( PeakEndTitles, 'Peak end time-', Inputs.FileID{ i }, ',' );
        end
        TableReportColumnTitles = strcat( 'Peptide modified sequence,Precursor charge,Score,', PrecRatioTitles, PrecAreaTitles, RT_Titles, PeakStartTitles, PeakEndTitles, 'Selected quantitative fragments' );
        TableReportColumnTitles = strip( TableReportColumnTitles, ',' );
        ReportFileID = fopen( [ Inputs.OutputFilePath, 'Report_PeptidesDecoy.csv' ], 'w' );
        fprintf( ReportFileID, '%s', TableReportColumnTitles );
        fclose( ReportFileID );
        writetable( TableReportDecoy, [ Inputs.OutputFilePath, 'Report_PeptidesDecoy.csv' ], 'WriteVariableNames', false, 'WriteMode', 'append' );
    else
        FianlScoreDecoy = NaN;
    end
    PeptideModifiedSequence = cell( NumPeptides, 1 );
    PrecursorCharge = ones( NumPeptides, 1 ) * NaN;
    for i = 1:NumPeptides
        PeptideModifiedSequence{ i } = Inputs.MyPeptideMSspec{ i }.PeptideSequence;
        PrecursorCharge( i ) = Inputs.MyPeptideMSspec{ i }.PrecursorCharge;
        SelectedFragmentIons{ i, 1 } = strrep( num2str( SelectedFragmentIons{ i }( end, : ), '% .4f' ), '  ', ' ' );
    end
    TableReport = table( PeptideModifiedSequence, PrecursorCharge, Inputs.PeptideSource, PrecScore, PrecRatios, PrecAreaSamples, PrecRTs, PrecPeakStarts, PrecPeakEnds, SelectedFragmentIons );
    PrecRatioTitles = [  ];
    for i = 2:NumConditions
        PrecRatioTitles = strcat( PrecRatioTitles, 'Ratio-', Inputs.ConditionNameUnique( i ), ':', Inputs.ConditionNameUnique( 1 ), ',' );
    end
    PrecAreaTitles = [  ];
    RT_Titles = [  ];
    PeakStartTitles = [  ];
    PeakEndTitles = [  ];
    for i = 1:NumSamples
        PrecAreaTitles = strcat( PrecAreaTitles, 'Area-', Inputs.FileID{ i }, ',' );
        RT_Titles = strcat( RT_Titles, 'Retention time-', Inputs.FileID{ i }, ',' );
        PeakStartTitles = strcat( PeakStartTitles, 'Peak start time-', Inputs.FileID{ i }, ',' );
        PeakEndTitles = strcat( PeakEndTitles, 'Peak end time-', Inputs.FileID{ i }, ',' );
    end
    TableReportColumnTitles = strcat( 'Peptide modified sequence,Precursor charge,Protein name,Score,', PrecRatioTitles, PrecAreaTitles, RT_Titles, PeakStartTitles, PeakEndTitles, 'Selected quantitative fragments' );
    TableReportColumnTitles = strip( TableReportColumnTitles, ',' );
    ReportFileID = fopen( [ Inputs.OutputFilePath, 'Report_PeptidePrecursors.csv' ], 'w' );
    fprintf( ReportFileID, '%s', TableReportColumnTitles );
    fclose( ReportFileID );
    writetable( TableReport, [ Inputs.OutputFilePath, 'Report_PeptidePrecursors.csv' ], 'WriteVariableNames', false, 'WriteMode', 'append' );
    disp( 'Start calculation for protein quantification.' );
    if ~isempty( Inputs.PeptideSource )
        [ProteinRatio,numPrecUsed,sumScorePrecsUsed,IndexProteinName,minFinalScoreLimit,PrecAreaUsed_ProtSum] = Quant_Prot_From_Prec2( PrecRatios, PrecScore, FianlScoreDecoy, Inputs.PeptideSource, Inputs.ScoreLimit, Inputs.FDR_Prec, Inputs.FDR_Protein, PrecAreaSamples, Inputs.SampleInfo, Inputs.UseBestPrecAreaForProt );
        disp( 'Finish calculation for protein quantification.' );
        TableReport = table( IndexProteinName, ProteinRatio, numPrecUsed, sumScorePrecsUsed, PrecAreaUsed_ProtSum );
        ProteinRatioTitles = [  ];
        numPrecUsedTitles = [  ];
        meanScorePrecsUsedTitles = [  ];
        for i = 2:NumConditions
            ProteinRatioTitles = strcat( ProteinRatioTitles, 'Ratio-', Inputs.ConditionNameUnique( i ), ':', Inputs.ConditionNameUnique( 1 ), '(Minimal ScoreLimit=', num2str( minFinalScoreLimit, '% .5f' ), ')', ',' );
        end
        PrecAreaUsed_ProtSumTitles = [  ];
        for i = 1:NumSamples
            if Inputs.UseBestPrecAreaForProt
                PrecAreaUsed_ProtSumTitles = strcat( PrecAreaUsed_ProtSumTitles, 'Quantity-', Inputs.FileID{ i }, ',' );
            else
                PrecAreaUsed_ProtSumTitles = strcat( PrecAreaUsed_ProtSumTitles, 'Normalized Quantity-', Inputs.FileID{ i }, ',' );
            end
        end
        numPrecUsedTitles = 'Number of precursors used for quantification,';
        meanScorePrecsUsedTitles = 'Total score of the precursors used for quantification,';
        TableReportColumnTitles = strcat( 'Protein Name,', ProteinRatioTitles, numPrecUsedTitles, meanScorePrecsUsedTitles, PrecAreaUsed_ProtSumTitles );
        TableReportColumnTitles = strip( TableReportColumnTitles, ',' );
        ReportFileID = fopen( [ Inputs.OutputFilePath, 'Report_Proteins.csv' ], 'w' );
        fprintf( ReportFileID, '%s', TableReportColumnTitles );
        fclose( ReportFileID );
        writetable( TableReport, [ Inputs.OutputFilePath, 'Report_Proteins.csv' ], 'WriteVariableNames', false, 'WriteMode', 'append' );
    end
end
