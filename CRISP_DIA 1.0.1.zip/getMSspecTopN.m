function MyPeptideMSspec = getMSspecTopN(MyPeptideMSspec,NumTransLimit)
    NumPeptides = size( MyPeptideMSspec, 2 );
    for ii = 1:NumPeptides
        MSspec = MyPeptideMSspec{ ii }.MSspec;
        if size( MSspec, 1 )>NumTransLimit
            MyPeptideMSspec{ ii }.MSspec = MSspec( 1:NumTransLimit, : );
            MyPeptideMSspec{ ii }.NeutralLoss = MyPeptideMSspec{ ii }.NeutralLoss( 1:NumTransLimit, : );
            MyPeptideMSspec{ ii }.FragmentCharge = MyPeptideMSspec{ ii }.FragmentCharge( 1:NumTransLimit, : );
        end
    end
end
