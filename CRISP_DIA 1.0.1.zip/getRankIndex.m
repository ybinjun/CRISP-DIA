function RankIndex = getRankIndex(MedianApexPoint,MedianPeakStartPoint,MedianPeakEndPoint,ApexPoints,MyDataset)
    NumTransitions = size( ApexPoints, 1 );
    RankIndex = ones( NumTransitions, 1 );
    for j = 1:NumTransitions
        if isnan( ApexPoints( j ) )
            RankIndex( j ) = NaN;
        else
            if ApexPoints( j )<MedianPeakStartPoint || ApexPoints( j )>MedianPeakEndPoint
                RankIndex( j ) = NaN;
            else
                TempoRankIndex = mySort( MyDataset{ j }.Data( MedianPeakStartPoint:MedianPeakEndPoint, 3 ), 1 );
                RankIndex( j ) = TempoRankIndex( MedianApexPoint - MedianPeakStartPoint + 1 );
            end
        end
    end
end
