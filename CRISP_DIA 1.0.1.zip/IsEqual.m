function r = IsEqual(x1,x2)
    if all( x1==x2 )
        r = 1;
    elseif isnan( x1 )==isnan( x2 )
        if all( x1( ~isnan( x1 ) )==x2( ~isnan( x2 ) ) )
            r = 1;
        else
            r = 0;
        end
    else
        r = 0;
    end
end
