function iRTMeanMzErrorPPM = get_MzErrorPPM(iRTMyDatasetAll,MyPeptideMSspec,iRTtimes,MzErrorLimitPPM)
    NumPeptides = size( iRTMyDatasetAll, 2 );
    NumSamples = size( iRTMyDatasetAll, 1 );
    for kk = 1:NumPeptides
        RefmzProduct = MyPeptideMSspec{ kk }.MSspec( :, 2 );
        NumTransitions = size( RefmzProduct, 1 );
        AllmzErrorPPM = [  ];
        for i = 1:NumSamples
            MyDataset = iRTMyDatasetAll{ i, kk };
            mzErrorPPM = [  ];
            [~,Index] = min( abs( MyDataset{ 1 }.Data( :, 1 ) - iRTtimes( i, kk ) ) );
            for j = 1:NumTransitions
                mzErrorPPM( j ) = (MyDataset{ j }.Data( Index, 2 ) - RefmzProduct( j )) / RefmzProduct( j ) * 10 ^ 6;
            end
            mzErrorPPM( abs( mzErrorPPM )>MzErrorLimitPPM ) = NaN;
            AllmzErrorPPM( :, i ) = mzErrorPPM';
            MeanMzErrorPPM( i ) = mean( mzErrorPPM', 'omitnan' );
        end
        FinalAllMzErrorPPM{ kk } = AllmzErrorPPM;
        FinalMeanMzErrorPPM( kk, : ) = MeanMzErrorPPM;
    end
    iRTMeanMzErrorPPM = mean( FinalMeanMzErrorPPM, 'omitnan' );
end
