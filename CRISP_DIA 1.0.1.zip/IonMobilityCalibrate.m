function IonMobilityDeviation = IonMobilityCalibrate(TopN,Inputs,RawDataPositionList,PrecursorRanges,inPrecursorRanges,Tr_Pred,iRT_Boundaries,iRTtimes,iRTMeanMzErrorPPM,MaxRetentionTime,TimeDeviationLimit_Intercept,TimeDeviationLimit_Slope,NormalizeCoeff,IonMobilityDeviationLimit,NumIonMobilityRangesPerIsolationWindow)
    [MyPeptideMSspec,IndexKept] = getPrecTopN_Intensity( Inputs.MyPeptideMSspec, TopN );
    inPrecursorRanges = inPrecursorRanges( :, IndexKept );
    Tr_Pred = Tr_Pred( IndexKept, : );
    NumSamples = size( iRTtimes, 1 );
    NumPeptides = size( MyPeptideMSspec, 2 );
    IonMobility = ones( NumPeptides, NumSamples ) * NaN;
    IonMobilityDeviation = ones( 1, NumSamples ) * 0;
    for i = 1:NumPeptides
        IonMobility( i, : ) = MyPeptideMSspec{ i }.IonMobility + IonMobilityDeviation;
    end
    disp( [ 'Start extracting MS2 data for ion mobility calibration.', datestr( now ) ] );
    MS2FilePath = [ Inputs.OutputFilePath, 'Matlab\MS2ForCali\' ];
    if exist( MS2FilePath, 'dir' )==7
        warning( [ 'The folder for the extracted MS2 data already exist. Manually remove the folder (', MS2FilePath, ') or set another OutputFilePath, if you want to redo data extraction (in cases like incomplete/mistaken previous extractions).' ] )
    else
        [~,~] = mkdir( MS2FilePath );
        for SampleIndex = 1:NumSamples
            MS2DataExtract_2Dpeaks( MyPeptideMSspec, RawDataPositionList, PrecursorRanges, inPrecursorRanges, Inputs.MzErrorLimitPPM, SampleIndex, Inputs.HalfExtractWindow, MS2FilePath, Tr_Pred( :, SampleIndex ), MaxRetentionTime, iRTMeanMzErrorPPM, Inputs.isSmooth, IonMobility, Inputs.IonMobilityHalfWindow, NumIonMobilityRangesPerIsolationWindow );
        end
        MS2DataExtractTrans( MyPeptideMSspec, NumSamples, MS2FilePath, PrecursorRanges, inPrecursorRanges );
        disp( [ 'Finish extracting extracted MS2 data for ion mobility calibration.', datestr( now ) ] );
    end
    [PrecScore,PrecRatios,PrecAreaSamples,PrecRTs,PrecPeakStarts,PrecPeakEnds,SelectedFragmentIons,IonMobilityAvgAll] = Quant_Pep_Prec( MyPeptideMSspec, MS2FilePath, [  ], [  ], Inputs.SampleInfo, iRT_Boundaries, iRTtimes, iRTMeanMzErrorPPM, Inputs.MzErrorLimitPPM, TimeDeviationLimit_Intercept, TimeDeviationLimit_Slope, Tr_Pred, Inputs.ScoreWeights, Inputs.HalfExtractWindow, NormalizeCoeff, false, Inputs.IonMobilityHalfWindow, IonMobility, IonMobilityDeviationLimit );
    IonMobilityDeviation = median( IonMobilityAvgAll - IonMobility, 'omitnan' );
    disp( 'Finish ion mobility calibration.' );
end
