function MS2DataExtract(MyPeptideMSspec,RawDataPositionList,PrecursorRanges,inPrecursorRanges,MzErrorLimitPPM,SampleIndex,HalfExtractWindow,FilePath,Tr_Pred,MaxRetentionTime,iRTMeanMzErrorPPM,isSmooth)
    NumPeptides = size( MyPeptideMSspec, 2 );
    loadFilePath = RawDataPositionList{ SampleIndex }( 1:length( RawDataPositionList{ SampleIndex } ) - 7 );
    NumPrecursorRanges = size( PrecursorRanges, 1 );
    parfor i = 1:NumPrecursorRanges
        inPrecursorRangesCurrent = inPrecursorRanges( i, : );
        NumPeptidesCurrent = sum( inPrecursorRangesCurrent );
        if NumPeptidesCurrent==0
            continue
        end
        subPrecursorRanges = PrecursorRanges( i, : );
        SubFileName = [ num2str( subPrecursorRanges( 1, 1 ), '%4.3f' ), '-', num2str( subPrecursorRanges( 1, 2 ), '%4.3f' ) ];
        LoadName = [ loadFilePath, SubFileName, '.mat' ];
        Tempo = load( LoadName, 'subMyMS' );
        MyMS = Tempo.subMyMS;
        Tempo = [  ];
        [NumScans,nTemp] = size( MyMS );
        if NumScans<nTemp
            MyMS = MyMS';
            NumScans = nTemp;
        end
        times = zeros( NumScans, 1 );
        for ii = 1:NumScans
            times( ii ) = MyMS{ ii }.Time;
        end
        MyDatasetToSave = cell( 1, NumPeptidesCurrent );
        q = 1;
        for k = 1:NumPeptides
            if inPrecursorRangesCurrent( k )==0
                continue
            end
            StartExtractTime = Tr_Pred( k ) - HalfExtractWindow;
            EndExtractTime = Tr_Pred( k ) + HalfExtractWindow;
            MyMS2keep = (times>=StartExtractTime) & (times<=EndExtractTime);
            subMyMS = MyMS( MyMS2keep );
            TimesTempo = times( MyMS2keep );
            NumTempo = size( TimesTempo, 1 );
            MyDataset = [  ];
            NumTransitions = size( MyPeptideMSspec{ k }.MSspec, 1 );
            for j = 1:NumTransitions
                precursor = MyPeptideMSspec{ k }.MSspec( j, 1 );
                mzProduct = MyPeptideMSspec{ k }.MSspec( j, 2 );
                if ~isnan( mzProduct )
                    mzInt = [ mzProduct * (1 + iRTMeanMzErrorPPM( SampleIndex ) / 1000000 - MzErrorLimitPPM / 1000000), mzProduct * (1 + iRTMeanMzErrorPPM( SampleIndex ) / 1000000 + MzErrorLimitPPM / 1000000) ];
                    EIPProd = ones( NumTempo, 3 ) * NaN;
                    for ii = 1:NumTempo
                        MStempo = subMyMS{ ii }.Data;
                        ind2keep = MStempo( :, 1 )>=mzInt( 1 ) & MStempo( :, 1 )<=mzInt( 2 );
                        switch sum( ind2keep )
                            case 0
                                EIPProd( ii, : ) = [ TimesTempo( ii ), 0, 0 ];
                            case 1
                                EIPProd( ii, : ) = [ TimesTempo( ii ), MStempo( ind2keep, : ) ];
                            otherwise
                                MStempoKept = MStempo( ind2keep, : );
                                SumIntensityTempo = sum( MStempoKept( :, 2 ) );
                                if SumIntensityTempo==0
                                    MzValue = 0;
                                else
                                    MzValue = sum( MStempoKept( :, 1 ) .* MStempoKept( :, 2 ) ) / SumIntensityTempo;
                                end
                                EIPProd( ii, : ) = [ TimesTempo( ii ), MzValue, SumIntensityTempo ];
                        end
                    end
                    if isSmooth==1
                        NumPoints=size(EIPProd,1);
                        MzSmooth=ones(NumPoints,1)*NaN;
                        MzSmooth(1,1)=EIPProd(1,2);
                        IntensitySmooth=ones(NumPoints,1)*NaN;
                        IntensitySmooth(1,1)=EIPProd(1,3);
                        for iii=2:NumPoints-1
                            MzSmooth(iii,1)=(EIPProd(iii-1,2)*EIPProd(iii-1,3)+EIPProd(iii,2)*EIPProd(iii,3)+EIPProd(iii+1,2)*EIPProd(iii+1,3))/(EIPProd(iii-1,3)+EIPProd(iii,3)+EIPProd(iii+1,3));
                            if isnan(MzSmooth(iii,1)) 
                                MzSmooth(iii,1)=0; 
                            end
                            IntensitySmooth(iii)=(EIPProd(iii-1,3)+EIPProd(iii,3)+EIPProd(iii+1,3))/3;
                        end
                        MzSmooth(NumPoints,1)=EIPProd(NumPoints,2);
                        IntensitySmooth(NumPoints)=EIPProd(NumPoints,3);
                        EIPProdSmooth=[EIPProd(:,1),MzSmooth,IntensitySmooth];
                        MyDataset{j}.Data=EIPProdSmooth;
                    else
                        MyDataset{j}.Data=EIPProd;
                    end
                    MyDataset{ j }.mzInt = mzInt;
                end
                MyDataset{ j }.precursor = precursor;
                MyDataset{ j }.mzProduct = mzProduct;
            end
            MyDatasetToSave{ q } = MyDataset;
            q = q + 1;
        end
        SaveName = [ FilePath, SubFileName, 'Sample', num2str( SampleIndex, '%03d' ), '.mat' ];
        parsave( SaveName, MyDatasetToSave );
    end
end
function parsave(fname,MyDatasetToSave)
    Info = whos( 'MyDatasetToSave' );
    if Info.bytes<2147483648
        save( fname, 'MyDatasetToSave', '-v7' );
    else
        save( fname, 'MyDatasetToSave', '-v7.3' );
    end
end
