function value = getMZML_value(curLine)
    CurrentPosStart = strfind( curLine, ' value="' ) + 8;
    CurrentLength = find( curLine( CurrentPosStart:end )=='"', 1 ) - 1;
    CurrentValue = curLine( CurrentPosStart:CurrentPosStart + CurrentLength - 1 );
    if isempty( CurrentValue )
        error( 'The mzML file format is not recognized.' );
    else
        value = str2double( CurrentValue );
    end
end
