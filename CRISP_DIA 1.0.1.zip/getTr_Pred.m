function Tr_Pred = getTr_Pred(Target_iRTValues,iRT_Boundaries,iRTValues,iRTtimes)
    Target_iRTValues = max( Target_iRTValues, iRT_Boundaries( 1, 2 ) );
    Target_iRTValues = min( Target_iRTValues, iRT_Boundaries( 2, 2 ) );
    Tr_Pred = TrPredInterp( iRTValues, iRTtimes, Target_iRTValues, iRT_Boundaries );
    Tr_Pred = Tr_Pred';
end
