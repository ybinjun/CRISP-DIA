function [TimeDeviationLimit_Intercept,TimeDeviationLimit_Slope] = get_TimeDeviationLimit3(iRTtimes,iRT_Boundaries)
    NumPeptides = size( iRTtimes, 2 );
    NumSamples = size( iRTtimes, 1 );
    iRTtimesMean = mean( iRTtimes );
    Tr_Pred_iRT = ones( NumSamples, NumPeptides ) * NaN;
    for i = 1:NumPeptides
        for j = 1:NumSamples
            Tr_Pred_iRT( j, i ) = interp1( [ iRT_Boundaries( 1, 1 ), iRTtimes( j, [ 1:i - 1, i + 1:NumPeptides ] ), iRT_Boundaries( 2, 1 ) ], [ iRT_Boundaries( 1, 1 ), iRTtimesMean( [ 1:i - 1, i + 1:NumPeptides ] ), iRT_Boundaries( 2, 1 ) ], iRTtimes( j, i ), 'linear' );
        end
    end
    TrDeviations = max( Tr_Pred_iRT, [  ], 1 ) - min( Tr_Pred_iRT, [  ], 1 );
    TimeDeviationLimit_Intercept = max( TrDeviations );
    TimeDeviationLimit_Intercept = TimeDeviationLimit_Intercept * 1;
    TimeDeviationLimit_Slope = 0;
end
