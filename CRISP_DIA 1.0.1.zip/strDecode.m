function Out = strDecode(str)
    PosEqual = find( str=='=' );
    NumEqual = size( PosEqual, 2 );
    NumStr = size( str, 2 );
    x = uint8( zeros( 1, NumStr ) );
    x( str=='+' ) = 62;
    x( str=='/' ) = 63;
    i = str>='A' & str<='Z';
    x( i ) = str( i ) - 'A';
    i = str>='a' & str<='z';
    x( i ) = str( i ) - 'a' + 26;
    i = str>='0' & str<='9';
    x( i ) = str( i ) - '0' + 52;
    x( PosEqual ) = 0;
    NumGroups = NumStr / 4;
    x = reshape( x, 4, NumGroups );
    Out = uint8( zeros( 3, NumGroups ) );
    Out( 1, : ) = bitshift( x( 1, : ), 2 );
    Out( 1, : ) = bitor( Out( 1, : ), bitshift( x( 2, : ), -4 ) );
    Out( 2, : ) = bitshift( x( 2, : ), 4 );
    Out( 2, : ) = bitor( Out( 2, : ), bitshift( x( 3, : ), -2 ) );
    Out( 3, : ) = bitshift( x( 3, : ), 6 );
    Out( 3, : ) = bitor( Out( 3, : ), x( 4, : ) );
    Out = Out( 1:end - NumEqual );
end
