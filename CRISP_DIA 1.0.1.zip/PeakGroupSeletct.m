function [FianlSelectedPeakIndex,FianlScore,FianlSelectedPeakIndexValidated] = PeakGroupSeletct(ScoresToSave,ScoreWeights)
    ScoreIntensity = ScoresToSave( :, 1 ) .^ ScoreWeights( 1 );
    ScoreRT_AfterSelectIon = ScoresToSave( :, 2 ) .^ ScoreWeights( 2 );
    ScoreCosDistAfterSelectIon = ScoresToSave( :, 3 ) .^ ScoreWeights( 3 );
    ScoreRSDArea = ScoresToSave( :, 4 ) .^ ScoreWeights( 4 );
    ScoreIntensityPrecursor = ScoresToSave( :, 5 ) .^ ScoreWeights( 5 );
    ScoreProfileSimilarity = ScoresToSave( :, 6 ) .^ ScoreWeights( 6 );
    ScoreEuclideanDistAfterSelectIon = ScoresToSave( :, 7 ) .^ ScoreWeights( 7 );
    ScoreNumIonsKept = ScoresToSave( :, 8 ) .^ ScoreWeights( 8 );
    ScoreMzError = ScoresToSave( :, 9 ) .^ ScoreWeights( 9 );
    ScoreSampleKept = ScoresToSave( :, 10 ) .^ ScoreWeights( 10 );
    ScoreComplementaryIon = ScoresToSave( :, 11 ) .^ ScoreWeights( 11 );
    ScoresMultiply = (ScoreIntensity .* ScoreRT_AfterSelectIon .* ScoreCosDistAfterSelectIon .* ScoreRSDArea .* ScoreIntensityPrecursor .* ScoreProfileSimilarity .* ScoreEuclideanDistAfterSelectIon .* ScoreNumIonsKept .* ScoreMzError .* ScoreSampleKept .* ScoreComplementaryIon / (100 ^ sum( ScoreWeights )));
    ScoresMultiply = ScoresMultiply .^ (1 / sum( ScoreWeights ));
    [FianlScore,FianlSelectedPeakIndex] = max( ScoresMultiply );
    NumPeaksForSelect = size( ScoresMultiply, 1 );
    if isnan( FianlScore ) || (FianlScore==0 && (NumPeaksForSelect - sum( isnan( ScoresMultiply ) ))>1)
        FianlSelectedPeakIndexValidated = 0;
    else
        FianlSelectedPeakIndexValidated = 1;
    end
end
