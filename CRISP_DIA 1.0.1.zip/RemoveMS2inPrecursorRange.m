function MyPeptideMSspec = RemoveMS2inPrecursorRange(MyPeptideMSspec,inPrecursorRanges,MzRangeWithBoundary)
    NumTransRemoved = 0;
    NumPeptides = size( MyPeptideMSspec, 2 );
    for i = 1:NumPeptides
        MzRangeWithBoundary_Cur = MzRangeWithBoundary( logical( inPrecursorRanges( :, i ) ), : );
        MSspecToRemove = MyPeptideMSspec{ i }.MSspec( :, 2 )>=MzRangeWithBoundary_Cur( 1 ) & MyPeptideMSspec{ i }.MSspec( :, 2 )<=MzRangeWithBoundary_Cur( 2 );
        if sum( MSspecToRemove )~=0
            MyPeptideMSspec{ i }.MSspec = MyPeptideMSspec{ i }.MSspec( ~MSspecToRemove, : );
            MyPeptideMSspec{ i }.NeutralLoss = MyPeptideMSspec{ i }.NeutralLoss( ~MSspecToRemove, : );
            MyPeptideMSspec{ i }.FragmentCharge = MyPeptideMSspec{ i }.FragmentCharge( ~MSspecToRemove, : );
            NumTransRemoved = NumTransRemoved + sum( MSspecToRemove );
        end
    end
end
