function [AllPeakListSum,areaAllSample,IonKept,MyDatasetAll,MzErrorPPM2,RankIndexAll,IonMobilityAvg] = PeakDetectIntegrate(NumSamples,OriginalReferenceMS2,iRTMeanMzErrorPPM,DataPosition,MzErrorLimitPPM,TimeDeviationLimit_Intercept,TimeDeviationLimit_Slope,NormalizeCoeff,IonMobilityDeviationLimit)
    areaAllSample = [  ];
    AllPeakListSum = [  ];
    IonKept = [  ];
    MzErrorPPM2 = [  ];
    load( DataPosition, 'MyDatasetAll' );
    for i = 1:NumSamples
        MyDataset = MyDatasetAll{ i };
        NumTransitions = size( MyDataset, 2 );
        for j = 1:NumTransitions
            MyDataset{ j }.Data( :, 3 ) = MyDataset{ j }.Data( :, 3 ) * NormalizeCoeff( i );
        end
        MyDatasetAll{ i } = MyDataset;
        PeakMinLimit = 0;
        PeakList = [  ];
        for j = 1:NumTransitions
            PeakList{ j } = PeakDetect( MyDataset{ j }.Data, 0.05, PeakMinLimit, OriginalReferenceMS2( 1, j ), iRTMeanMzErrorPPM( i ), MzErrorLimitPPM );
        end
        IonPeakListAllAglin = IonsAglin( PeakList, TimeDeviationLimit_Intercept, TimeDeviationLimit_Slope );
        IonPeakListAllAglin = PeakRemove( IonPeakListAllAglin, NumTransitions );
        IonPeakListSelected = IonSelect( IonPeakListAllAglin, MyDataset, IonMobilityDeviationLimit );
        [AllPeakListSum{ i },areaAllSample{ i },IonKept{ i },MzErrorPPM2{ i },RankIndexAll{ i },IonMobilityAvg{ i }] = IonPeakSumUp( IonPeakListSelected, MyDataset, OriginalReferenceMS2( 1, : ), iRTMeanMzErrorPPM( i ), MzErrorLimitPPM );
    end
end
