function [FinalIonsKeptIndexs,ReferenceMS2] = InterfereDetect(PeakListAglin,areaSampleAglin,ReferenceMS2,IonKeptCommon,SampleInfo,NumProcesses)
    NumSamples = size( areaSampleAglin, 1 );
    NumTransitions = size( areaSampleAglin, 2 );
    FinalIonsKeptIndexs = 1:NumTransitions;
    ii = NumSamples;
    while ii>0
        if isnan( PeakListAglin( ii, 1 ) )
            PeakListAglin( ii, : ) = [  ];
            areaSampleAglin( ii, : ) = [  ];
            SampleInfo( ii, : ) = [  ];
        end
        ii = ii - 1;
    end
    NumSamples = size( areaSampleAglin, 1 );
    j = NumTransitions;
    while j>0
        if IonKeptCommon( j )==0
            areaSampleAglin( :, j ) = [  ];
            NumTransitions = NumTransitions - 1;
            ReferenceMS2( :, j ) = [  ];
            FinalIonsKeptIndexs( j ) = [  ];
        end
        j = j - 1;
    end
    j = NumTransitions;
    while j>0
        nansumAreaSampleAglin = sum( areaSampleAglin( :, j ), 'omitnan' );
        if nansumAreaSampleAglin==0 || isnan( nansumAreaSampleAglin )
            areaSampleAglin( :, j ) = [  ];
            NumTransitions = NumTransitions - 1;
            ReferenceMS2( :, j ) = [  ];
            FinalIonsKeptIndexs( j ) = [  ];
        end
        j = j - 1;
    end
    if NumTransitions>2
        for ii = 1:NumProcesses
            MeanAreas( ii, : ) = mean( areaSampleAglin( ii==SampleInfo( :, 1 ), : ), 1, 'omitnan' );
        end
        if sum( ~all( isnan( MeanAreas ), 2 ) )>1
            CountNotNaNForProcesses = sum( ~isnan( MeanAreas ), 2 );
            SumAreasForProcesses = sum( MeanAreas, 2, 'omitnan' );
            [~,~,RankCountNotNaNForProcesses] = unique( CountNotNaNForProcesses, 'sorted' );
            if sum( max( RankCountNotNaNForProcesses )==RankCountNotNaNForProcesses )>1
                TempoMeanAreas = MeanAreas( max( RankCountNotNaNForProcesses )==RankCountNotNaNForProcesses, : );
                [~,TempoIndex1ForRatio] = max( SumAreasForProcesses( max( RankCountNotNaNForProcesses )==RankCountNotNaNForProcesses ) );
                MeanAreas1ForRatio = TempoMeanAreas( TempoIndex1ForRatio, : );
                TempoMeanAreas( TempoIndex1ForRatio, : ) = [  ];
                TempoSumAreasForProcesses = SumAreasForProcesses( max( RankCountNotNaNForProcesses )==RankCountNotNaNForProcesses );
                TempoSumAreasForProcesses( TempoIndex1ForRatio, : ) = [  ];
                [~,TempoRank] = sort( TempoSumAreasForProcesses );
                TempoIndex2ForRatio = TempoRank( round( size( TempoRank, 1 ) / 2 ) );
                MeanAreas2ForRatio = TempoMeanAreas( TempoIndex2ForRatio, : );
            else
                [~,Index1ForRatio] = max( RankCountNotNaNForProcesses );
                MeanAreas1ForRatio = MeanAreas( Index1ForRatio, : );
                [~,TempoRank] = sort( SumAreasForProcesses( (max( RankCountNotNaNForProcesses ) - 1)==RankCountNotNaNForProcesses ) );
                TempoIndex2ForRatio = TempoRank( round( size( TempoRank, 1 ) / 2 ) );
                TempoMeanAreas = MeanAreas( (max( RankCountNotNaNForProcesses ) - 1)==RankCountNotNaNForProcesses, : );
                MeanAreas2ForRatio = TempoMeanAreas( TempoIndex2ForRatio, : );
            end
            LogRatioForIons = log2( MeanAreas1ForRatio ./ MeanAreas2ForRatio );
            Limit_Abs_Diff_medianLogRatioForIons = 1;
            while NumTransitions>2
                if sum( ~isnan( ReferenceMS2( 2, : ) ) )>0
                    WeightedAvgRatioForIons = sum( LogRatioForIons( LogRatioForIons~=inf & LogRatioForIons~=-inf & ~isnan( LogRatioForIons ) ) .* ReferenceMS2( 2, LogRatioForIons~=inf & LogRatioForIons~=-inf & ~isnan( LogRatioForIons ) ) ) / sum( ReferenceMS2( 2, LogRatioForIons~=inf & LogRatioForIons~=-inf & ~isnan( LogRatioForIons ) ) );
                    Abs_Diff_LogRatioForIons = abs( LogRatioForIons - WeightedAvgRatioForIons );
                else
                    medianLogRatioForIons = median( LogRatioForIons, 'omitnan' );
                    Abs_Diff_LogRatioForIons = abs( LogRatioForIons - medianLogRatioForIons );
                end
                [max_Abs_Diff_LogRatioForIons,j] = max( Abs_Diff_LogRatioForIons );
                if max_Abs_Diff_LogRatioForIons>Limit_Abs_Diff_medianLogRatioForIons
                    areaSampleAglin( :, j ) = [  ];
                    NumTransitions = NumTransitions - 1;
                    ReferenceMS2( :, j ) = [  ];
                    FinalIonsKeptIndexs( j ) = [  ];
                    LogRatioForIons( j ) = [  ];
                else
                    break
                end
            end
        end
    end
    if NumTransitions>2
        if NumSamples>=2
            HCACosDistList = HCACosDist( areaSampleAglin );
            IonsKept = [ HCACosDistList( 1, 1 ), HCACosDistList( 1, 2 ) ];
            NumKept = 2;
            if HCACosDistList( 2, 1 )<=NumTransitions
                IonsKept = [ IonsKept, HCACosDistList( 2, 1 ) ];
                NumKept = NumKept + 1;
            end
            if HCACosDistList( 2, 2 )<=NumTransitions
                IonsKept = [ IonsKept, HCACosDistList( 2, 2 ) ];
                NumKept = NumKept + 1;
            end
            sumCosDistKept = sum( HCACosDistList( 1:2, 3 ) );
            NumCosDistKept = 2;
            DistLimitCoeff = 2;
            DistLimitAbs = 0.05;
            for k = 3:NumTransitions - 1
                if HCACosDistList( k, 3 )<DistLimitCoeff * sumCosDistKept / NumCosDistKept || HCACosDistList( k, 3 )<DistLimitAbs
                    KeptIncreased = 0;
                    if HCACosDistList( k, 1 )<=NumTransitions
                        IonsKept = [ IonsKept, HCACosDistList( k, 1 ) ];
                        NumKept = NumKept + 1;
                        KeptIncreased = 1;
                    end
                    if HCACosDistList( k, 2 )<=NumTransitions
                        IonsKept = [ IonsKept, HCACosDistList( k, 2 ) ];
                        NumKept = NumKept + 1;
                        KeptIncreased = 1;
                    end
                    if KeptIncreased==1
                        NumCosDistKept = NumCosDistKept + 1;
                        sumCosDistKept = sumCosDistKept + HCACosDistList( k, 3 );
                    end
                end
            end
            j = NumTransitions;
            while j>0
                if ~any( IonsKept==j )
                    areaSampleAglin( :, j ) = [  ];
                    NumTransitions = NumTransitions - 1;
                    ReferenceMS2( :, j ) = [  ];
                    FinalIonsKeptIndexs( j ) = [  ];
                end
                j = j - 1;
            end
        end
    end
end
function z = HCACosDist(x)
    x = x';
    y = pdist( x, 'cosine' );
    z = linkage( y );
end
