function check_iRT_Times(iRTtimes,iRTValues,MyPeptideMSspec,OutputFilePath_Matlab)
    NumPeptides = size( iRTtimes, 2 );
    IsIncrease = iRTtimes( :, 1:end - 1 )<=iRTtimes( :, 2:end );
    if ~all( IsIncrease, 'all' )
        SaveName = [ OutputFilePath_Matlab, 'iRTtimes.mat' ];
        save( SaveName, 'iRTtimes', 'iRTValues' );
        error( [ 'Abnormal trends in the detected retention times of the iRT peptides, which have been saved as ', SaveName, '. Try manually check the data and input all iRTtimes at the beginning.The existing abnormal iRT peptides should be discarded.' ] )
    end
    maxRTs = max( iRTtimes, [  ], 1 );
    minRTs = min( iRTtimes, [  ], 1 );
    medianRTs = median( iRTtimes, 1 );
    RTDeviationLimits = max( [ medianRTs * 0.1; ones( 1, NumPeptides ) * 2 ], [  ], 1 );
    for kk = 1:NumPeptides
        if (maxRTs( kk ) - minRTs( kk ))>RTDeviationLimits( kk )
            warning( [ 'Abnormal deviations in the detected retention times of the ', MyPeptideMSspec{ kk }.PeptideSequence, ' iRT peptide. Suggestion: End this process. Try manually check the data and input all iRTtimes at the beginning. Or, press Enter to continue.' ] )
            pause;
        end
    end
    iRTcoef = corrcoef( iRTValues, medianRTs );
    iRTcoef = iRTcoef( 1, 2 );
    if iRTcoef<0.95
        warning( 'Too low pearson correlation coefficient between the iRT values and the detected retention times of the iRT peptides. Suggestion: End this process. Try manually check the data and discard the abnormal iRT peptides. Or, press Enter to continue.' )
        pause;
    end
end
