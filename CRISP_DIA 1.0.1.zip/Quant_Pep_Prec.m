function [FianlScore,FianlRatios,FianlAreas,FianlRTs,FianlPeakStarts,FianlPeakEnds,FianlSelectedProductIons,IonMobilityAvgAll] = Quant_Pep_Prec(MyPeptideMSspec,FilePath,FilePathPrecursor,FilePathComplementaryIon,SampleInfo,iRT_Boundaries,iRTtimes,iRTMeanMzErrorPPM,MzErrorLimitPPM,TimeDeviationLimit_Intercept,TimeDeviationLimit_Slope,Tr_Pred_All,ScoreWeights1,HalfExtractWindow,NormalizeCoeff,is_iRTClac,IonMobilityHalfWindow,IonMobilityAll,IonMobilityDeviationLimit)
    NumPeptides = size( MyPeptideMSspec, 2 );
    NumProcesses = max( SampleInfo( :, 1 ) );
    NumSamples = size( SampleInfo, 1 );
    FianlRatios = ones( NumProcesses - 1, NumPeptides ) * NaN;
    FianlScore = ones( 1, NumPeptides ) * NaN;
    FianlAreaSamples = ones( NumProcesses, NumPeptides ) * NaN;
    FianlAreas = ones( NumSamples, NumPeptides ) * NaN;
    ScoresToSave = [  ];
    FianlRTs = ones( NumSamples, NumPeptides ) * NaN;
    FianlPeakStarts = ones( NumSamples, NumPeptides ) * NaN;
    FianlPeakEnds = ones( NumSamples, NumPeptides ) * NaN;
    FianlSelectedPeakIndexToSave = ones( 1, NumPeptides ) * NaN;
    ErrorPrecursor = [  ];
    IonMobilityAvgAll = ones( NumPeptides, NumSamples ) * NaN;
    parfor kk = 1:NumPeptides
        warning( 'off' );
        ScoreWeights = ScoreWeights1;
        NumSampleKept = [  ];
        IonKeptCommon = [  ];
        IonKeptOneColumn = [  ];
        RankIndexAllAglin = [  ];
        IonMobilityAvgAglin = [  ];
        MzErrorPPM2Aglin = [  ];
        areaAllSampleAglin = [  ];
        IonsIndexsOrig = [  ];
        BestMatchRunID = [  ];
        MyDatasetAll = [  ];
        Tr_PredSample = [  ];
        isLibFreeMode = [  ];
        OriginalReferenceMS2 = [  ];
        if ~isempty( MyPeptideMSspec{ kk }.MSspec )
            OriginalReferenceMS2 = MyPeptideMSspec{ kk }.MSspec( :, 2:3 )';
            NumTransitions = size( OriginalReferenceMS2, 2 );
            if sum( ~isnan( OriginalReferenceMS2( 2, : ) ) )==0
                isLibFreeMode = true;
            else
                isLibFreeMode = false;
            end
            Tr_PredSample = Tr_Pred_All( kk, : )';
            Tr_Pred = mean( Tr_PredSample );
            DataPosition = [ FilePath, num2str( MyPeptideMSspec{ kk }.MSspec( 1, 1 ), '%4.0f' ), MyPeptideMSspec{ kk }.PeptideSequence, '.mat' ];
            [AllPeakListSum,areaAllSample,IonKept,MyDatasetAll,MzErrorPPM2,RankIndexAll,IonMobilityAvg] = PeakDetectIntegrate( NumSamples, OriginalReferenceMS2, iRTMeanMzErrorPPM, DataPosition, MzErrorLimitPPM, TimeDeviationLimit_Intercept, TimeDeviationLimit_Slope, NormalizeCoeff, IonMobilityDeviationLimit );
            if ~isempty( FilePathPrecursor )
                PrecursorDataPosition = [ FilePathPrecursor, num2str( MyPeptideMSspec{ kk }.MSspec( 1, 1 ), '%4.0f' ), MyPeptideMSspec{ kk }.PeptideSequence, '.mat' ];
            else
                PrecursorDataPosition = [  ];
            end
            if isnan( IonMobilityHalfWindow ) || sum( ~isnan( IonMobilityAll( kk, : ) ) )==0
                ScoreWeights( 11 ) = 0;
            end
            [BestMatchRunID,BestMatchPeakID,BestMatchIonsKept,BestPeakScore( kk, : )] = getBestMatchPeak( AllPeakListSum, areaAllSample, IonKept, MzErrorPPM2, OriginalReferenceMS2, ScoreWeights, PrecursorDataPosition, Tr_PredSample, MzErrorLimitPPM, HalfExtractWindow, isLibFreeMode, IonMobilityAvg, IonMobilityAll( kk, : ), IonMobilityHalfWindow );
            if isnan( BestPeakScore( kk, : ) ) || BestPeakScore( kk, : )==0
                PeakListAllAglin = [  ];
            else
                AllPeakListSum{ BestMatchRunID } = AllPeakListSum{ BestMatchRunID }( BestMatchPeakID, : );
                areaAllSample{ BestMatchRunID } = areaAllSample{ BestMatchRunID }( BestMatchPeakID, : );
                IonKept{ BestMatchRunID } = IonKept{ BestMatchRunID }( BestMatchPeakID, : );
                MzErrorPPM2{ BestMatchRunID } = MzErrorPPM2{ BestMatchRunID }( BestMatchPeakID, : );
                RankIndexAll{ BestMatchRunID } = RankIndexAll{ BestMatchRunID }( BestMatchPeakID, : );
                IonMobilityAvg{ BestMatchRunID } = IonMobilityAvg{ BestMatchRunID }( BestMatchPeakID, : );
                for i = 1:NumSamples
                    if ~isempty( AllPeakListSum{ i } )
                        areaAllSample{ i } = areaAllSample{ i }( :, BestMatchIonsKept );
                        IonKept{ i } = IonKept{ i }( :, BestMatchIonsKept );
                        MzErrorPPM2{ i } = MzErrorPPM2{ i }( :, BestMatchIonsKept );
                        RankIndexAll{ i } = RankIndexAll{ i }( :, BestMatchIonsKept );
                        IonMobilityAvg{ i } = IonMobilityAvg{ i }( :, BestMatchIonsKept );
                    else
                        AllPeakListSum{ i } = ones( 1, 10 ) * NaN;
                        NumTransTempo = sum( BestMatchIonsKept );
                        areaAllSample{ i } = ones( 1, NumTransTempo ) * NaN;
                        IonKept{ i } = zeros( 1, NumTransTempo );
                        MzErrorPPM2{ i } = ones( 1, NumTransTempo ) * NaN;
                        RankIndexAll{ i } = ones( 1, NumTransTempo ) * NaN;
                        IonMobilityAvg{ i } = ones( 1, NumTransTempo ) * NaN;
                    end
                end
                NewReferenceMS2Intensity = areaAllSample{ BestMatchRunID };
                OriginalReferenceMS2 = [ OriginalReferenceMS2( 1, BestMatchIonsKept ); NewReferenceMS2Intensity ];
                IonsIndexsOrig = (1:NumTransitions)';
                IonsIndexsOrig = IonsIndexsOrig( BestMatchIonsKept );
                NumTransitions = size( OriginalReferenceMS2, 2 );
                iRTtimesMean = mean( iRTtimes );
                BestMatchRTAglined = interp1( [ iRT_Boundaries( 1, 1 ), iRTtimes( BestMatchRunID, : ), iRT_Boundaries( 2, 1 ) ], [ iRT_Boundaries( 1, 1 ), iRTtimesMean, iRT_Boundaries( 2, 1 ) ], AllPeakListSum{ BestMatchRunID }( 1, 1 ), 'linear' );
                TimeDeviationLimit = BestMatchRTAglined * TimeDeviationLimit_Slope + TimeDeviationLimit_Intercept;
                IonMobilityReferenceBias = median( IonMobilityAvg{ BestMatchRunID }, 'omitnan' ) - IonMobilityAll( kk, BestMatchRunID );
                PeakScore = [  ];
                for i = 1:NumSamples
                    if i~=BestMatchRunID
                        RTAglined = interp1( [ iRT_Boundaries( 1, 1 ), iRTtimes( i, : ), iRT_Boundaries( 2, 1 ) ], [ iRT_Boundaries( 1, 1 ), iRTtimesMean, iRT_Boundaries( 2, 1 ) ], AllPeakListSum{ i }( :, 1 ), 'linear' );
                        IonMobilityReferenceTemp = IonMobilityAll( kk, i ) + IonMobilityReferenceBias;
                        [AllPeakListSum{ i },areaAllSample{ i },IonKept{ i },MzErrorPPM2{ i },IonMobilityAvg{ i },RankIndexAll{ i },PeakScore( i, 1 )] = getMatchPeak2( AllPeakListSum{ i }, areaAllSample{ i }, IonKept{ i }, MzErrorPPM2{ i }, IonMobilityAvg{ i }, RankIndexAll{ i }, OriginalReferenceMS2, BestMatchRTAglined, TimeDeviationLimit, RTAglined, ScoreWeights, MzErrorLimitPPM, is_iRTClac, isLibFreeMode, IonMobilityReferenceTemp, IonMobilityHalfWindow );
                    end
                end
                PeakScore( BestMatchRunID ) = NaN;
                for i = 1:NumProcesses
                    indexCur = find( SampleInfo( :, 1 )==i );
                    PeakScore_CurCondition = PeakScore( indexCur );
                    PeakIsRemove_CurCondition = (max( PeakScore_CurCondition ) - PeakScore_CurCondition>0.2) | (PeakScore_CurCondition<0.5);
                    PeakToRemove_CurCondition = indexCur( PeakIsRemove_CurCondition );
                    PeakToRemove_CurCondition( BestMatchRunID==PeakToRemove_CurCondition ) = [  ];
                    if ~isempty( PeakToRemove_CurCondition )
                        for j = 1:size( PeakToRemove_CurCondition, 1 )
                            NumColumns = 10;
                            AllPeakListSum{ PeakToRemove_CurCondition( j ) } = ones( 1, NumColumns ) * NaN;
                            areaAllSample{ PeakToRemove_CurCondition( j ) } = ones( 1, NumTransitions ) * NaN;
                            IonKept{ PeakToRemove_CurCondition( j ) } = zeros( 1, NumTransitions );
                            MzErrorPPM2{ PeakToRemove_CurCondition( j ) } = ones( 1, NumTransitions ) * NaN;
                            IonMobilityAvg{ PeakToRemove_CurCondition( j ) } = ones( 1, NumTransitions ) * NaN;
                            RankIndexAll{ PeakToRemove_CurCondition( j ) } = ones( 1, NumTransitions ) * NaN;
                        end
                    end
                end
                PeakListAllAglin = cell2mat( AllPeakListSum' );
                PeakListAllAglin( :, [ 8, 9 ] ) = NaN;
                areaAllSampleAglin = cell2mat( areaAllSample' );
                MzErrorPPM2Aglin = cell2mat( MzErrorPPM2' );
                IonMobilityAvgAglin = cell2mat( IonMobilityAvg' );
                RankIndexAllAglin = cell2mat( RankIndexAll' );
                IonKeptOneColumn = cell2mat( IonKept' );
                if ScoreWeights( 4 )~=0
                    IndexSamplesForConditions = cell( NumProcesses, 1 );
                    AreaSamplesForRSD = cell( NumProcesses, 1 );
                    for ii = 1:NumSamples
                        IndexSamplesForConditions{ SampleInfo( ii, 1 ), 1 }( end + 1, 1 ) = ii;
                        if ~isnan( PeakListAllAglin( ii, 1 ) )
                            AreaSamplesForRSD{ SampleInfo( ii, 1 ), 1 }( end + 1, 1 ) = sum( areaAllSampleAglin( ii, : ), 'omitnan' );
                        else
                            AreaSamplesForRSD{ SampleInfo( ii, 1 ), 1 }( end + 1, 1 ) = NaN;
                        end
                    end
                    for i = 1:size( AreaSamplesForRSD, 1 )
                        if std( AreaSamplesForRSD{ i, 1 }, 'omitnan' ) / mean( AreaSamplesForRSD{ i, 1 }, 'omitnan' )>1
                            IonKeptOneColumn( IndexSamplesForConditions{ i }, : ) = 0;
                            PeakListAllAglin( IndexSamplesForConditions{ i }, : ) = NaN;
                            areaAllSampleAglin( IndexSamplesForConditions{ i }, : ) = NaN;
                            MzErrorPPM2Aglin( IndexSamplesForConditions{ i }, : ) = NaN;
                            IonMobilityAvgAglin( IndexSamplesForConditions{ i }, : ) = NaN;
                            RankIndexAllAglin( IndexSamplesForConditions{ i }, : ) = NaN;
                        end
                    end
                end
                [PeakListAllAglin,IonKeptCommon] = getIonKeptCommon2( PeakListAllAglin, IonKeptOneColumn, SampleInfo );
                areaAllSampleAglin( isnan( PeakListAllAglin( :, 1 ) ), : ) = NaN;
                MzErrorPPM2Aglin( isnan( PeakListAllAglin( :, 1 ) ), : ) = NaN;
                IonMobilityAvgAglin( isnan( PeakListAllAglin( :, 1 ) ), : ) = NaN;
                RankIndexAllAglin( isnan( PeakListAllAglin( :, 1 ) ), : ) = NaN;
                IonKeptOneColumn( isnan( PeakListAllAglin( :, 1 ) ), : ) = 0;
                NumSampleKept = sum( ~isnan( PeakListAllAglin( :, 1 ) ) );
                NumIonsLeast = 1;
                if sum( IonKeptCommon )<NumIonsLeast
                    PeakListAllAglin = [  ];
                end
                ScoreWeights( 1 ) = 0;
                ScoreWeights( 5 ) = 0;
                ScoreWeights( 3 ) = 0;
            end
        else
            PeakListAllAglin = [  ];
        end
        if isempty( PeakListAllAglin )
            FianlRatios( :, kk ) = ones( NumProcesses - 1, 1 ) * NaN;
            FianlRTs( :, kk ) = NaN;
            FianlPeakStarts( :, kk ) = NaN;
            FianlPeakEnds( :, kk ) = NaN;
            FianlSelectedProductIons{ kk } = NaN;
            FianlSelectedPeakAreas{ kk } = NaN;
            FianlScore( 1, kk ) = NaN;
        else
            NumIonsKeptMean = sum( sum( IonKeptOneColumn ) ) / NumSampleKept;
            ScoreNumIonsKept = (NumIonsKeptMean - 1 + 1) / (min( [ size( MyPeptideMSspec{ kk }.MSspec, 1 ), 15 ] ) - 1 + 1) * 100;
            if ScoreNumIonsKept>=100
                ScoreNumIonsKept = 100;
            end
            if ScoreNumIonsKept<0
                ScoreNumIonsKept = 0;
            end
            [FinalIonsKeptIndexs,ReferenceMS2] = InterfereDetect( PeakListAllAglin, areaAllSampleAglin, OriginalReferenceMS2, IonKeptCommon, SampleInfo, NumProcesses );
            areaListAglinSelectedIons = areaAllSampleAglin( :, FinalIonsKeptIndexs );
            PeakListAglinSelectedIons = PeakListAllAglin;
            PeakListAglinSelectedIons( :, 8 ) = sum( areaListAglinSelectedIons, 2 );
            IonMobilityAvgSelectedIons = ones( NumSamples, 1 ) * NaN;
            for ii = 1:NumSamples
                if ~isnan( PeakListAglinSelectedIons( ii, 1 ) )
                    PeakListAglinSelectedIons( ii, 9 ) = median( MzErrorPPM2Aglin( ii, FinalIonsKeptIndexs ), 'omitnan' );
                    IonMobilityAvgSelectedIons( ii ) = median( IonMobilityAvgAglin( ii, FinalIonsKeptIndexs ), 'omitnan' );
                    PeakListAglinSelectedIons( ii, 10 ) = mean( RankIndexAllAglin( ii, IonKeptOneColumn( ii, : )==1 ), 'omitnan' );
                else
                    PeakListAglinSelectedIons( ii, 9 ) = NaN;
                    PeakListAglinSelectedIons( ii, 10 ) = NaN;
                end
            end
            IonMobilityReferenceBias = IonMobilityAvgSelectedIons( BestMatchRunID ) - IonMobilityAll( kk, BestMatchRunID );
            IonMobilityError = mean( abs( IonMobilityAvgSelectedIons - (IonMobilityAll( kk, : )' + IonMobilityReferenceBias) ), 'omitnan' );
            if isLibFreeMode
                CosDistAfterSelectIon = NaN;
                EuclideanDistAfterSelectIon = NaN;
            elseif sum( IonKeptCommon )==1
                CosDistAfterSelectIon = 0.5;
                EuclideanDistAfterSelectIon = 0.15;
            else
                CosDist2 = [  ];
                for ii = 1:NumSamples
                    if isnan( PeakListAglinSelectedIons( ii, 1 ) )
                        CosDist2( ii ) = NaN;
                    else
                        CosDist2( ii ) = 1 - dot( ReferenceMS2( 2, : ), areaListAglinSelectedIons( ii, : ) ) / norm( ReferenceMS2( 2, : ) ) / norm( areaListAglinSelectedIons( ii, : ) );
                    end
                end
                CosDistAfterSelectIon = median( CosDist2, 'omitnan' );
                ScaledReferenceMS2 = ReferenceMS2( 2, : ) / sum( ReferenceMS2( 2, : ) );
                NumTransitions_Current = size( ScaledReferenceMS2, 2 );
                EuclideanDist = [  ];
                for ii = 1:NumSamples
                    if isnan( PeakListAglinSelectedIons( ii, 1 ) )
                        EuclideanDist( ii ) = NaN;
                    else
                        ScaledSampleMS2 = areaListAglinSelectedIons( ii, : ) / sum( areaListAglinSelectedIons( ii, : ) );
                        EuclideanDist( ii ) = sqrt( sum( (ScaledSampleMS2 - ScaledReferenceMS2) .* (ScaledSampleMS2 - ScaledReferenceMS2) ) / (NumTransitions_Current - 1) );
                    end
                end
                EuclideanDistAfterSelectIon = median( EuclideanDist, 'omitnan' );
            end
            PeakAreaAfterSelectIon = sum( PeakListAglinSelectedIons( :, 8 ), 'omitnan' ) / NumSamples;
            RTerror_AfterSelectIon = mean( abs( PeakListAglinSelectedIons( :, 1 ) - Tr_PredSample ), 'omitnan' );
            PrecursorPeakArea = NaN;
            AreaSamplesForRSD = [  ];
            CountAreaSamples = zeros( NumProcesses, 1 );
            for ii = 1:NumSamples
                CountAreaSamples( SampleInfo( ii, 1 ) ) = CountAreaSamples( SampleInfo( ii, 1 ) ) + 1;
                AreaSamplesForRSD{ SampleInfo( ii, 1 ) }( CountAreaSamples( SampleInfo( ii, 1 ) ) ) = sum( areaListAglinSelectedIons( ii, : ) );
            end
            CosDistComplementaryIon = NaN;
            if isempty( FilePathComplementaryIon )
                CosDistComplementaryIon = 0;
            else
                DataPosition = [ FilePathComplementaryIon, num2str( MyPeptideMSspec{ kk }.MSspec( 1, 1 ), '%4.0f' ), MyPeptideMSspec{ kk }.PeptideSequence, '.mat' ];
                MyDatasetAllComplementaryIon = load( DataPosition, 'MyDatasetAll' );
                MyDatasetAllComplementaryIon = MyDatasetAllComplementaryIon.MyDatasetAll;
                CosDist3SampleMedian = [  ];
                if ~isempty( FinalIonsKeptIndexs )
                    for j = FinalIonsKeptIndexs
                        if isnan( MyDatasetAllComplementaryIon{ 1 }{ j }.mzProduct )
                            CosDist3SampleMedian( j ) = NaN;
                        else
                            CosDist3 = [  ];
                            for ii = 1:NumSamples
                                if isnan( PeakListAglinSelectedIons( ii, 1 ) )
                                    CosDist3( ii ) = NaN;
                                else
                                    TempoComplementaryIonIntensity = MyDatasetAllComplementaryIon{ ii }{ j }.Data( PeakListAglinSelectedIons( ii, 5 ):PeakListAglinSelectedIons( ii, 6 ), 3 );
                                    TempoProdIonIntensity = MyDatasetAll{ ii }{ j }.Data( PeakListAglinSelectedIons( ii, 5 ):PeakListAglinSelectedIons( ii, 6 ), 3 );
                                    CosDist3( ii ) = 1 - dot( TempoProdIonIntensity, TempoComplementaryIonIntensity ) / norm( TempoProdIonIntensity ) / norm( TempoComplementaryIonIntensity );
                                end
                            end
                            CosDist3SampleMedian( j ) = median( CosDist3, 'omitnan' );
                        end
                    end
                    CosDistComplementaryIon = median( CosDist3SampleMedian( FinalIonsKeptIndexs{ k } ), 'omitnan' );
                end
            end
            ScoresToSave = PeakGroupsScoring( NumProcesses, PeakAreaAfterSelectIon, RTerror_AfterSelectIon, CosDistAfterSelectIon, AreaSamplesForRSD, PrecursorPeakArea, PeakListAglinSelectedIons, EuclideanDistAfterSelectIon, ScoreNumIonsKept, CosDistComplementaryIon, MzErrorLimitPPM, HalfExtractWindow, IonMobilityError, IonMobilityHalfWindow );
            if isLibFreeMode
                ScoreWeights( 2 ) = 0;
                ScoreWeights( 3 ) = 0;
                ScoreWeights( 7 ) = 0;
            end
            [~,FianlScore( 1, kk ),FianlSelectedPeakIndexValidated] = PeakGroupSeletct( ScoresToSave, ScoreWeights );
            MeanAreaSamples = ones( NumProcesses, 1 ) * NaN;
            if FianlSelectedPeakIndexValidated==0
                FianlRatios( :, kk ) = ones( NumProcesses - 1, 1 ) * NaN;
                FianlSelectedProductIons{ kk } = NaN;
                FianlAreaSamples( :, kk ) = ones( NumProcesses, 1 ) * NaN;
                FianlSelectedPeak = ones( NumSamples, 10 ) * NaN;
                FianlSelectedPeakAreas{ kk } = NaN;
                FianlAreas( :, kk ) = ones( NumSamples, 1 ) * NaN;
            else
                FianlSelectedPeakAreas{ kk } = areaListAglinSelectedIons;
                FianlAreas( :, kk ) = sum( FianlSelectedPeakAreas{ kk }, 2 );
                FianlSelectedPeak = PeakListAglinSelectedIons( :, : );
                for ii = 1:NumProcesses
                    MeanAreaSamples( ii ) = mean( AreaSamplesForRSD{ ii }, 'omitnan' );
                end
                TempoFianlRatios = [  ];
                for ii = 2:NumProcesses
                    TempoFianlRatios( ii - 1, 1 ) = MeanAreaSamples( ii ) / MeanAreaSamples( 1 );
                end
                FianlRatios( :, kk ) = TempoFianlRatios;
                FianlSelectedProductIons{ kk } = [ IonsIndexsOrig( FinalIonsKeptIndexs )'; OriginalReferenceMS2( 1, FinalIonsKeptIndexs ) ];
            end
            FianlAreaSamples( :, kk ) = MeanAreaSamples;
            FianlRTs( :, kk ) = FianlSelectedPeak( :, 1 );
            FianlPeakStarts( :, kk ) = FianlSelectedPeak( :, 2 );
            FianlPeakEnds( :, kk ) = FianlSelectedPeak( :, 3 );
            IonMobilityAvgAll( kk, : ) = IonMobilityAvgSelectedIons';
        end
        if mod( kk, 1000 )==0
            disp( 'About 1000 peptide precursors calculated after the previous information display.' );
        end
        warning( 'on' );
    end
    FianlRatios = FianlRatios';
    FianlRTs = FianlRTs';
    FianlPeakStarts = FianlPeakStarts';
    FianlPeakEnds = FianlPeakEnds';
    FianlScore = FianlScore';
    FianlAreaSamples = FianlAreaSamples';
    FianlAreas = FianlAreas';
    FianlSelectedProductIons = FianlSelectedProductIons';
    FianlScore = sqrt( FianlScore .* BestPeakScore );
    FianlScore( isnan( FianlScore ) ) = 0;
end
